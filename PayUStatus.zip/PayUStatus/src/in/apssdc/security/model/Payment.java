package in.apssdc.security.model;

import com.andromeda.commons.model.BaseModel;

public class Payment extends BaseModel
{
	private String paymentOption;
	private String aadhaar;
	private String uniqueKey;

	public String getUniqueKey()
	{
		return uniqueKey;
	}

	public void setUniqueKey(String uniqueKey)
	{
		this.uniqueKey = uniqueKey;
	}

	public String getPaymentOption()
	{
		return paymentOption;
	}

	public void setPaymentOption(String paymentOption)
	{
		this.paymentOption = paymentOption;
	}

	public String getAadhaar()
	{
		return aadhaar;
	}

	public void setAadhaar(String aadhaar)
	{
		this.aadhaar = aadhaar;
	}

}
