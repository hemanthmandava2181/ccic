package in.apssdc.security.model;

import com.andromeda.commons.model.BaseModel;

public class Echallan extends BaseModel
{
	private String email;
	private Integer jobid;
	private String aadhaar;
	private String guid;
	private String apssdcNumber;
	private String iidtNumber;
	private String challanPath;
	private String ipAddress;
	private String phone;
	private String name;
	private String program;
	private String uniqueKey;

	public String getUniqueKey()
	{
		return uniqueKey;
	}

	public void setUniqueKey(String uniqueKey)
	{
		this.uniqueKey = uniqueKey;
	}

	public String getProgram()
	{
		return program;
	}

	public void setProgram(String program)
	{
		this.program = program;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public Integer getJobid()
	{
		return jobid;
	}

	public void setJobid(Integer jobid)
	{
		this.jobid = jobid;
	}

	public String getAadhaar()
	{
		return aadhaar;
	}

	public void setAadhaar(String aadhaar)
	{
		this.aadhaar = aadhaar;
	}

	public String getGuid()
	{
		return guid;
	}

	public void setGuid(String guid)
	{
		this.guid = guid;
	}

	public String getApssdcNumber()
	{
		return apssdcNumber;
	}

	public void setApssdcNumber(String apssdcNumber)
	{
		this.apssdcNumber = apssdcNumber;
	}

	public String getIidtNumber()
	{
		return iidtNumber;
	}

	public void setIidtNumber(String iidtNumber)
	{
		this.iidtNumber = iidtNumber;
	}

	public String getChallanPath()
	{
		return challanPath;
	}

	public void setChallanPath(String challanPath)
	{
		this.challanPath = challanPath;
	}

	public String getIpAddress()
	{
		return ipAddress;
	}

	public void setIpAddress(String ipAddress)
	{
		this.ipAddress = ipAddress;
	}

	public String getPhone()
	{
		return phone;
	}

	public void setPhone(String phone)
	{
		this.phone = phone;
	}

}
