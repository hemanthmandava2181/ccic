package in.apssdc.security.model;

import java.util.Date;

import com.andromeda.commons.model.BaseModel;

public class PersonalInfo extends BaseModel
{
	private String name;
	private String fathername;
	private String category;
	private String gender;
	private Long phone;
	private String email;
	private String aadhaar;
	private String caste;
	private String pincode;
	private String doorno;
	private String street;
	private String villageName;
	private String mandalName;
	private String districtName;
	private String stateName;
	private Date dob;
	private Integer jobid;
	private String skills;
	private Long alternate_phno;
	private String examinationCenter;
	private String examinationCenter2;
	private String examinationCenter3;
	private String ipAddress;
	private String iidtRegistrationNo;
	private String program;
	private String paymentoption;

	public String getExaminationCenter2()
	{
		return examinationCenter2;
	}

	public void setExaminationCenter2(String examinationCenter2)
	{
		this.examinationCenter2 = examinationCenter2;
	}

	public String getExaminationCenter3()
	{
		return examinationCenter3;
	}

	public void setExaminationCenter3(String examinationCenter3)
	{
		this.examinationCenter3 = examinationCenter3;
	}

	public String getPaymentoption()
	{
		return paymentoption;
	}

	public void setPaymentoption(String paymentoption)
	{
		this.paymentoption = paymentoption;
	}

	public String getProgram()
	{
		return program;
	}

	public void setProgram(String program)
	{
		this.program = program;
	}

	public String getIidtRegistrationNo()
	{
		return iidtRegistrationNo;
	}

	public void setIidtRegistrationNo(String iidtRegistrationNo)
	{
		this.iidtRegistrationNo = iidtRegistrationNo;
	}

	public String getExaminationCenter()
	{
		return examinationCenter;
	}

	public void setExaminationCenter(String examinationCenter)
	{
		this.examinationCenter = examinationCenter;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getFathername()
	{
		return fathername;
	}

	public void setFathername(String fathername)
	{
		this.fathername = fathername;
	}

	public String getCategory()
	{
		return category;
	}

	public void setCategory(String category)
	{
		this.category = category;
	}

	public String getGender()
	{
		return gender;
	}

	public void setGender(String gender)
	{
		this.gender = gender;
	}

	public Long getPhone()
	{
		return phone;
	}

	public void setPhone(Long phone)
	{
		this.phone = phone;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public String getAadhaar()
	{
		return aadhaar;
	}

	public void setAadhaar(String aadhaar)
	{
		this.aadhaar = aadhaar;
	}

	public String getCaste()
	{
		return caste;
	}

	public void setCaste(String caste)
	{
		this.caste = caste;
	}

	public String getPincode()
	{
		return pincode;
	}

	public void setPincode(String pincode)
	{
		this.pincode = pincode;
	}

	public String getDoorno()
	{
		return doorno;
	}

	public void setDoorno(String doorno)
	{
		this.doorno = doorno;
	}

	public String getStreet()
	{
		return street;
	}

	public void setStreet(String street)
	{
		this.street = street;
	}

	public String getVillageName()
	{
		return villageName;
	}

	public void setVillageName(String villageName)
	{
		this.villageName = villageName;
	}

	public String getMandalName()
	{
		return mandalName;
	}

	public void setMandalName(String mandalName)
	{
		this.mandalName = mandalName;
	}

	public String getDistrictName()
	{
		return districtName;
	}

	public void setDistrictName(String districtName)
	{
		this.districtName = districtName;
	}

	public String getStateName()
	{
		return stateName;
	}

	public void setStateName(String stateName)
	{
		this.stateName = stateName;
	}

	public Date getDob()
	{
		return dob;
	}

	public void setDob(Date dob)
	{
		this.dob = dob;
	}

	public Integer getJobid()
	{
		return jobid;
	}

	public void setJobid(Integer jobid)
	{
		this.jobid = jobid;
	}

	public String getSkills()
	{
		return skills;
	}

	public void setSkills(String skills)
	{
		this.skills = skills;
	}

	public Long getAlternate_phno()
	{
		return alternate_phno;
	}

	public void setAlternate_phno(Long alternate_phno)
	{
		this.alternate_phno = alternate_phno;
	}

	public String getIpAddress()
	{
		return ipAddress;
	}

	public void setIpAddress(String ipAddress)
	{
		this.ipAddress = ipAddress;
	}

}
