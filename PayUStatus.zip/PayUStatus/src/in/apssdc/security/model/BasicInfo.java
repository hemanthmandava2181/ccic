package in.apssdc.security.model;

import com.andromeda.commons.model.BaseModel;

public class BasicInfo extends BaseModel
{
	private String email;
	private Integer jobid;
	private String aadhaar;
	private String phone;

	public String getPhone()
	{
		return phone;
	}

	public void setPhone(String phone)
	{
		this.phone = phone;
	}

	public String getAadhaar()
	{
		return aadhaar;
	}

	public void setAadhaar(String aadhaar)
	{
		this.aadhaar = aadhaar;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public Integer getJobid()
	{
		return jobid;
	}

	public void setJobid(Integer jobid)
	{
		this.jobid = jobid;
	}

}
