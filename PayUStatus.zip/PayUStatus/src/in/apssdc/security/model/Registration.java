package in.apssdc.security.model;

import com.andromeda.commons.model.BaseModel;

public class Registration extends BaseModel
{
	private PersonalInfo personalInfo;
	private EducationalInfo educationInfo;
	private SkillsInfo skillsInfo;
	private String challanPath;

	public String getChallanPath()
	{
		return challanPath;
	}

	public void setChallanPath(String challanPath)
	{
		this.challanPath = challanPath;
	}

	public PersonalInfo getPersonalInfo()
	{
		return personalInfo;
	}

	public void setPersonalInfo(PersonalInfo personalInfo)
	{
		this.personalInfo = personalInfo;
	}

	public EducationalInfo getEducationInfo()
	{
		return educationInfo;
	}

	public void setEducationInfo(EducationalInfo educationInfo)
	{
		this.educationInfo = educationInfo;
	}

	public SkillsInfo getSkillsInfo()
	{
		return skillsInfo;
	}

	public void setSkillsInfo(SkillsInfo skillsInfo)
	{
		this.skillsInfo = skillsInfo;
	}

}
