package in.apssdc.security.model;

import com.andromeda.commons.model.BaseModel;

public class EducationalInfo extends BaseModel
{

	private String sscInstitute;
	private Double sscGpa;
	private Double sscPercentage;
	private String sscBoard;
	private String sscGradingType;
	private Integer sscyear;
	private String interInstitute;
	private String interGradingType;
	private Double interGpa;
	private Double interPercentage;
	private String interBoard;
	private Integer interyear;
	private String graduationType;
	private String graduationBranch;
	private Double graduationPercentage;
	private Double graduationGpa;
	private String gradGradingType;
	private Integer graduationyear;
	private String graduationUniversity;
	private String graduationCollege;
	private String pgBranch;
	private Double pgPercentage;
	private Double pgGpa;
	private Integer pgyear;
	private String pgUniversity;
	private String pgCollege;
	private String pgType;
	private String pgGradingType;
	private Integer graduationBacklog;
	private Integer pgBacklog;

	public String getSscInstitute()
	{
		return sscInstitute;
	}

	public void setSscInstitute(String sscInstitute)
	{
		this.sscInstitute = sscInstitute;
	}

	public Double getSscGpa()
	{
		return sscGpa;
	}

	public void setSscGpa(Double sscGpa)
	{
		this.sscGpa = sscGpa;
	}

	public Double getSscPercentage()
	{
		return sscPercentage;
	}

	public void setSscPercentage(Double sscPercentage)
	{
		this.sscPercentage = sscPercentage;
	}

	public String getSscBoard()
	{
		return sscBoard;
	}

	public void setSscBoard(String sscBoard)
	{
		this.sscBoard = sscBoard;
	}

	public String getSscGradingType()
	{
		return sscGradingType;
	}

	public void setSscGradingType(String sscGradingType)
	{
		this.sscGradingType = sscGradingType;
	}

	public Integer getSscyear()
	{
		return sscyear;
	}

	public void setSscyear(Integer sscyear)
	{
		this.sscyear = sscyear;
	}

	public String getInterInstitute()
	{
		return interInstitute;
	}

	public void setInterInstitute(String interInstitute)
	{
		this.interInstitute = interInstitute;
	}

	public String getInterGradingType()
	{
		return interGradingType;
	}

	public void setInterGradingType(String interGradingType)
	{
		this.interGradingType = interGradingType;
	}

	public Double getInterGpa()
	{
		return interGpa;
	}

	public void setInterGpa(Double interGpa)
	{
		this.interGpa = interGpa;
	}

	public Double getInterPercentage()
	{
		return interPercentage;
	}

	public void setInterPercentage(Double interPercentage)
	{
		this.interPercentage = interPercentage;
	}

	public String getInterBoard()
	{
		return interBoard;
	}

	public void setInterBoard(String interBoard)
	{
		this.interBoard = interBoard;
	}

	public Integer getInteryear()
	{
		return interyear;
	}

	public void setInteryear(Integer interyear)
	{
		this.interyear = interyear;
	}

	public String getGraduationType()
	{
		return graduationType;
	}

	public void setGraduationType(String graduationType)
	{
		this.graduationType = graduationType;
	}

	public String getGraduationBranch()
	{
		return graduationBranch;
	}

	public void setGraduationBranch(String graduationBranch)
	{
		this.graduationBranch = graduationBranch;
	}

	public Double getGraduationPercentage()
	{
		return graduationPercentage;
	}

	public void setGraduationPercentage(Double graduationPercentage)
	{
		this.graduationPercentage = graduationPercentage;
	}

	public Double getGraduationGpa()
	{
		return graduationGpa;
	}

	public void setGraduationGpa(Double graduationGpa)
	{
		this.graduationGpa = graduationGpa;
	}

	public String getGradGradingType()
	{
		return gradGradingType;
	}

	public void setGradGradingType(String gradGradingType)
	{
		this.gradGradingType = gradGradingType;
	}

	public Integer getGraduationyear()
	{
		return graduationyear;
	}

	public void setGraduationyear(Integer graduationyear)
	{
		this.graduationyear = graduationyear;
	}

	public String getGraduationUniversity()
	{
		return graduationUniversity;
	}

	public void setGraduationUniversity(String graduationUniversity)
	{
		this.graduationUniversity = graduationUniversity;
	}

	public String getGraduationCollege()
	{
		return graduationCollege;
	}

	public void setGraduationCollege(String graduationCollege)
	{
		this.graduationCollege = graduationCollege;
	}

	public String getPgBranch()
	{
		return pgBranch;
	}

	public void setPgBranch(String pgBranch)
	{
		this.pgBranch = pgBranch;
	}

	public Double getPgPercentage()
	{
		return pgPercentage;
	}

	public void setPgPercentage(Double pgPercentage)
	{
		this.pgPercentage = pgPercentage;
	}

	public Double getPgGpa()
	{
		return pgGpa;
	}

	public void setPgGpa(Double pgGpa)
	{
		this.pgGpa = pgGpa;
	}

	public Integer getPgyear()
	{
		return pgyear;
	}

	public void setPgyear(Integer pgyear)
	{
		this.pgyear = pgyear;
	}

	public String getPgUniversity()
	{
		return pgUniversity;
	}

	public void setPgUniversity(String pgUniversity)
	{
		this.pgUniversity = pgUniversity;
	}

	public String getPgCollege()
	{
		return pgCollege;
	}

	public void setPgCollege(String pgCollege)
	{
		this.pgCollege = pgCollege;
	}

	public String getPgType()
	{
		return pgType;
	}

	public void setPgType(String pgType)
	{
		this.pgType = pgType;
	}

	public String getPgGradingType()
	{
		return pgGradingType;
	}

	public void setPgGradingType(String pgGradingType)
	{
		this.pgGradingType = pgGradingType;
	}

	public Integer getGraduationBacklog()
	{
		return graduationBacklog;
	}

	public void setGraduationBacklog(Integer graduationBacklog)
	{
		this.graduationBacklog = graduationBacklog;
	}

	public Integer getPgBacklog()
	{
		return pgBacklog;
	}

	public void setPgBacklog(Integer pgBacklog)
	{
		this.pgBacklog = pgBacklog;
	}

}
