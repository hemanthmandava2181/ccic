package in.apssdc.security.model;

import com.andromeda.commons.model.BaseModel;

public class SkillsInfo extends BaseModel
{
	private String email;
	private String registrationId;
	private String primarySkills;
	private String otherSkills;

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public String getRegistrationId()
	{
		return registrationId;
	}

	public void setRegistrationId(String registrationId)
	{
		this.registrationId = registrationId;
	}

	public String getPrimarySkills()
	{
		return primarySkills;
	}

	public void setPrimarySkills(String primarySkills)
	{
		this.primarySkills = primarySkills;
	}

	public String getOtherSkills()
	{
		return otherSkills;
	}

	public void setOtherSkills(String otherSkills)
	{
		this.otherSkills = otherSkills;
	}

}
