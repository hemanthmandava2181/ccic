package in.apssdc.service;

import in.apssdc.security.model.Echallan;

import java.io.FileOutputStream;

import org.springframework.stereotype.Service;

import com.andromeda.commons.model.Response;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class EchallanGenerateService
{
	Response response = new Response();

	public Response createPDF(Echallan echallan)
	{
		Document doc = new Document();
		PdfWriter docWriter = null;
		String pdfFilename =
				System.getProperty("catalina.base") + "/webapps/iidtRegistration/docs/iidt_"
						+ echallan.getApssdcNumber() + ".pdf";
		try
		{
			// special font sizes
			Font bfBold12 = new Font(FontFamily.TIMES_ROMAN, 10, Font.BOLD, new BaseColor(0, 0, 0));
			Font bf12 = new Font(FontFamily.TIMES_ROMAN, 10);

			// file path
			String path = pdfFilename;
			docWriter = PdfWriter.getInstance(doc, new FileOutputStream(path));

			// document header attributes
			doc.addAuthor("APSSDC");
			doc.addCreationDate();
			doc.addProducer();
			doc.addTitle("Challan");
			doc.setPageSize(PageSize.LETTER);

			// open document
			doc.open();

			// create a paragraph
			/*
			 * Paragraph paragraph = new Paragraph("");
			 */

			// specify column widths
			float[] columnWidths = { 3f, 3f, 3f, 3f };
			// create PDF table with the given widths
			PdfPTable table = new PdfPTable(columnWidths);
			// set table width a percentage of the page width
			table.setWidthPercentage(90f);

			// insert column headings
			insertCell(table, "PAYABLE AT ANY BRANCH OF ANDHRA BANK", Element.ALIGN_CENTER, 4, bf12);
			insertCell(table, "ORIGINAL (Candidate copy)", Element.ALIGN_CENTER, 4, bf12);
			insertCell(table, "Andhra Pradesh State Skill Development Corporation",
					Element.ALIGN_CENTER, 4, bf12);
			insertCell(table, "Andhra Bank, Saifabad Branch", Element.ALIGN_CENTER, 4, bf12);
			insertCell(table, "Secretariat Road, Saifabad", Element.ALIGN_CENTER, 4, bf12);
			insertCell(table, "Hyderabad - 500004", Element.ALIGN_CENTER, 4, bf12);
			// table.setHeaderRows(1);

			// insert an empty row
			insertCell(table, "Challan ACCOUNT", Element.ALIGN_CENTER, 2, bfBold12);
			insertCell(table, "Bill COLL Details", Element.ALIGN_CENTER, 2, bfBold12);

			insertCell(table, "Current A/C", Element.ALIGN_CENTER, 1, bf12);
			insertCell(table, "053311100001440", Element.ALIGN_CENTER, 1, bf12);
			insertCell(table, "Organization", Element.ALIGN_CENTER, 1, bf12);
			insertCell(table, "GOAP", Element.ALIGN_CENTER, 1, bf12);

			insertCell(table, "IFSC Code", Element.ALIGN_CENTER, 1, bf12);
			insertCell(table, "ANDB0000533", Element.ALIGN_CENTER, 1, bf12);
			insertCell(table, "Scheme", Element.ALIGN_CENTER, 1, bf12);
			insertCell(table, "APSSDC", Element.ALIGN_CENTER, 1, bf12);

			insertCell(table, "APSSDC Number", Element.ALIGN_CENTER, 1, bf12);
			insertCell(table, echallan.getApssdcNumber(), Element.ALIGN_LEFT, 1, bf12);
			insertCell(table, "Date:", Element.ALIGN_LEFT, 2, bf12);

			insertCell(table, "Programme name:", Element.ALIGN_LEFT, 1, bf12);
			insertCell(table, echallan.getProgram(), Element.ALIGN_LEFT, 3, bfBold12);

			insertCell(table, "Name:", Element.ALIGN_LEFT, 1, bf12);
			insertCell(table, echallan.getName(), Element.ALIGN_LEFT, 3, bfBold12);

			insertCell(table, "Mobile Number", Element.ALIGN_LEFT, 1, bfBold12);
			insertCell(table, echallan.getPhone().toString(), Element.ALIGN_LEFT, 1, bfBold12);
			insertCell(table, "Registration Id", Element.ALIGN_LEFT, 1, bfBold12);
			insertCell(table, echallan.getIidtNumber(), Element.ALIGN_LEFT, 1, bfBold12);

			insertCell(table, "Details", Element.ALIGN_LEFT, 3, bfBold12);
			insertCell(table, "Amount*", Element.ALIGN_RIGHT, 1, bfBold12);

			insertCell(table, "Amount", Element.ALIGN_LEFT, 3, bfBold12);
			insertCell(table, "500/-", Element.ALIGN_RIGHT, 1, bfBold12);

			insertCell(table, "Commission", Element.ALIGN_LEFT, 3, bfBold12);
			insertCell(table, "10/-", Element.ALIGN_RIGHT, 1, bfBold12);

			insertCell(table, "Total", Element.ALIGN_RIGHT, 3, bfBold12);
			insertCell(table, "510.00/-", Element.ALIGN_RIGHT, 1, bfBold12);

			insertCell(table, "In words rupees", Element.ALIGN_LEFT, 1, bfBold12);
			insertCell(table, "FIVE HUNDRED AND TEN RUPEES ONLY", Element.ALIGN_CENTER, 3, bfBold12);

			insertCell(table, "Amount received by the Bank (in Figures)", Element.ALIGN_LEFT, 2,
					bfBold12);
			insertCell(table, "", Element.ALIGN_RIGHT, 2, bf12);

			insertCell1(table, "(Signature of the Remitter)", Element.ALIGN_CENTER, 2, bfBold12);
			insertCell1(table, "Cashier", Element.ALIGN_CENTER, 1, bfBold12);
			insertCell1(table, "Manager", Element.ALIGN_CENTER, 1, bfBold12);

			insertCell(
					table,
					"* NOTE: The Amount once paid will not be refunded back.Hence the college shall verify the particulars before making the payment.",
					Element.ALIGN_LEFT, 4, bfBold12);
			
			
			PdfPTable table1 = new PdfPTable(columnWidths);
			// set table width a percentage of the page width
			table1.setWidthPercentage(90f);

			// insert column headings
			insertCell(table1, "PAYABLE AT ANY BRANCH OF ANDHRA BANK", Element.ALIGN_CENTER, 4, bf12);
			insertCell(table1, "Duplicate (Bank copy)", Element.ALIGN_CENTER, 4, bf12);
			insertCell(table1, "Andhra Pradesh State Skill Development Corporation",
					Element.ALIGN_CENTER, 4, bf12);
			insertCell(table1, "Andhra Bank, Saifabad Branch", Element.ALIGN_CENTER, 4, bf12);
			insertCell(table1, "Secretariat Road, Saifabad", Element.ALIGN_CENTER, 4, bf12);
			insertCell(table1, "Hyderabad - 500004", Element.ALIGN_CENTER, 4, bf12);
			// table.setHeaderRows(1);

			insertCell(table1, "Challan ACCOUNT", Element.ALIGN_CENTER, 2, bfBold12);
			insertCell(table1, "Bill COLL Details", Element.ALIGN_CENTER, 2, bfBold12);

			insertCell(table1, "Current A/C", Element.ALIGN_CENTER, 1, bf12);
			insertCell(table1, "053311100001440", Element.ALIGN_CENTER, 1, bf12);
			insertCell(table1, "Organization", Element.ALIGN_CENTER, 1, bf12);
			insertCell(table1, "GOAP", Element.ALIGN_CENTER, 1, bf12);

			insertCell(table1, "IFSC Code", Element.ALIGN_CENTER, 1, bf12);
			insertCell(table1, "ANDB0000533", Element.ALIGN_CENTER, 1, bf12);
			insertCell(table1, "Scheme", Element.ALIGN_CENTER, 1, bf12);
			insertCell(table1, "APSSDC", Element.ALIGN_CENTER, 1, bf12);

			insertCell(table1, "APSSDC Number", Element.ALIGN_CENTER, 1, bf12);
			insertCell(table1, echallan.getApssdcNumber(), Element.ALIGN_LEFT, 1, bf12);
			insertCell(table1, "Date:", Element.ALIGN_LEFT, 2, bf12);

			insertCell(table1, "Programme name:", Element.ALIGN_LEFT, 1, bf12);
			insertCell(table1,  echallan.getProgram(), Element.ALIGN_LEFT, 3, bfBold12);

			insertCell(table1, "Name:", Element.ALIGN_LEFT, 1, bf12);
			insertCell(table1, echallan.getName(), Element.ALIGN_LEFT, 3, bfBold12);

			insertCell(table1, "Mobile Number", Element.ALIGN_LEFT, 1, bfBold12);
			insertCell(table1, echallan.getPhone().toString(), Element.ALIGN_LEFT, 1, bfBold12);
			insertCell(table1, "Registration Id", Element.ALIGN_LEFT, 1, bfBold12);
			insertCell(table1, echallan.getIidtNumber(), Element.ALIGN_LEFT, 1, bfBold12);

			insertCell(table1, "Details", Element.ALIGN_LEFT, 3, bfBold12);
			insertCell(table1, "Amount*", Element.ALIGN_RIGHT, 1, bfBold12);

			insertCell(table1, "Amount", Element.ALIGN_LEFT, 3, bfBold12);
			insertCell(table1, "500/-", Element.ALIGN_RIGHT, 1, bfBold12);

			insertCell(table1, "Commission", Element.ALIGN_LEFT, 3, bfBold12);
			insertCell(table1, "10/-", Element.ALIGN_RIGHT, 1, bfBold12);

			insertCell(table1, "Total", Element.ALIGN_RIGHT, 3, bfBold12);
			insertCell(table1, "510.00/-", Element.ALIGN_RIGHT, 1, bfBold12);

			insertCell(table1, "In words rupees", Element.ALIGN_LEFT, 1, bfBold12);
			insertCell(table1, "FIVE HUNDRED AND TEN RUPEES ONLY", Element.ALIGN_CENTER, 3, bfBold12);

			insertCell(table1, "Amount received by the Bank (in Figures)", Element.ALIGN_LEFT, 2,
					bfBold12);
			insertCell(table1, "", Element.ALIGN_RIGHT, 2, bf12);

			insertCell1(table1, "(Signature of the Remitter)", Element.ALIGN_CENTER, 2, bfBold12);
			insertCell1(table1, "Cashier", Element.ALIGN_CENTER, 1, bfBold12);
			insertCell1(table1, "Manager", Element.ALIGN_CENTER, 1, bfBold12);

			insertCell(
					table1,
					"* NOTE: The Amount once paid will not be refunded back.Hence the college shall verify the particulars before making the payment.",
					Element.ALIGN_LEFT, 4, bfBold12);

			// add the PDF table to the paragraph
			// paragraph.add(table);
			// add the paragraph to the document
			doc.add(table);
			doc.add(new Paragraph(""));
			doc.add(table1);
			response.setSuccessful(true);
			response.setResponseObject(path);
		}
		catch (DocumentException dex)
		{
			response.setSuccessful(false);
			dex.printStackTrace();
		}
		catch (Exception ex)
		{
			response.setSuccessful(false);
			ex.printStackTrace();
		}
		finally
		{
			if (doc != null)
			{
				// close the document
				doc.close();
			}
			if (docWriter != null)
			{
				// close the writer
				docWriter.close();
			}
		}
		return response;
	}

	private void insertCell(PdfPTable table, String text, int align, int colspan, Font font)
	{

		// create a new cell with the specified Text and Font
		PdfPCell cell = new PdfPCell(new Phrase(text.trim(), font));
		// set the cell alignment
		cell.setHorizontalAlignment(align);
		// set the cell column span in case you want to merge two or more cells
		cell.setColspan(colspan);
		// in case there is no text and you wan to create an empty row
		if (text.trim().equalsIgnoreCase(""))
		{
			cell.setMinimumHeight(10f);
		}
		// add the call to the table
		table.addCell(cell);

	}

	private void insertCell1(PdfPTable table, String text, int align, int colspan, Font font)
	{

		// create a new cell with the specified Text and Font
		PdfPCell cell = new PdfPCell(new Phrase(text.trim(), font));
		// set the cell alignment
		cell.setHorizontalAlignment(align);
		cell.setBottom((float) 20.0);
		// set the cell column span in case you want to merge two or more cells
		cell.setColspan(colspan);
		// in case there is no text and you wan to create an empty row
		cell.setMinimumHeight((float) 40.0);
		cell.setPaddingBottom((float) 20.0);
		if (text.trim().equalsIgnoreCase(""))
		{
			cell.setMinimumHeight(10f);
		}
		// add the call to the table
		table.addCell(cell);

	}

}
