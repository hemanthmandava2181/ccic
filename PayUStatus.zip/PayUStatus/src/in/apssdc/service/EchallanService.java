package in.apssdc.service;

import in.apssdc.dao.EchallanDAO;
import in.apssdc.security.model.Echallan;
import in.apssdc.security.model.Email;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.andromeda.commons.model.Response;
import com.andromeda.commons.util.CryptoUtils;
import com.andromeda.commons.util.IDGenerator;

@Service
public class EchallanService
{
	Response response = new Response();

	@Autowired
	private EchallanDAO echallanDAO;

	@Autowired
	private EmailService emailService;

	@Autowired
	private EchallanGenerateService echallanGenerateService;

	public Response add(Echallan echallan)
	{
		response.setSuccessful(false);
		Response statusOfGeneration = echallanGenerateService.createPDF(echallan);
		if (statusOfGeneration.isSuccessful())
		{
			echallan.setGuid(IDGenerator.getUniqueID()
					+ CryptoUtils.getMD5Hash(echallan.getAadhaar()));
			echallan.setChallanPath(statusOfGeneration.getResponseObject().toString());
			boolean status = echallanDAO.add(echallan);
			if (status)
			{
				echallan.setChallanPath(statusOfGeneration.getResponseObject().toString());
				Response res = mailSend(echallan);
				response.setSuccessful(res.isSuccessful());
			}
			else
			{
				response.setSuccessful(false);
				response.setErrorMessage("Challan not created!");
			}
			response.setResponseObject(echallan);
		}
		else
		{
			response.setSuccessful(false);
			response.setErrorMessage("Already Challan registered!");
			response.setResponseObject(null);
		}
		return response;
	}

	public Response mailSend(Echallan echallan)
	{
		this.response.setSuccessful(false);
		Email email = new Email();
		List<String> fileNames = new ArrayList<String>();
		fileNames.add(echallan.getChallanPath());

		String sjsonobject = echallan.getUniqueKey();
		byte[] encodedBytes = Base64.encodeBase64(sjsonobject.getBytes());
		String encryptedString = new String(encodedBytes);

		String challanSubmissionURL =
				"http://202.65.133.69:8181/echallanSubmission?q=" + encryptedString;
		String sender = "info@apssdc.in";
		email.setSubject("APSSDC");
		email.setFrom(sender);
		email.setTo(echallan.getEmail());
		email.setName("APSSDC");
		email.setAttachments(fileNames);
		email.setSignature("Andhra Pradesh State Skill Development Corporation (APSSDC)");
		String msg = "";
		msg =
				msg
						+ "Dear&nbsp;"
						+ echallan.getName()
						+ ",<br>"
						+ "<br>"
						+ "Please find & download the below attached e-challan document &nbsp;"
						+ "<br><br>"
						+ "<b>Note:</b>&nbsp;Please forward the details by the below link.&nbsp;<br><br>"
						+ challanSubmissionURL + "&nbsp;";
		email.setText(msg);
		emailService.sendHtmlMsg(email);
		this.response.setSuccessful(true);
		this.response.setResponseObject(echallan);
		return this.response;
	}

	public Response mailForOnlinePayees(Echallan echallan)
	{
		this.response.setSuccessful(false);
		Email email = new Email();

		String sjsonobject = echallan.getUniqueKey();
		byte[] encodedBytes = Base64.encodeBase64(sjsonobject.getBytes());
		String encryptedString = new String(encodedBytes);

		String challanSubmissionURL = "http://202.65.133.69:8181/payment?q=" + encryptedString;
		String sender = "info@apssdc.in";
		email.setSubject("APSSDC");
		email.setFrom(sender);
		email.setTo(echallan.getEmail());
		email.setName("APSSDC");
		email.setAttachments(null);
		email.setSignature("Andhra Pradesh State Skill Development Corporation (APSSDC)");
		String msg = "";
		msg =
				msg
						+ "Dear&nbsp;"
						+ echallan.getName()
						+ ",<br>"
						+ "<br>"
						+ "Please find the below link for online payment &nbsp;"
						+ "<br><br>"
						+ challanSubmissionURL + "&nbsp;";
		email.setText(msg);
		emailService.sendHtmlMsg(email);
		this.response.setSuccessful(true);
		this.response.setResponseObject(echallan);
		return this.response;
	}

}
