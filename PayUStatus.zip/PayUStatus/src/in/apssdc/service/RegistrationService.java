package in.apssdc.service;

import in.apssdc.dao.RegistrationDAO;
import in.apssdc.security.model.Payment;
import in.apssdc.security.model.Registration;

import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.andromeda.commons.model.Response;

@Service
public class RegistrationService
{
	Response response = new Response();

	@Autowired
	private RegistrationDAO registrationDAO;

	@Autowired
	private EmailService emailService;

	public Response add(Registration registration)
	{
		response.setSuccessful(false);
		boolean status = registrationDAO.checkUser(registration.getPersonalInfo());
		if (!status)
		{
			String iidtNumber = registrationDAO.getIIDTNumber();
			registration.getPersonalInfo().setIidtRegistrationNo(iidtNumber);
			Response res = registrationDAO.add(registration);
			if (res.isSuccessful())
			{
				response.setSuccessful(res.isSuccessful());
				response.setResponseObject(res);
			}
			else
			{
				response.setSuccessful(false);
			}

		}
		else
		{
			response.setSuccessful(false);
			response.setErrorMessage("You have already registered!");
			response.setResponseObject(registration);
		}
		return response;
	}

	public Response getMailIdByCode(String q)
	{
		response.setSuccessful(false);
		byte[] decodedBytes = Base64.decodeBase64(q);
		String s = new String(decodedBytes);
		Map<String, Object> bi = registrationDAO.getMailIdByCode(s);
		if (bi != null)
		{
			response.setSuccessful(true);
			response.setResponseObject(bi);
		}
		else
		{
			response.setSuccessful(false);
			response.setErrorMessage("Details not updated!");
			response.setResponseObject(null);
		}
		return response;
	}

	public Response paymentOption(Payment payment)
	{
		response.setSuccessful(false);
		Response res = registrationDAO.paymentOption(payment);
		if (res.isSuccessful())
		{
			response.setSuccessful(res.isSuccessful());
			response.setErrorMessage("Please check your mail for payment!");
			response.setResponseObject(res);
		}
		else
		{
			response.setSuccessful(false);
			response.setErrorMessage("Link expired!");
		}
		return response;
	}

}
