package in.apssdc.controller;

import in.apssdc.security.model.Payment;
import in.apssdc.security.model.PersonalInfo;
import in.apssdc.security.model.Registration;
import in.apssdc.service.RegistrationService;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.andromeda.commons.model.Response;
import com.andromeda.commons.util.HttpUtils;

@RestController
@RequestMapping("/registration")
public class RegistrationController
{
	Response response = new Response();
	
	@Autowired
	private RegistrationService registrationService;

	@ResponseBody
	@RequestMapping(value = "home", method = { RequestMethod.GET, RequestMethod.POST })
	public Response getMailIdByCode(@RequestBody String q)
	{
		response = registrationService.getMailIdByCode(q);
		return response;
	}
	
	@ResponseBody
	@RequestMapping(value = "add", method = { RequestMethod.GET, RequestMethod.POST })
	public Response add(@RequestBody Registration registration, HttpServletRequest httpServletRequest)
	{
		PersonalInfo personalInfo = new PersonalInfo();
		String clientProxyIp = HttpUtils.getClientProxyAddress(httpServletRequest);
		String clientIp = HttpUtils.getClientAddress(httpServletRequest);
		String ipAddress = "CLIENT:" + clientIp + ", CLIENT_PROXY:" + clientProxyIp;
		registration.getPersonalInfo().setIpAddress(ipAddress);
		personalInfo.setIpAddress(ipAddress);
		return registrationService.add(registration);
	}
	
	@ResponseBody
	@RequestMapping(value = "paymentOption", method = { RequestMethod.GET, RequestMethod.POST })
	public Response paymentOption(@RequestBody Payment payment)
	{
		return registrationService.paymentOption(payment);
	}

}
