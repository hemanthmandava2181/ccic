package in.apssdc.dao;

import in.apssdc.security.model.Echallan;

import java.util.HashMap;
import java.util.Map;

import com.andromeda.commons.dao.BaseDAO;

public class EchallanDAO extends BaseDAO
{

	public boolean add(Echallan echallan)
	{
		boolean status = false;
		int count = 0;
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("p", echallan);
		count = sqlSessionTemplate.insert("Echallan.add", params);
		if (count != 0)
		{
			status = true;
		}
		else
		{
			status = false;
		}
		return status;
	}

}
