package in.apssdc.dao;

import in.apssdc.security.model.BasicInfo;
import in.apssdc.security.model.Echallan;
import in.apssdc.security.model.Payment;
import in.apssdc.security.model.PersonalInfo;
import in.apssdc.security.model.Registration;
import in.apssdc.service.EchallanService;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.andromeda.commons.dao.BaseDAO;
import com.andromeda.commons.model.Response;

public class RegistrationDAO extends BaseDAO
{
	@Autowired
	private EchallanService echallanService;

	public Response add(Registration registration)
	{
		Response res = new Response();
		int p;
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("p", registration.getPersonalInfo());
		params.put("e", registration.getEducationInfo());
		p = sqlSessionTemplate.insert("Registration.add", params);
		if (p != 0)
		{
			res.setSuccessful(true);
		}
		else
		{
			res.setSuccessful(false);
		}
		return res;
	}

	public boolean checkUser(PersonalInfo personalInfo)
	{
		boolean subscriberStatus = false;
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("p", personalInfo);
		// count = sqlSessionTemplate.selectOne("Registration.checkUser", params);
		int i = sqlSessionTemplate.selectOne("Registration.checkUserFromAllDetails", params);
		if (i != 0)
		{
			subscriberStatus = true;
		}
		else
		{
			subscriberStatus = false;
		}
		return subscriberStatus;
	}

	public Map<String, Object> getMailIdByCode(String q)
	{
		PersonalInfo personalInfo = null;
		Map<String, Object> map = new HashMap<String, Object>();
		// int count = sqlSessionTemplate.selectOne("Registration.getMailCount", q);
		BasicInfo data = sqlSessionTemplate.selectOne("Registration.getMailId", q);
		if (data != null)
		{
			int count =
					sqlSessionTemplate.selectOne("Registration.checkRegistrations",
							data.getAadhaar());
			if (count != 0)
			{
				personalInfo =
						sqlSessionTemplate.selectOne("Registration.getStatus", data.getAadhaar());
				map.put("basicData", data);
				map.put("allData", personalInfo);
			}
			else
			{
				personalInfo = null;
				map.put("basicData", data);
				map.put("allData", personalInfo);
			}
		}
		else
		{
			map = null;
		}
		return map;
	}

	public Response paymentOption(Payment payment)
	{
		Response response = new Response();
		response.setSuccessful(false);
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("p", payment);
		int i = sqlSessionTemplate.insert("Registration.updatePaymentOption", params);
		if (i != 0)
		{
			Echallan echallan = sqlSessionTemplate.selectOne("Registration.getAll", params);
			echallan.setUniqueKey(payment.getUniqueKey());
			String program =
					sqlSessionTemplate.selectOne("Registration.getProgram", echallan.getJobid());
			echallan.setProgram(program);
			if (payment.getPaymentOption().equals("challan"))
			{
				Response respon = echallanService.add(echallan);
				response.setSuccessful(respon.isSuccessful());
			}
			else
			{
				Response respon = echallanService.mailForOnlinePayees(echallan);
				response.setSuccessful(respon.isSuccessful());
			}
		}
		return response;
	}

	public String getIIDTNumber()
	{
		String iidtNum = sqlSessionTemplate.selectOne("Registration.getIIDTNo");
		return iidtNum;
	}

}
