var paymentSuccessModule = angular.module('paymentSuccessModule', [])
.controller('formController', ['$scope','$http',function($scope,$http)
{
	var base64String = Andromeda.getSessionValue("Base64String");
	/*var jsonStr = window.atob(base64String);
	var jsonObj = JSON.parse(jsonStr);*/
	
	/*console.log(jsonObj);
	console.log(jsonObj['studentList']);
	console.log(jsonObj['studentList'][0]['trainingProgramName']);*/
	
	var txnId = $("#txnId").html();
	
	var statusId = $("#statusId").html();
	
	//$("#courseId").html(jsonObj['studentList'][0]['trainingProgramName']);
	
	var details = 
		{
			studentDetails : base64String,
			txnId : txnId,
			status : statusId,
			mode : $("#modeId").html(),
			mihId : $("#mihId").html()
		};
	
	console.log(details);
	
	$http.post('/paymentStatus/paymentSuccessStatus', details).then(function(response){
		$scope.data = response.data;
		if($scope.data.successful)
		{
			console.log("Success");
		}
		else
		{
			console.log("Client error while saving data");
		}
	},
	function(response)
	{
		console.log("Server error while saving data");
	});
	
}]);