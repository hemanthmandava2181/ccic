package in.apssdc.security.model;

import java.util.List;

import com.andromeda.commons.model.BaseModel;

public class StudentList extends BaseModel
{
	private List<Student> studentList;

	public List<Student> getStudentList()
	{
		return studentList;
	}

	public void setStudentList(List<Student> studentList)
	{
		this.studentList = studentList;
	}

}
