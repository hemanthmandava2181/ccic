package in.apssdc.security.model;

import com.andromeda.commons.model.BaseModel;

public class PayUMoney extends BaseModel
{
	private String txnType;
	private Integer collegeid;
	private String collegename;
	private Integer trainingprogramid;
	private String trainingprogramname;
	private Integer programid;
	private String programname;
	private String year;
	private Integer trainingBatchId;
	private String course;
	private String mihpayid;
	private String mode;
	private String status;
	private String unmappedstatus;
	private String key;
	private String txnid;
	private String amount;
	private String cardCategory;
	private String discount;
	private String net_amount_debit;
	private String addedon;
	private String productinfo;
	private String firstname;
	private String lastname;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String country;
	private String zipcode;
	private String email;
	private String phone;
	private String hash;
	private String payment_source;
	private String PG_TYPE;
	private String bank_ref_num;
	private String bankcode;
	private String error;
	private String error_Message;
	private String name_on_card;
	private String cardnum;
	private String cardhash;
	private String issuing_bank;
	private String card_type;
	private String ipAddress;
	private String udf1;
	private String udf2;
	private String udf3;
	private String udf4;
	private String url;
	private String name;
	private String centerId;
	private String courseId;     
	private String center;   
	private String coecoursecode;
	private String coecenterid;
	private String tsdicourseid;
	private String tsdicenterid;   
	private String trainingId;
	private String guid;
	private String applicationid;
	
	public String getTrainingId() {
		return trainingId;
	}

	public void setTrainingId(String trainingId) {
		this.trainingId = trainingId;
	}

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getTsdicourseid() {
		return tsdicourseid;
	}

	public void setTsdicourseid(String tsdicourseid) {
		this.tsdicourseid = tsdicourseid;
	}

	public String getTsdicenterid() {
		return tsdicenterid;
	}

	public void setTsdicenterid(String tsdicenterid) {
		this.tsdicenterid = tsdicenterid;
	}

	public String getCenter() {
		return center;
	}

	public void setCenter(String center) {
		this.center = center;
	}

	public String getCoecoursecode() {
		return coecoursecode;
	}

	public void setCoecoursecode(String coecoursecode) {
		this.coecoursecode = coecoursecode;
	}

	public String getCoecenterid() {
		return coecenterid;
	}

	public void setCoecenterid(String coecenterid) {
		this.coecenterid = coecenterid;
	}

	public String getCenterId() {
		return centerId;
	}

	public void setCenterId(String centerId) {
		this.centerId = centerId;
	}

	public String getCourseId() {
		return courseId;
	}

	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getUrl()
	{
		return url;
	}

	public void setUrl(String url)
	{
		this.url = url;
	}

	public String getTxnType()
	{
		return txnType;
	}

	public void setTxnType(String txnType)
	{
		this.txnType = txnType;
	}

	public Integer getCollegeid()
	{
		return collegeid;
	}

	public void setCollegeid(Integer collegeid)
	{
		this.collegeid = collegeid;
	}

	public String getCollegename()
	{
		return collegename;
	}

	public void setCollegename(String collegename)
	{
		this.collegename = collegename;
	}

	public Integer getTrainingprogramid()
	{
		return trainingprogramid;
	}

	public void setTrainingprogramid(Integer trainingprogramid)
	{
		this.trainingprogramid = trainingprogramid;
	}

	public String getTrainingprogramname()
	{
		return trainingprogramname;
	}

	public void setTrainingprogramname(String trainingprogramname)
	{
		this.trainingprogramname = trainingprogramname;
	}

	public Integer getProgramid()
	{
		return programid;
	}

	public void setProgramid(Integer programid)
	{
		this.programid = programid;
	}

	public String getProgramname()
	{
		return programname;
	}

	public void setProgramname(String programname)
	{
		this.programname = programname;
	}

	public Integer getTrainingBatchId()
	{
		return trainingBatchId;
	}

	public void setTrainingBatchId(Integer trainingBatchId)
	{
		this.trainingBatchId = trainingBatchId;
	}

	public String getYear()
	{
		return year;
	}

	public void setYear(String year)
	{
		this.year = year;
	}

	public String getCourse()
	{
		return course;
	}

	public void setCourse(String course)
	{
		this.course = course;
	}

	public String getUdf4()
	{
		return udf4;
	}

	public void setUdf4(String udf4)
	{
		this.udf4 = udf4;
	}

	public String getUdf3()
	{
		return udf3;
	}

	public void setUdf3(String udf3)
	{
		this.udf3 = udf3;
	}

	public String getUdf1()
	{
		return udf1;
	}

	public void setUdf1(String udf1)
	{
		this.udf1 = udf1;
	}

	public String getUdf2()
	{
		return udf2;
	}

	public void setUdf2(String udf2)
	{
		this.udf2 = udf2;
	}

	public String getIpAddress()
	{
		return ipAddress;
	}

	public void setIpAddress(String ipAddress)
	{
		this.ipAddress = ipAddress;
	}

	public String getMihpayid()
	{
		return mihpayid;
	}

	public void setMihpayid(String mihpayid)
	{
		this.mihpayid = mihpayid;
	}

	public String getMode()
	{
		return mode;
	}

	public void setMode(String mode)
	{
		this.mode = mode;
	}

	public String getStatus()
	{
		return status;
	}

	public void setStatus(String status)
	{
		this.status = status;
	}

	public String getUnmappedstatus()
	{
		return unmappedstatus;
	}

	public void setUnmappedstatus(String unmappedstatus)
	{
		this.unmappedstatus = unmappedstatus;
	}

	public String getKey()
	{
		return key;
	}

	public void setKey(String key)
	{
		this.key = key;
	}

	public String getTxnid()
	{
		return txnid;
	}

	public void setTxnid(String txnid)
	{
		this.txnid = txnid;
	}

	public String getAmount()
	{
		return amount;
	}

	public void setAmount(String amount)
	{
		this.amount = amount;
	}

	public String getCardCategory()
	{
		return cardCategory;
	}

	public void setCardCategory(String cardCategory)
	{
		this.cardCategory = cardCategory;
	}

	public String getDiscount()
	{
		return discount;
	}

	public void setDiscount(String discount)
	{
		this.discount = discount;
	}

	public String getNet_amount_debit()
	{
		return net_amount_debit;
	}

	public void setNet_amount_debit(String net_amount_debit)
	{
		this.net_amount_debit = net_amount_debit;
	}

	public String getAddedon()
	{
		return addedon;
	}

	public void setAddedon(String addedon)
	{
		this.addedon = addedon;
	}

	public String getProductinfo()
	{
		return productinfo;
	}

	public void setProductinfo(String productinfo)
	{
		this.productinfo = productinfo;
	}

	public String getFirstname()
	{
		return firstname;
	}

	public void setFirstname(String firstname)
	{
		this.firstname = firstname;
	}

	public String getLastname()
	{
		return lastname;
	}

	public void setLastname(String lastname)
	{
		this.lastname = lastname;
	}

	public String getAddress1()
	{
		return address1;
	}

	public void setAddress1(String address1)
	{
		this.address1 = address1;
	}

	public String getAddress2()
	{
		return address2;
	}

	public void setAddress2(String address2)
	{
		this.address2 = address2;
	}

	public String getCity()
	{
		return city;
	}

	public void setCity(String city)
	{
		this.city = city;
	}

	public String getState()
	{
		return state;
	}

	public void setState(String state)
	{
		this.state = state;
	}

	public String getCountry()
	{
		return country;
	}

	public void setCountry(String country)
	{
		this.country = country;
	}

	public String getZipcode()
	{
		return zipcode;
	}

	public void setZipcode(String zipcode)
	{
		this.zipcode = zipcode;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public String getPhone()
	{
		return phone;
	}

	public void setPhone(String phone)
	{
		this.phone = phone;
	}

	public String getHash()
	{
		return hash;
	}

	public void setHash(String hash)
	{
		this.hash = hash;
	}

	public String getPayment_source()
	{
		return payment_source;
	}

	public void setPayment_source(String payment_source)
	{
		this.payment_source = payment_source;
	}

	public String getPG_TYPE()
	{
		return PG_TYPE;
	}

	public void setPG_TYPE(String pG_TYPE)
	{
		PG_TYPE = pG_TYPE;
	}

	public String getBank_ref_num()
	{
		return bank_ref_num;
	}

	public void setBank_ref_num(String bank_ref_num)
	{
		this.bank_ref_num = bank_ref_num;
	}

	public String getBankcode()
	{
		return bankcode;
	}

	public void setBankcode(String bankcode)
	{
		this.bankcode = bankcode;
	}

	public String getError()
	{
		return error;
	}

	public void setError(String error)
	{
		this.error = error;
	}

	public String getError_Message()
	{
		return error_Message;
	}

	public void setError_Message(String error_Message)
	{
		this.error_Message = error_Message;
	}

	public String getName_on_card()
	{
		return name_on_card;
	}

	public void setName_on_card(String name_on_card)
	{
		this.name_on_card = name_on_card;
	}

	public String getCardnum()
	{
		return cardnum;
	}

	public void setCardnum(String cardnum)
	{
		this.cardnum = cardnum;
	}

	public String getCardhash()
	{
		return cardhash;
	}

	public void setCardhash(String cardhash)
	{
		this.cardhash = cardhash;
	}

	public String getIssuing_bank()
	{
		return issuing_bank;
	}

	public void setIssuing_bank(String issuing_bank)
	{
		this.issuing_bank = issuing_bank;
	}

	public String getCard_type()
	{
		return card_type;
	}

	public void setCard_type(String card_type)
	{
		this.card_type = card_type;
	}

	public String getApplicationid() {
		return applicationid;
	}

	public void setApplicationid(String applicationid) {
		this.applicationid = applicationid;
	}

}
