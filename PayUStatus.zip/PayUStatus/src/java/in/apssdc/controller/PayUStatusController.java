package in.apssdc.controller;

import in.apssdc.security.model.PayUMoney;
import in.apssdc.security.model.Student;
import in.apssdc.service.PayUStatusService;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.andromeda.commons.model.Response;
import com.andromeda.commons.util.HttpUtils;

@Controller
public class PayUStatusController
{
	Response response = new Response();
  
	@Autowired  
	private PayUStatusService payUStatusService;
   
	@ResponseBody      
	@RequestMapping(value = "status", method = { RequestMethod.POST },
			produces = MediaType.TEXT_HTML_VALUE)
	public String getPayUStatusObject(HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) throws IOException, JSONException
	{
		httpServletResponse.setContentType("text/html");
		PayUMoney payUMoney = new PayUMoney();
		payUMoney.setMihpayid(httpServletRequest.getParameter("mihpayid"));  
		payUMoney.setEmail(httpServletRequest.getParameter("email"));
		payUMoney.setFirstname(httpServletRequest.getParameter("name"));
		payUMoney.setAmount(httpServletRequest.getParameter("amount"));
		payUMoney.setCardnum(httpServletRequest.getParameter("cardnum"));
		payUMoney.setCardCategory(httpServletRequest.getParameter("cardCategory"));
		payUMoney.setMode(httpServletRequest.getParameter("mode"));
		payUMoney.setTxnid(httpServletRequest.getParameter("txnid"));
		payUMoney.setStatus(httpServletRequest.getParameter("status"));   
		payUMoney.setKey(httpServletRequest.getParameter("key"));  
		payUMoney.setPG_TYPE(httpServletRequest.getParameter("PG_TYPE"));
		payUMoney.setAddedon(httpServletRequest.getParameter("addedon"));
		payUMoney.setBank_ref_num(httpServletRequest.getParameter("bank_ref_num"));
		payUMoney.setNet_amount_debit(httpServletRequest.getParameter("net_amount_debit"));
		payUMoney.setName_on_card(httpServletRequest.getParameter("name_on_card"));
		payUMoney.setIssuing_bank(httpServletRequest.getParameter("issuing_bank"));
		payUMoney.setProductinfo(httpServletRequest.getParameter("productinfo"));
		payUMoney.setPhone(httpServletRequest.getParameter("phone"));
		payUMoney.setPayment_source(httpServletRequest.getParameter("payment_source"));
		payUMoney.setHash(httpServletRequest.getParameter("hash"));
		payUMoney.setError_Message(httpServletRequest.getParameter("error_Message"));
		payUMoney.setError(httpServletRequest.getParameter("error"));
		payUMoney.setDiscount(httpServletRequest.getParameter("discount"));
		payUMoney.setUnmappedstatus(httpServletRequest.getParameter("unmappedstatus"));
		payUMoney.setAddedon(httpServletRequest.getParameter("addedon"));
		payUMoney.setUdf1(httpServletRequest.getParameter("udf1"));
		payUMoney.setUdf2(httpServletRequest.getParameter("udf2"));
		payUMoney.setUdf3(httpServletRequest.getParameter("udf3"));
		payUMoney.setUdf4(httpServletRequest.getParameter("udf4"));   
		String clientProxyIp = HttpUtils.getClientProxyAddress(httpServletRequest);
		String clientIp = HttpUtils.getClientAddress(httpServletRequest);
		String ipAddress = "CLIENT:" + clientIp + ", CLIENT_PROXY:" + clientProxyIp;
		payUMoney.setIpAddress(ipAddress);
		/*PrintWriter out = httpServletResponse.getWriter();
		out.println("PayUMoney Details:"+payUMoney);
		*/  
		Response res = payUStatusService.add(payUMoney);      
		System.out.println(res.getResponseObject());  
		return res.getResponseObject().toString();   
	}    
    
	@ResponseBody
	@RequestMapping(value = "paymentSuccessStatus", method = { RequestMethod.POST })
	public Response paymentSuccessStatus(@RequestBody Student student,
			HttpServletRequest httpServletRequest) throws JSONException     
	{
		String clientProxyIp = HttpUtils.getClientProxyAddress(httpServletRequest);
		String clientIp = HttpUtils.getClientAddress(httpServletRequest);
		String ipAddress = "CLIENT:" + clientIp + ", CLIENT_PROXY:" + clientProxyIp;
		student.setIpAddress(ipAddress);
		return payUStatusService.paymentSuccessStatus(student);
	}
}