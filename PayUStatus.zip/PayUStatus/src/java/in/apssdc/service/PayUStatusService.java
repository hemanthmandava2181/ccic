package in.apssdc.service;

import java.io.IOException;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.andromeda.commons.model.Response;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;
import freemarker.template.Version;
import in.apssdc.dao.PayUStatusDAO;
import in.apssdc.security.model.Email;
import in.apssdc.security.model.PayUMoney;
import in.apssdc.security.model.Student;

@Service
public class PayUStatusService
{
	@Autowired
	private PayUStatusDAO payUStatusDAO;
  
	@Autowired
	private EmailService emailService;

	public Response add(PayUMoney payUMoney) throws JSONException, JsonParseException, JsonMappingException, IOException
	{
		Response response = new Response();   
		response.setSuccessful(false);
		/*String course = payUStatusDAO.getCoursename(payUMoney.getUdf2());
		payUMoney.setCourse(course);
		String center = payUStatusDAO.getCentername(payUMoney.getUdf3());
		payUMoney.setCenter(center);*/
		boolean status = payUStatusDAO.add(payUMoney);               
   
		
  
		// Prepare input
		Map<String, Object> input = new HashMap<String, Object>();
		input.put("payUMoney", payUMoney);

		if (status)
		{
			if (payUMoney.getStatus().equals("success"))   
			{
				   
				Response re = SuccessMailSend(payUMoney);
				//Response res = SuccessMailSendInfo(payUMoney);
				response.setSuccessful(re.isSuccessful());
				String mes = "<html><head>" + "<script src='/ccic/js/Andromeda.js'></script>"
						+ "<script src='/ccic/js/angular.js'></script>"
						+ "<script src='/siemensPaymentStatus/scripts/common/paymentSuccessModule.js'></script>"
						+ "</head><body id='paymentSuccessDiv' data-ng-controller='formController'>"
						+ "<h1>Payment Success</h1>" + "<label>Name: </label>" + payUMoney.getName() + "<br>"
						+ "<br><label>Transaction Id: </label>" + "<label id='txnId'>" + payUMoney.getTxnid()
						+ "</label>" + "<br><label>Pay U Id: </label>" + "<label id='mihId'>" + payUMoney.getMihpayid()
						+ "</label>" + "<br><label>Amount: </label>" + payUMoney.getAmount()
						+ "<br><label>Mode: </label>" + "<label id='modeId'>" + payUMoney.getMode() + "</label>"
						+ "<br><label>Payment status: </label>" + "<label id='statusId'>" + payUMoney.getStatus()
						+ "</label>"   
						// +
						// "<br><label>Note*: </label>Hall ticket will be send to your registered
						// email id! Thank you"
						+ "</body>" + "<script type='text/javascript'>" + "jQuery(document).ready(function()" + "{"
						+ "angular.bootstrap(jQuery('#paymentSuccessDiv'), ['paymentSuccessModule']);" + "});"
						+ "</script></html>";
				response.setResponseObject(mes);
			} else {
				Response rs = FailureMailSend(payUMoney);
				response.setSuccessful(rs.isSuccessful());
				String mes = "<html><body><h1>Payment Failed! Try again</h1></body></html>";
				response.setResponseObject(mes);
			}
		} else {
			response.setSuccessful(false);
			response.setErrorMessage("Payment Error!");
			String mes = "<html><body><h1>Payment Error!</h1></body></html>";
			response.setResponseObject(mes);
		}
		return response;
	}   

	public Response SuccessMailSend(PayUMoney payUMoney)
	{
		Response response = new Response();
		response.setSuccessful(false);
		Email email = new Email();

		String sender = "SBTET <joinus@apssdc.in>";
		email.setSubject("CCIC - Certificate Fee Payment " + payUMoney.getStatus());
		email.setFrom(sender);
		email.setTo(payUMoney.getEmail());   
		// email.setCc("mruduladevi.n@apssdc.in");
		// email.setCc("sulochana.c@apssdc.in");     
		//email.setTo("ravi510.a@gmail.com");
		email.setName("APSSDC");   
		email.setAttachments(null);
		email.setSignature("Andhra Pradesh State Board of Technical Education(APSBTET)");
		String msg = "";
		msg = msg + "Dear&nbsp;" + payUMoney.getName() + ",<br><br>"  
				+ "You have successfully completed payment" + "<br><br>" + "<b>Center:</b>&nbsp;"
				
				+ payUMoney.getCourseId() + "&nbsp;<br><br>" + "<b>Pay U Id:</b>&nbsp;"
				+ payUMoney.getMihpayid() + "&nbsp;<br><br>" + "<b>Transaction Id:</b>&nbsp;"
				+ payUMoney.getTxnid() + "&nbsp;<br><br>" + "<b>Name:</b>&nbsp;"
				+ payUMoney.getName() + "&nbsp;<br><br>" + "<b>Mode:</b>&nbsp;"
				+ payUMoney.getMode() + "&nbsp;<br><br>" + "<b>Amount:</b>&nbsp;"
				+ payUMoney.getNet_amount_debit() + "&nbsp;<br><br>"
				// + "<b>Note:</b>&nbsp;We will send the hall ticket soon. &nbsp;<br><br>"
				+ "&nbsp;";
		email.setText(msg);
		emailService.sendHtmlMsg(email);
		response.setSuccessful(true);
		response.setResponseObject(payUMoney);
		return response;
	}

	public Response mailSendSuccessi2E(PayUMoney studentSubscribeModel)
	{
		Response response = new Response();
		Email email = new Email();
		/*
		 * String fileName = System.getProperty("catalina.base") + "/webapps/hallticket/LatestPDF/"
		 * + registrationEnquiry.getHallTicketNo() + ".pdf"; response.setSuccessful(false);
		 * 
		 * List<String> fileAttachments = new ArrayList<String>(); fileAttachments.add(fileName);
		 */
		String sender = "SBTET <joinus@apssdc.in>";
		email.setSubject("SBTET: CCIC Certificate Fee Payment Pending");
		email.setFrom(sender);
		email.setTo(studentSubscribeModel.getEmail().trim());
		// email.setTo("ravi510.a@gmail.com");
		email.setName("SBTET");
		email.setSignature("Andhra Pradesh State Board of Technical Education(APSBTET)");
		// email.setAttachments(fileAttachments);
		String msg = "";
		msg = msg + "Dear&nbsp;" + studentSubscribeModel.getName() + ",<br><br>"
				+ "Thanks for showing interest and registering for the Basics in Entrepreneurship program recently announced by the <b>International Institute for Entrepreneurship Development (i2E)</b>."
				+ "<br><br>"
				+ "Phase I is mostly online learning with a few sessions requiring in-person attendance. The requirement of an aptitude test has been removed, but you will be required to fill out an aptitude assessment form, which will be used, along with the progress you make in Phase I (Certificate in Basics of Entrepreneurship), to determine eligibility for entry into Phase II (Diploma in Venture Development), which will commence in December."
				+ "<br><br>"
				+ "We are making preparations for the launch of Phase I, and will communicate the commencement of classes in the very near future. In the meantime, please make arrangements to pay the Phase I tuition fee of INR 10,000.<br><br>"
				+ "<b>Please use the following payment gateway link to submit your payment:</b><br>"
				+ " <a href='" + studentSubscribeModel.getUrl() + "'>"
				+ studentSubscribeModel.getUrl() + "</a>" + "<br><br>"
				+ "For more details, Please visit: <a href='http://i2e.apssdc.in' target='new'>http://i2e.apssdc.in</a> <br><br>"
				+ "<b>If you have any questions regarding the program, please use the following link (Contact Us Tab):</b> <a href='http://i2e.apssdc.in' target='new'>http://i2e.apssdc.in</a> <b>, to submit them, and one of our i2E representatives will contact you: Email:</b> i2e@apssdc.in <br><br>"
				+ "Please ignore this mail, if you have completed the payment process already.<br><br>"
				+ "<b>All the best!</b><br><br>" + "" + "&nbsp;";

		email.setText(msg);
		emailService.sendHtmlMsg(email);  
		// response.setSuccessful(res);
		response.setResponseObject(studentSubscribeModel);
		return response;
	}

	public Response FailureMailSend(PayUMoney payUMoney)
	{
		Response response = new Response();
		response.setSuccessful(false);
		Email email = new Email();  
		String sender = "CCIC <joinus@apssdc.in>";
		email.setSubject("SBTET - CCIC Certificate Fee Payment " + payUMoney.getStatus());
		email.setFrom(sender);
		email.setTo(payUMoney.getEmail());
		// email.setTo("ravi510.a@gmail.com");
		email.setName("SBTET");   
		email.setAttachments(null);
		email.setSignature("Andhra Pradesh State Board of Technical Education(APSBTET)");
		String msg = "";
		msg = msg + "Dear&nbsp;" + payUMoney.getName() + ",<br><br>"
				+ "We regret for the inconvenience caused to you during the Payment.<br><br>"
				+ "Due to technical problem, payment process failed! Please try again after some time.&nbsp;<br><br>"
				+ "<b>All the best!</b>" + "<br>" + "&nbsp;";
		email.setText(msg);
		emailService.sendHtmlMsg(email);
		response.setSuccessful(true);   
		response.setResponseObject(payUMoney);
		return response;      
	}          

	public Response paymentSuccessStatus(Student student) throws JSONException
	{
		Response response = new Response();
		response.setSuccessful(false);
		payUStatusDAO.paymentSuccessStatus(student);
		response.setSuccessful(true);
		return response;  
	}
}