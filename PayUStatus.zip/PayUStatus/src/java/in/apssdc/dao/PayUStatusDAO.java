package in.apssdc.dao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.andromeda.commons.dao.BaseDAO;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import in.apssdc.security.model.PayUMoney;
import in.apssdc.security.model.Student;
import in.apssdc.security.model.StudentList;

public class PayUStatusDAO extends BaseDAO
{
	public static final ObjectMapper mapper = new ObjectMapper();

	PayUMoney paymentDetails = new PayUMoney();
   
	/*public boolean updateCourseFee(PayUMoney payUMoney)
	{   
		if(payUMoney.getStatus().equalsIgnoreCase("success"))
		{
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("p", payUMoney);
			if (payUMoney.getAmount().equalsIgnoreCase("10000.00")
					&& payUMoney.getTrainingprogramid() == 93)
			{
				sqlSessionTemplate.update("PayUStatus.updateCourseFee", params);
			}
			else if (payUMoney.getAmount().equalsIgnoreCase("2.00")
					&& payUMoney.getTrainingprogramid() == 93)
			{
				sqlSessionTemplate.update("PayUStatus.updateRegistrationFee", params);
			}
		}   
		return true;      
	}   */

	public Boolean add(PayUMoney payUMoney) throws JSONException, JsonParseException, JsonMappingException, IOException
	{
		/*System.out.println("--> PayU Response DAO");
		System.out.println(payUMoney);*/
		boolean status = false; int p;
		paymentDetails = payUMoney;
		Map<String, Object> params = new HashMap<String, Object>();
		
			payUMoney.setTxnType("BULK");   
			params.put("p", payUMoney);
			String studentList = sqlSessionTemplate.selectOne("PayUStatus.getStudentList", params);
			Student student = new Student();
			student.setStudentDetails(studentList);     
			paymentSuccessStatus(student);            
			sqlSessionTemplate.insert("PayUStatus.addToTransactions", params);
			boolean checkStatus = checkStatus(params);
			if (checkStatus) {  
				status = true; 
				byte[] byteArr = Base64.decodeBase64(student.getStudentDetails());
				String str = new String(byteArr);  
				JSONObject jsonObject = new JSONObject(str);  
				List<JSONObject> list = new ArrayList<JSONObject>();
				JSONArray array = new JSONArray(jsonObject.get("studentList").toString());
				for (int i = 0; i < array.length(); i++)
				{
					list.add(array.getJSONObject(i));
				}
				Iterator<JSONObject> i = list.iterator();
				while (i.hasNext())
				{
					JSONObject jsonObj = i.next();
					Student studentDetails = new Student();					
					
					//studentDetails.setCourseid(jsonObj.getString("aadhaar"));      
					studentDetails.setName(jsonObj.getString("name"));
					//studentDetails.setEmail(jsonObj.getString("email"));
					//studentDetails.setPhone(jsonObj.getString("phoneno"));
					studentDetails.setApplicationid(jsonObj.getString("applicationid"));  			
					//studentDetails.setHighestQualification(jsonObj.getString("highestqualification"));
					studentDetails.setInstituteid(paymentDetails.getUdf2());
					studentDetails.setCourseid(paymentDetails.getUdf1()); 
					Map<String, Object> map = new HashMap<String, Object>();
					map.put("p", studentDetails);
					int successStatus = sqlSessionTemplate.update("PayUStatus.updateStudentPayment", map);
					if (successStatus != 0)  
					{
						status = true;
					}
					else    
					{
						status = false;
					}
				
				}
			}
			else {
				
				status = false;
			}
		
		return status;   
	}

	public static <T> StudentList readFromString(String data, Class<StudentList> class1)
			throws JsonParseException, JsonMappingException, IOException
	{
		return mapper.readValue(data, class1);
	}

	public Boolean checkStatus(Map<String, Object> params)
	{
		boolean status = false;
		int i = sqlSessionTemplate.selectOne("PayUStatus.getRecord", params);  
		if (i != 0)    
		{
			status = true;
		}
		else
		{   
			status = false;
		}
		return status;    
	}

	public void paymentSuccessStatus(Student student) throws JSONException
	{
		System.out.println("--> Student data to check");
		System.out.println(student);
		System.out.println(student.getStudentDetails());     
		byte[] byteArr = Base64.decodeBase64(student.getStudentDetails());
		String str = new String(byteArr);
		JSONObject jsonObject = new JSONObject(str);
		List<JSONObject> list = new ArrayList<JSONObject>();
		JSONArray array = new JSONArray(jsonObject.get("studentList").toString());
		System.out.println("Array Length:"+array.length());
		for (int i = 0; i < array.length(); i++)
		{
			list.add(array.getJSONObject(i));
		}
		Iterator<JSONObject> i = list.iterator();
		while (i.hasNext())
		{
			JSONObject jsonObj = i.next();  
			Student studentDetails = new Student();
			studentDetails.setMihId(paymentDetails.getMihpayid());   
			studentDetails.setMode(paymentDetails.getMode());
			studentDetails.setStatus(paymentDetails.getStatus());
			studentDetails.setUnmappedstatus(paymentDetails.getUnmappedstatus());
			studentDetails.setKey(paymentDetails.getKey());  
			studentDetails.setTxnid(paymentDetails.getTxnid());
			studentDetails.setFee(paymentDetails.getAmount().toString());  
			studentDetails.setCardCategory(paymentDetails.getCardCategory());
			studentDetails.setDiscount(paymentDetails.getDiscount());
			studentDetails.setNet_amount_debit(paymentDetails.getNet_amount_debit());
			studentDetails.setAddedon(paymentDetails.getAddedon());  
			studentDetails.setProductinfo(paymentDetails.getProductinfo());
			/*studentDetails.setAddress1(paymentDetails.getAddress1());
			studentDetails.setAddress2(paymentDetails.getAddress2());
			studentDetails.setState(paymentDetails.getState());
			studentDetails.setCity(paymentDetails.getCity());
			studentDetails.setCountry(paymentDetails.getCountry());    
			studentDetails.setZipcode(paymentDetails.getZipcode());*/
			studentDetails.setHash(paymentDetails.getHash());
			studentDetails.setPayment_source(paymentDetails.getPayment_source());
			studentDetails.setBank_ref_num(paymentDetails.getBank_ref_num());
			studentDetails.setBankcode(paymentDetails.getBankcode());
			studentDetails.setUdf3(paymentDetails.getUdf3());
			studentDetails.setError(paymentDetails.getError());
			studentDetails.setError_Message(paymentDetails.getError_Message());
			studentDetails.setName_on_card(paymentDetails.getName_on_card());
			studentDetails.setCardnum(paymentDetails.getCardnum());
			studentDetails.setCardhash(paymentDetails.getCardhash());
			studentDetails.setIssuing_bank(paymentDetails.getIssuing_bank());
			studentDetails.setCard_type(paymentDetails.getCard_type());
			studentDetails.setIpAddress(paymentDetails.getIpAddress());
			studentDetails.setPG_TYPE(paymentDetails.getPG_TYPE());
			//studentDetails.setCourseid(jsonObj.getString("courseid"));   
			studentDetails.setName(jsonObj.getString("name"));
			//studentDetails.setEmail(paymentDetails.getEmail());  
			//studentDetails.setPhone(jsonObj.getString("phoneno"));
			//studentDetails.setInstituteid(jsonObj.getString("instituteid"));     	  		
			//studentDetails.setHighestQualification(jsonObj.getString("highestqualification"));
			studentDetails.setInstituteid(paymentDetails.getUdf2());
			studentDetails.setCourseid(paymentDetails.getUdf1());   

			Map<String, Object> map = new HashMap<String, Object>();  
			map.put("p", studentDetails);
			sqlSessionTemplate.insert("PayUStatus.saveStudentDetails", map);   
		}         
	}
       
	public PayUMoney getCourseDetails(PayUMoney payUMoney) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p", payUMoney);
		PayUMoney payu = sqlSessionTemplate.selectOne("PayUStatus.getcourseDetails", map);
		return payu;
	}
	        
	public String getCoursename(String courseid) {
		String Course = sqlSessionTemplate.selectOne("PayUStatus.getCoursename", courseid);
		return Course;   
	}
	
	
	public String getCentername(String centerid) {
		String Center = sqlSessionTemplate.selectOne("PayUStatus.getCentername", centerid);
		return Center;   
	}

	public PayUMoney getStudentLink(PayUMoney payUMoney)
	{
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p", payUMoney);
		return sqlSessionTemplate.selectOne("PayUStatus.getStudentLink", map);
	}
}