/*function showHomepage(){
	Andromeda.showPage("/fileupload/html/general/fileupload.html","containerDiv");
}
*/

function showHomepage(){
	Andromeda.showPage("/apssdc/html/general/registrerStudent.html","containerDiv");
}

function showSubscriptionPage(){
	Andromeda.showPage("/apssdc/html/general/subscribe.html","containerDiv");
}

function showRegPage(){
	Andromeda.showPage("html/general/studentRegistration.html","containerDiv");
}

function showJob1Page(){
	Andromeda.showPage("html/general/jobOneRegistration.html","containerDiv");
}

function showPaymentPage(){
	Andromeda.showPage("html/general/choosePayment.html","containerDiv");
}

function showJob2Page(){
	Andromeda.showPage("html/general/jobTwoRegistration.html","containerDiv");
}
function showJob3Page(){
	Andromeda.showPage("html/general/jobThreeRegistration.html","containerDiv");
}
function showJob4Page(){
	Andromeda.showPage("html/general/jobFourRegistration.html","containerDiv");
}
function showJob5Page(){
	Andromeda.showPage("html/general/jobFiveRegistration.html","containerDiv");
}
function showJob6Page(){
	Andromeda.showPage("html/general/jobSixRegistration.html","containerDiv");
}
function showJob7Page(){
	Andromeda.showPage("html/general/jobSevenRegistration.html","containerDiv");
}
function showJob8Page(){
	Andromeda.showPage("html/general/jobEightRegistration.html","containerDiv");
}

function getUrlParameter(sParam) {
				    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
				        sURLVariables = sPageURL.split('&'),
				        sParameterName,
				        i;
				
				    for (i = 0; i < sURLVariables.length; i++) {
				        sParameterName = sURLVariables[i].split('=');
				
				        if (sParameterName[0] === sParam) {
				            return sParameterName[1] === undefined ? true : sParameterName[1];
				        }
				    }
					};