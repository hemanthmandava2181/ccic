var studentModule = angular.module('studentModule', []);
studentModule.controller('FormController', [ '$http', '$scope','$filter', function($http, $scope, $filter) {
	
    	$scope.status = true;
 		var range = 30;
		var currentYear = new Date().getFullYear();
		currentYear = currentYear + 5;
		var testYears = [];
		for ( var i = 0; i < range; i++) {
			testYears.push(currentYear - i);
		}
		$scope.years = testYears;
		
		$http.post('/communication/aadhaar/info', Andromeda.getSessionValue("aadhaar")).then(function(response) {
				$scope.response = response.data;
				if($scope.response.successful) {
					var todaydate = new Date($scope.response.responseObject.dob);
						var date=todaydate.getDate();
						var month=todaydate.getMonth()+1;
						var year=todaydate.getFullYear();
						if(date<10){
						date='0'+date;
						   }
						   if(month<10){
						    month='0'+month;
						   }
						var today=year+'-'+month+'-'+date;
					if($scope.response.responseObject.gender=='M'){
						$scope.response.responseObject.gender='Male';
					} else if($scope.response.responseObject.gender='F'){
						$scope.response.responseObject.gender='Female';
					}
					var object = {
						name : $scope.response.responseObject.name,
						aadhaar : $scope.response.responseObject.uid,
						dob : today,
						fathername : $scope.response.responseObject.careOf,
						gender : $scope.response.responseObject.gender,
						street : $scope.response.responseObject.street,
						mandalName : $scope.response.responseObject.mandalName,
						districtName : $scope.response.responseObject.districtName,
						pincode : $scope.response.responseObject.pincode,
						villageName : $scope.response.responseObject.villageName,
						phone: Number(Andromeda.getSessionValue("phone"))
					};
					$scope.personal = {object: object};
					var image = "<img src="+$scope.response.responseObject.photoLocation+" style='margin-top:30px;margin-left:40px;' alt='No_image'/>";
					jQuery("#image").html(image);
				}else{
					alert("Aadhaar Id is not available!");
				}
				
			}, function(errResponse) {
				console.error('Error while fetching notes');
			});
		
		$scope.add = function(personalInfo,educationInfo,skillsInfo) {
			personalInfo.email = Andromeda.getSessionValue("email");
			personalInfo.jobid = Andromeda.getSessionValue("jobid");
			personalInfo.skills = JSON.stringify(skillsInfo);
			
		if(personalInfo.email!=null && personalInfo.name!=null &&
			personalInfo.gender!=null && personalInfo.dob!=null && personalInfo.fathername!=null &&
			personalInfo.aadhaar!=null && personalInfo.category!=null && personalInfo.doorno!=null &&
			personalInfo.street!=null && personalInfo.villageName!=null && personalInfo.mandalName!=null &&
			personalInfo.districtName!=null && personalInfo.stateName!=null && personalInfo.pincode!=null &&
			personalInfo.phone!=null &&
			educationInfo.sscInstitute!=null && educationInfo.sscBoard!=null && educationInfo.sscGradingType!=null&&
			 educationInfo.sscyear!=null &&
			educationInfo.interInstitute!=null && educationInfo.interBoard!=null && educationInfo.interGradingType!=null&&
			 educationInfo.interyear!=null&&
			educationInfo.graduationCollege!=null && educationInfo.graduationUniversity!=null && educationInfo.graduationType!=null&&
			educationInfo.graduationBranch!=null && educationInfo.gradGradingType!=null&&
			 educationInfo.graduationyear!=null && educationInfo.graduationBacklog!=null && personalInfo.examinationCenter!=null)
			 {
				var registration = {
					personalInfo : personalInfo,
					educationInfo : educationInfo
				};
			$http.post('registration/add', registration).then(function(response) {
				$scope.response = response.data;
				if($scope.response.successful) {
					alert("Registration successful! Click ok for payment");
					jQuery("#spinner").removeClass("glyphicon glyphicon-refresh glyphicon-refresh-animate");
					showPaymentPage();
				}else{
					jQuery("#spinner").removeClass("glyphicon glyphicon-refresh glyphicon-refresh-animate");
					alert("You have already registered with us...");
				}
				
			}, function(errResponse) {
				console.error('Error while fetching notes');
			});
		}else{
			jQuery("#spinner").removeClass("glyphicon glyphicon-refresh glyphicon-refresh-animate");
			alert("All (*) fields are mandatory!");
		}	
		};
		
		
		 $scope.updateStudent = function(studentModel) {
		        studentModel.trainingBatchId = batchid;
		        $http.post('student/update', studentModel).then(function(response) {
		                $scope.data = response.data;
		                if ($scope.data.successful) {
		                    alert("Your Details updated successfully!!!!!");
		                } else {
		                    showError($scope.data.errorMessage);
		                }
		            },
		            function(errResponse) {
		                console.error('Error while fetching notes');
		            });

		    };
		
}]);
