var paymentOption = angular.module('paymentOption', [])
.controller('FormController', [ '$http', '$scope', function($http, $scope) {
	var self = this;
	var param = Andromeda.getSessionValue("param");
	$scope.save = function(paymentOption){
		paymentOption.aadhaar = Andromeda.getSessionValue("aadhaar");
		paymentOption.uniqueKey =  window.atob(Andromeda.getSessionValue("param"));
		$http.post('registration/paymentOption', paymentOption).then(function(response) {
					$scope.data = response.data;
					if($scope.data.successful) {
						alert("Check your mail!");
						jQuery("#spinner").removeClass("glyphicon glyphicon-refresh glyphicon-refresh-animate");
					} else{
						alert("Link expired!");
						jQuery("#spinner").removeClass("glyphicon glyphicon-refresh glyphicon-refresh-animate");
					}
		});
	};
} ]);




