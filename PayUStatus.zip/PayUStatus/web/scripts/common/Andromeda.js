var Andromeda = {

	showPage: function(path, targetDiv) {
		var jqxhr = jQuery.post(path, function(data) {
			jQuery("#" + targetDiv).html(data);
		});
	},

	showLoginPage: function() {
		var path = "/andromeda/html/login/loginForm.html";
		Andromeda.showPage(path, "amdContainerDiv");
	},

	showHomePage: function() {
		var path = "/sip/html/general/Home.html";
		Andromeda.showPage(path, "amdContainerDiv");
	},
	
	showSIPHome : function() {
		var path = "/sip/html/general/SIPHome.html";
		Andromeda.showPage(path, "amdContainerDiv");
	},
	
	showYearsPage : function() {
		var path = "/sip/html/general/SIPYearwise.html";
		Andromeda.showPage(path, "collegeDiv");
	},
	
	showCollegePrograms : function() {
		var path = "/sip/html/general/SIPCollegeWisePrograms.html";
		Andromeda.showPage(path, "collegeDiv");
	},
	
	showFacultyPrograms : function() {
		var path = "/sip/html/general/FacultyPrograms.html";
		Andromeda.showPage(path, "collegeDiv");
	},
	
	showPrograms : function() {
		var path = "/sip/html/general/SIPPrograms.html";
		Andromeda.showPage(path, "collegeDiv");
	},
	
	showStudents : function() {
		var path = "/sip/html/general/SIPStudents.html";
		Andromeda.showPage(path, "collegeDiv");
	},
	
	showCollegeDashboardPage : function() {
		var path = "/sip/html/general/Dashboard.html";
		Andromeda.showPage(path, "collegeDiv");
	},
	
	showMentorsPage : function() {
		var path = "/sip/html/general/Mentors.html";
		Andromeda.showPage(path, "collegeDiv");
	},
	
	showAttendancePage : function() {
		var path = "/sip/html/general/AttendanceTrainingPrgms.html";
		Andromeda.showPage(path, "collegeDiv");
	},
	
	showAttendanceReportHomePage : function() {
		var path = "/sip/html/general/AttendanceReport.html";
		Andromeda.showPage(path, "collegeDiv");
	},
	
	showCollegeDetailsPage : function() {
		var path = "/sip/html/general/CollegeDetails.html";
		Andromeda.showPage(path, "collegeDiv");
	},
	
	showAttReportTrainingPrgmsPage : function() {
		var path = "/sip/html/general/AttReportTrainingPrgms.html";
		Andromeda.showPage(path, "reportTableDiv");
	},
	
	showAttPrograms : function() {
		var path = "/sip/html/general/AttendancePrgms.html";
		Andromeda.showPage(path, "collegeDiv");
	},
	
	showAttStudents : function() {
		var path = "/sip/html/general/StudentAtt.html";
		Andromeda.showPage(path, "collegeDiv");
	},
	
	showAttReportPrgmsPage : function()
	{
		var path = "/sip/html/general/AttReportPrgms.html";
		Andromeda.showPage(path, "reportTableDiv");
	},
	
	showAttReportStudents : function()
	{
		var path = "/sip/html/general/AttReportStudents.html";
		Andromeda.showPage(path, "reportTableDiv");
	},
	
	showFIPFacultyDetails : function() {
		var path = "/sip/html/general/FIPFacultyDetails.html";
		Andromeda.showPage(path, "collegeDiv");
	},
	
	getCollegesforReg : function() {
		var path = "/sip/html/general/ClientRegistration.html";
		Andromeda.showPage(path, "registrationDiv");
	},
	
	showLinkGenerationPage : function() {
		var path = "/sip/html/general/LinkGeneration.html";
		Andromeda.showPage(path, "collegeDiv");
	},
	
	showStudentShiftPage : function() {
		var path = "/sip/html/general/StudentShift.html";
		Andromeda.showPage(path, "collegeDiv");
	},
	
	showCollegePaymentPage : function() {
		var path = "/sip/html/general/CollegePayment.html";
		Andromeda.showPage(path, "collegeDiv");
	},
	
	showSlidePage : function() {
		$("#replaceDiv").load("/andromeda/html/general/Slideshow.html");
	},
	
	home: function() {
		var path = "/";
		Andromeda.showPage(path, "amdContainerDiv");
	},

	setSessionValue: function(key, value) {
		sessionStorage.setItem(key, value);
	},

	getSessionValue: function(key) {
		return sessionStorage.getItem(key);
	},

	removeSessionValue: function(key) {
		sessionStorage.removeItem(key);
	},

	showError: function(errorMessage) {
		var message = "<div class=\"alert alert-danger\"><strong>Error: </strong>"+errorMessage+"</div>";
		jQuery("#errorDiv").html(message);
	},

	logout : function() {
		var username = Andromeda.getSessionValue("userName") || "";
		Andromeda.setSessionValue("userName", null);
		Andromeda.setSessionValue("context", null);
		var data = {
			username : username
		};
		Andromeda.post('/andromeda/security/logout', data);
		$("#amdContainerDiv").load("/andromeda/html/general/Home.html");
	},
	
	/*SIPLogout : function() {
		var username = Andromeda.getSessionValue("userName") || "";
		Andromeda.setSessionValue("userName", null);
		Andromeda.setSessionValue("context", null);
		var data = {
			username : username
		};
		Andromeda.post('/andromeda/security/logout', data);
		Andromeda.showHomePage();
	},*/

	post: function(url, data) {
		var responseData = null;
	
		jQuery.ajax({
			url : url,
			type : 'post',
			data : JSON.stringify(data), // Stringified Json Object
			dataType : 'json',
			async : false, // Cross-domain requests and dataType: "jsonp" requests do not support synchronous operation
			cache : false, // This will force requested pages not to be cached by the browser
			processData : false, // To avoid making query String instead of JSON
			contentType : "application/json; charset=utf-8",
			success : function(data) {
				responseData = data;
			}
		});

		return responseData;
	},

	isUserLoggedIn: function() {
		var username = localStorage.getItem("userName") || "";
		var context = localStorage.getItem("context") || "";
		var data = {
			username : username,
			context : context
		};
		return Andromeda.post('/andromeda/security/loggedin', data) || false;
	},
	
	showModulesPage: function(userName) {
		var object = {
			userName: userName
		};
	 var data = Andromeda.post('/andromeda/modules', object);
			Andromeda.showModules(data);
	},
	
	loadModule: function(userName,moduleId,moduleUrl) {
		Andromeda.setSessionValue("userName",userName);
		Andromeda.setSessionValue("moduleId",moduleId);
		jQuery("#amdContainerDiv").load(moduleUrl);
	},
	
	loadLink: function(path) {
		var targetDiv = "amdContentDiv";
		Andromeda.showPage(path, targetDiv);
	},
	
	showLinks: function(data) {
		var linksDataString = "No links present";
		if ((data) && (data.links) && (data.links.length > 0))
		{
				//var moduleString = "<div id='sidebar' class='well sidebar-nav'>";
				var moduleString = "";	
			for(var i=0; i<data.links.length; i++)
			{
				var serviceId = data.links[i].id || "No ID";
				var serviceName = data.links[i].name || "No Name";
				var serviceDescription = data.links[i].description || "No Description";
				var serviceUrl = data.links[i].url || "No Url";
				var serviceFunction = data.links[i].functionName || "No Function";
				//var moduleTestUrl = data.modules[i].testUrl;
				//var userName = Andromeda.getSessionId("username");
				//"Andromeda.loadLink('" + serviceUrl + "')
				moduleString += "<li class='left-menu-item cursor-pointer'	onClick='"+serviceFunction+"'><a>"+serviceDescription+"</a></li>";		
			}
			linksDataString = moduleString;
		}
		jQuery("#amdContentDiv").html(linksDataString);
	},
	
	loadServices: function(){
	var userName = Andromeda.getSessionValue("userName");
	var moduleId = Andromeda.getSessionValue("moduleId");
		var path = "/andromeda/moduleServices/"+userName+"/"+moduleId;
		var jqxhr = Andromeda.post(path,'');
		Andromeda.showLinks(jqxhr);
	},
	
	showModules: function(data) {
		var modulesDataString = "No modules present";
	
		if ((data) && (data.modules) && (data.modules.length > 0))
		{
			modulesDataString = "<div class=\"row\">";
			for(var i=0; i<data.modules.length; i++)
			{
				var moduleId = data.modules[i].id || "No ID";
				var moduleName = data.modules[i].name || "No Name";
				var moduleDescription = data.modules[i].description || "No Description";
				var moduleUrl = data.modules[i].url || "No Url";
				var moduleTestUrl = data.modules[i].testUrl;
				var userName = Andromeda.getSessionValue("userName");
				var moduleString = "<div class=\"col-md-3 amdModuleDiv\" onClick=\"Andromeda.loadModule('" + userName + "'," +moduleId+ ",'"+ moduleUrl +"');\">";
				moduleString += "<div class=\"amdModule\" id=\"amdModule"+i+"\"><table border=\"0\"><tr>";
				if(moduleName=='SDC'){
					moduleString += "<td><div class=\"amdModuleIcon\"><span style=\"font-size:40px;color:green;\" class=\"glyphicon glyphicon-blackboard\"></div></td>";
				} else if(moduleName=='ESDM'){
					moduleString += "<td><div class=\"amdModuleIcon\"><img src='andromeda/images/icons/ESDM.png' /></div></td>";
				} else if(moduleName=='Employee'){
					moduleString += "<td><div class=\"amdModuleIcon\"><span style=\"font-size:40px;color:skyblue;\" class=\"glyphicon glyphicon-user\"></span></div></td>";
				} else if(moduleName=='Reports'){
					moduleString += "<td><div class=\"amdModuleIcon\"><img src='andromeda/images/icons/Reports.png' /></div></td>";
				} else if(moduleName=='SkillAmaravati'){
						moduleString += "<td><div class=\"amdModuleIcon\"><span style=\"font-size:40px;color:#337ab7;\" class=\"glyphicon glyphicon-calendar\"></div></td>";
				} else if(moduleName=='Companies'){
                        moduleString += "<td><div class=\"amdModuleIcon\"><span style=\"font-size:40px;color:peru;\" class=\"glyphicon glyphicon-tower\"></div></td>";
                } else{
					moduleString += "<td><div class=\"amdModuleIcon\"></div></td>";
				}
				
				moduleString += "<td><div class=\"amdModuleTitle\">"+ moduleName +"</div></td>";
				moduleString += "</tr><tr><td colspan=\"2\">";
				moduleString += "<div class=\"amdModuleDescription\">" + moduleDescription + "</div>";
				moduleString += "</td></tr></table></div></div>";
				
				modulesDataString += moduleString;
			}
			
			modulesDataString += "</div>";
		}

		jQuery("#amdContentDiv").html(modulesDataString);
	},
	
	showEmployeePage: function() {
		var path = "/tiesems/html/forms/EmployeeForm.html";
		Andromeda.showPage(path, "amdContentDiv");
	}
	
	
};

function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};