var fileupload = angular.module('fileupload', [])
.controller('FormController', [ '$http', '$scope', function($http, $scope) {
	
$scope.uploadFile = function(el1) {
		  var fileName = el1.files[0].name;
				var fileReader;
			        fileReader = new FileReader();
			        fileReader.onload = function(e) {
			        	binaryString =  e.target.result;
			        	base64 = btoa(binaryString);
			        	var str = base64.toString();
			        	var fileModel = {
			        		fileName : fileName,
			        		base64String : str,
			        		name:'Profile'
			        		
			        	};
			        	console.log(fileModel);
						$http.post('/file/upload',fileModel).then(function(response) {
							$scope.data = response.data;
							if($scope.data.successful)
							{
								alert("Successfully Uploaded!");
								
							}
							else {
								alert("File upload failed....please try again!!!!");
							}
						}, function(errResponse) {
							console.error('Error while fetching notes');
						});
			        };       
			        fileReader.readAsBinaryString( el1.files[0]);	
			        
	};
}]);
