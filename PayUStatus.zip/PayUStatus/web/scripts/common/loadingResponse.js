
var loadingResponse = angular.module('loadingResponse', [])
.controller('FormController', [ '$http', '$scope', function($http, $scope) {
	var self = this;
		$http.post('registration/home').then(function(response) {
					$scope.data = response.data;
					if($scope.data.successful) {
						alert("successsss");
					}else{
						alert("Link expired!");
					}
		});
} ]);




