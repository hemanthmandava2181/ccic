var Andromeda = {

	showPage : function(path, targetDiv) {
		var jqxhr = jQuery.post(path, function(data) {
			jQuery("#" + targetDiv).html(data);
		});
	},
	
	showHomePage : function() {  
		var path = "/ccic/html/home.html";
		Andromeda.showPage(path, "mainDiv");
	},
	showRegistrationPage : function()
	{
		var path = "/ccic/html/GetStudent.html";
		Andromeda.showPage(path,"change");	
	},
	 
	showHODLoginCreation : function()
	{
		var path = "/ccic/html/HODCreation.html";       
		Andromeda.showPage(path,"change");
	},
	showLoginCreation : function(){ 
		var path = "/ccic/html/LoginCreation.html";
		Andromeda.showPage(path,"change");
	},         
	showStudentPortal : function(){
		var path = "/ccic/html/studentportal.html";    
		Andromeda.showPage(path,"mainDiv");            
	},   
	
	
	showStudentPay : function(){
		var path = "/ccic/html/StudentPay.html";   
		Andromeda.showPage(path,"studentDiv");        
	},     
	
	showGenerateHallTicket : function(){
		var path = "/ccic/html/hallticketgeneration.html";          
		Andromeda.showPage(path,"studentDiv");        
	}, 
	  
	showStudentsApprove : function(){
		var path = "/ccic/html/StudentsApprove.html";          
		Andromeda.showPage(path,"change");        
	},   
	      
	   
	
	
	 showAdminHomePage : function() {     
			var path = "/ccic/html/adminhome.html";               
			Andromeda.showPage(path, "mainDiv");
	},
	showHodHomePage : function() {     
		var path = "/ccic/html/hodhome.html";               
		Andromeda.showPage(path, "mainDiv");    
	},
	showLoginHomePage : function()
	{
		var path = "/ccic/html/loginhome.html";               
		Andromeda.showPage(path, "mainDiv");	
	},
	
	  showStudentRegistration1 : function() {     
			var path = "/ccic/html/GetStudent.html";               
			Andromeda.showPage(path, "change");
		},       
		showStudentRegistration2 : function() {     
			var path = "/ccic/html/table.html";               
			Andromeda.showPage(path, "change");
		},
		showStudentRegistration3 : function() {     
			var path = "/ccic/html/PayStudent.html";               
			Andromeda.showPage(path, "change");      
		},
	    
	
	
	       
	/*showAboutPage : function() {  
		var path = "/ccic/html/about.html";               
		Andromeda.showPage(path, "subHome");
	},
	    
	     
	
	showLoginHome : function(){
		var path = "/ccic/html/home.html";
		Andromeda.showPage(path, "mainDiv");	
	},	
	
	showlogincredentialsPage: function() {               
		var path = "/ccic/html/LoginCreation.html";
		Andromeda.showPage(path, "subHome");
	},
	
	showContactPage : function() {    
		var path = "/ccic/html/contact.html";
		Andromeda.showPage(path, "subHome");
	},
	
	
	showAddStudentDetails : function() {    
		var path = "/ccic/html/AddStudent.html";
		Andromeda.showPage(path, "replaceDiv"); 
	},   
	
	showGetStudentDetails : function() {    
		var path = "/ccic/html/GetStudent.html";
		Andromeda.showPage(path, "replaceDiv");
	},   
	
	showPayStudentDetails : function() {    
		var path = "/ccic/html/PayStudent.html";
		Andromeda.showPage(path, "replaceDiv");
	},      
	
	showFeedbackForm: function() {
		var path = "/ccic/html/feedback_form.html";  
		Andromeda.showPage(path, "subHome");
	},

	showLogin: function() {  
		var path = "/ccic/html/login.html";
		Andromeda.showPage(path, "subHome");
	},
	
	
	home : function() {
		window.location.reload();             
	},
	
	          
	
	
	
	   
	showPayment: function() {
		var path = "/ccic/html/payment.html";      
		Andromeda.showPage(path, "replaceDiv");
	},      
*/

	setSessionValue : function(key, value) {
		sessionStorage.setItem(key, value);
	},

	getSessionValue : function(key) {
		return sessionStorage.getItem(key);
	},

	removeSessionValue : function(key) {
		sessionStorage.removeItem(key);
	},

	showError : function(errorMessage) {
		var message = "<div class=\"alert alert-danger\"><strong>Error: </strong>"
				+ errorMessage + "</div>";
		jQuery("#errorDiv").html(message);
	},                       
                                                         
	logout : function() {
		
		var username = Andromeda.getSessionValue("username") || "";
		Andromeda.setSessionValue("username", null);
		Andromeda.setSessionValue("password", null);
		Andromeda.setSessionValue("role", null);
		var data = {
			username : username
		};  
		Andromeda.post('/ccic/login/logout', data);
		Andromeda.showHomePage();
	},

	post : function(url, data) {
		var responseData = null;

		jQuery.ajax({   
			url : url,
			type : 'post',
			data : JSON.stringify(data), // Stringified Json Object
			dataType : 'json',
			async : false, // Cross-domain requests and dataType: "jsonp"
			// requests do not support synchronous operation
			cache : false, // This will force requested pages not to be cached
			// by the browser
			processData : false, // To avoid making query String instead of
			// JSON
			contentType : "application/json; charset=utf-8",
			success : function(data) {
				responseData = data;
			}
		});

		return responseData;
	},

	isUserLoggedIn : function() {
		
		var username = Andromeda.getSessionValue("username") || "";
		var password = Andromeda.getSessionValue("password") || "";
		var role = Andromeda.getSessionValue("role") || "";
		
		var login = {
			username : username,
			password : password,
			role : role,
			
		};    
   
		return Andromeda.post('/ccic/login/loggedin', login) || false;
	}  	
};
