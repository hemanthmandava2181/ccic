var Student = angular.module('PayStudentModule', []);
Student.filter('numberFormat', function () {
	return function(input) {   
	     input = input || 0;
	     var out = new Intl.NumberFormat('en-IN').format(parseInt(input));
	     return out;
	};
})  

.filter('sumOfValue', function() {
    return function(data, key) {
      if (angular.isUndefined(data) || angular.isUndefined(key))
        return 0;
      var sum = 0;
      angular.forEach(data, function(v, k) {
        sum = sum + parseInt(v[key]);
      });
      return sum;
    };           
 })    

     

.controller('PayStudentController', ['$http','$scope', function($http, $scope) {
	$scope.filteredResult = [], $scope.studentFilteredResult = [], $scope.studentsPaymentArr = [],
	$scope.totalLength = 0, $scope.totalAmount = 0, $scope.paidDetails = [];
		      

	
	// View Data from Database                        
	var courseid = Andromeda.getSessionValue('courseshortname');
	$http.post('/ccic/PayStudent/getSubjects',courseid).then(function(response){
		$scope.data61 = response.data;
		if($scope.data61.successful)
		{
			$scope.subjects = $scope.data61.responseObject;
		}
		else                       
		{
			console.log("Client error while getting data");
		}                      
	},
	function(response)  
	{	
		console.log("Server error while getting data");    
	});  
	
	$scope.getAll = function(userData)
	
	{    
		if(userData == "1")
			{
				var a=[Andromeda.getSessionValue("instituteid"),  
					Andromeda.getSessionValue("courseshortname")];
				a[0]=Andromeda.getSessionValue("instituteid");
				a[1] = Andromeda.getSessionValue("courseshortname");         
					
			  $http.post('/ccic/PayStudent/getAll',a).then(function(response) {
						$("#lb6b").show();
						$("#Div3").hide();
						$scope.data1 = response.data;
						if ($scope.data1.successful) {
							$scope.regdetails = $scope.data1.responseObject;
	     					} else {  
							alert("Can't view the Data");
						}
					},
					function(errResponse) {
						console.error('Error while viewing notes');
						
					});     
			}
		else{
			
			var a=[Andromeda.getSessionValue("instituteid"),  
				Andromeda.getSessionValue("courseshortname")];
			a[0]=Andromeda.getSessionValue("instituteid");
			a[1] = Andromeda.getSessionValue("courseshortname");         
				
		  $http.post('/ccic/PayStudent/getBacklogAll',a).then(function(response) {     
					$("#lb6b").show();
					$("#Div3").hide();
					$scope.data1 = response.data;
					if ($scope.data1.successful) {
						$scope.regdetails = $scope.data1.responseObject;
					} else {  
						alert("Can't view the Data");
					}
				},
				function(errResponse) {
					console.error('Error while viewing notes');
					
				});
			
			
			    
		}    
					
	}
	
				
					$scope.name=null,$scope.filteredResult = null;
					
					$scope.getNameWiseData = function(obj) {      
						$scope.getBranchWisePrograms = function(totalObj)
						{
							Andromeda.setSessionValue("studentBranchId", totalObj.name);
							
							$("#glyphiconid").show();      
							$scope.name = totalObj.name;
							$http.post('/ccic/PayStudent/getBranchWisePrograms', totalObj.name).then(function(response)
							{
								$scope.data = response.data;
								if($scope.data.successful)
								{
									$scope.regdetails = $scope.data.responseObject;
									/*$("#div1").hide();
									$("#lb6b").show();
									$("#div4").hide();  */
									$("#glyphiconid").hide();
								}
								else
								{    
									console.log("Client error while getting data");
								}
							},
							function(response)
							{
								console.log("Server error while getting data");
							});
						}; 
					} 
				     
					$scope.showStudentsDetails = function()
					{
						$("#Div3").hide();
						$("#Div1").hide();
						$("#div2").show();             
						$("#courseWise").hide();    
						$("#courseWiseSCST").hide();    
						$("#courseWiseSCSTDetailsDiv").hide();
						$("#i2EDetailsDiv").hide();
					};
	
					$scope.save = function(){        
						var institutioncode = Andromeda.getSessionValue("instituteid");
						
						$http.post('/payment/payment/home', institutioncode).then(function(response) {
									$scope.data = response.data;
									if($scope.data.successful) {
										//alert("Check your mail!");
										jQuery("#mainDiv").html($scope.data.responseObject.responseObject);
									} else{    
										alert("Link expired!");
									}  
						});
			    		};   
			
			    		$scope.toggle = function(id)
			    		{
			    			$("#" + id).toggle();
			    		};
			    		     
			    		$scope.exportToExcel = function(id)
			    		{
			    			var blob = new Blob([document.getElementById(id).innerHTML], { 
			    		        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8" 
			    		    }); 
			    		    var fileName = "Report.xls"; 
			    		    saveAs(blob, fileName);
			    		};       
			    		       
			    		
			    		
			    		$scope.setAllRegIds = function(allStudents)
			    		{
			    			if(allStudents == true)
			    			{
			    				for(var i = 0; i < $scope.studentFilteredResult.length; i++)
			    				{
			    					var applicationid = $scope.studentFilteredResult[i]['applicationid'];
			    					$scope.studentsPaymentArr[applicationid] = true;
			    				}
			    			}
			    			else if(allStudents == false)
			    			{
			    				$scope.studentsPaymentArr = [];
			    			}
			    			            			
			    		};
			    		
			    		/*$scope.studentList.studentList = $scope.arr;
			    		Andromeda.setSessionValue("studentList", btoa(JSON.stringify($scope.studentList)));
			    		
			    		var object =
			    		{
			    			students: $scope.totalLength,
			    			amount: $scope.totalAmount,
			    			studentList: btoa(JSON.stringify($scope.studentList)),
			    			course: $scope.course
			    		};
			    		
			    		
			    		Andromeda.setSessionValue("Base64String", btoa(JSON.stringify($scope.studentList)));
			    		
			    		$scope.payment = {object: object};
			    		$("#Div3").show();
			    		$("#Div1").hide();
			    		$("#Div2").hide();
			    		$("#courseWise").hide();
			    		$("#courseWiseSCST").hide();
			    		$("#courseWiseSCSTDetailsDiv").hide();
			    		$("#i2EDetailsDiv").hide();
			    		
			    		
			    		var data =
			    			{
			    				spocEmail : Andromeda.getSessionValue("userName")
			    			};   
			    		$scope.data = {object : data};
			    	         */    
			    		
			    		   
			    		$scope.savePaymentDetails = function(studentsPaymentArr)
			    		{
			    			console.log(studentsPaymentArr);
			    			$scope.totalLength = 0;
			    			$scope.totalAmount = 0;
			    			$scope.arr = [];                       
			    			$scope.studentList = {};
			    			
			    			//trainingBatchID = $scope.studentFilteredResult[0]['applicationid'];
			    			 if(studentsPaymentArr!= null)
			    			 {
			    			for(var i in studentsPaymentArr)   
			    			{
			    				if(studentsPaymentArr[i]== true)     
			 				   {
			    	  			$scope.student = {};  
			    				
			    				for(var j = 0; j < $scope.studentFilteredResult.length; j++)
			    				{
			    					var temp = $scope.studentFilteredResult[j];
			    					
			    					if((studentsPaymentArr[i] == true) && (i == temp['applicationid']))
			    					{
			    						$scope.student.name = temp['name'];
			    						//$scope.student.email = temp['email'];     
			    						$scope.student.phoneno = temp['phoneno'];
			     		  				$scope.student.applicationid = temp['applicationid'];
			     		  				$scope.student.courseid= Andromeda.getSessionValue('courseshortname');
			     		  				$scope.student.instituteid= Andromeda.getSessionValue('instituteid');
			    					//	$scope.student.address = temp['address'];       
			    						/*$scope.student.phone = temp['phone'];
			    						$scope.student.trainingProgramName = temp['trainingProgramName'];
			    						$scope.course = temp['trainingProgramName'];
			    						$scope.year = temp['course'];*/
			    						$scope.totalLength = $scope.totalLength + 1;
			    						$scope.totalAmount = $scope.totalAmount + parseInt(temp['fee']);
			    						$scope.arr.push($scope.student);
			    						
			    					}    
			    					console.log($scope.student); 
			    					/*console.log($scope.totalAmount);*/  
			    				}   
			    				
			    			}  
			    			 }
			    			 }
			    			 
			    				$scope.studentList.studentList = $scope.arr;  
			    				
			    				console.log($scope.arr);    
			    				
			    				Andromeda.setSessionValue("studentList", btoa(JSON.stringify($scope.studentList)));
			    				      
			    				var object =  
			    				{
			    					students: $scope.totalLength,
			    					amount: $scope.totalAmount,
			    					studentList: btoa(JSON.stringify($scope.studentList)),
			    					courseid: $scope.student.courseid,
			    					instituteid: $scope.student.instituteid
			    					
			    				};    
			    				  console.log(object);
			    				Andromeda.setSessionValue("Base64String", btoa(JSON.stringify($scope.studentList)));
			    				
			    				$scope.payment = {object: object};
			    				$("#errorDiv").hide();		
			    				$("#coursewiseDiv").hide();
			    				$("#coePaymentCoursesDiv").hide();   
			    				$("#registeredListDiv").hide(); 
			    				$("#Div3").show(); 
			    				$("#spinner").hide();

			    				/*var data =  
			    					{
			    						inchargeEmail : Andromeda.getSessionValue("userName")
			    					};
			    				$scope.data = {object : data}; */   
			    			};
			    			    
			    			$scope.pay = function(Data, paymentCountDetails)
			    			{
			    				if(Data == null || Data == undefined || Data == "")
			    				{
			    					alert("Fill all details");
			    				}
			    				
			    				else if(Data.spocName == null || Data.spocName == undefined || Data.spocName == "")
			    				{
			    					alert("Enter name");
			    				}    
			    				
			    				else if(Data.spocEmail == null || Data.spocEmail == undefined || Data.spocEmail == "")
			    				{
			    					alert("Enter valid mail id");
			    				}  
			    				else if(Data.phone == null || Data.phone == undefined || Data.phone == "")
			    				{
			    					alert("Mobile number starts with 9 or 8 or 7 or 6 and should be 10 digits");
   		    				}
			    				else     
			    				{       
			    					var status = confirm("A confirmation mail will be sent to \nEmail: " + Data['spocEmail'] + " \nAre you sure want to proceed?");
			    					if(status)  
			    					{            
			    						Data['applicationid'] = Andromeda.getSessionValue('applicationid');    
			    						Data['courseid'] = Andromeda.getSessionValue('courseshortname');
			    						Data['instituteid']=Andromeda.getSessionValue('instituteid');
			    					    
			    								//paymentCountDetails.aadhaar = allDetails['aadhaar'];
			    								paymentCountDetails.email = Data['spocEmail'];
			       								paymentCountDetails.name = Data['spocName'];
			    								paymentCountDetails.phone = Data['phone'];  
			    								paymentCountDetails.courseid =Data['courseid'];
			    								paymentCountDetails.instituteid =Data['instituteid'];
			    						    
			    			   					$scope.data = {object : paymentCountDetails};     
			    								    
			    								jQuery("#spinner").show();	
			    		   						
			    							$http.post('/ccic/PayStudent/paymentOption', paymentCountDetails).then(function(response) {
			    									$scope.data = response.data;
			    									if($scope.data.successful) {
			    										
			    			     							paymentCountDetails.bulkPaymentKey = $scope.data.responseObject;
			      				    						console.log(paymentCountDetails.courseid);
			    				    						console.log(paymentCountDetails.instituteid);
			    					 					$http.post('/payment/payment/bulkPayment', paymentCountDetails).then(function(response)
			    				          			   		{
			    											$scope.data = response.data;  
			    						     					if($scope.data.successful)    
			    						        					{
			    					   							$scope.paymentResponse = $scope.data.responseObject.responseObject;
			    												console.log("Response:"+$scope.paymentResponse);
			    												jQuery("#paymentDiv").html($scope.paymentResponse);
			    											}     
			    											else                          
			    											{
			    												console.log("Client error while getting college data");
			    											}
			    										},
			    										function(response)
			    		  								{
			    											console.log("Server error while getting college data");
			    										});
			    									}
			    								});
			    									
			    				    
			    								
			    								
			    					}
			    				}
			    			};
			    	
		} ]);
