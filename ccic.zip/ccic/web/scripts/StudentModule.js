
var Student = angular.module('StudentModule', ['xlsx-model']);
Student.controller('StudentController', ['$http','$scope', function($http, $scope) {
	
	/*$http.post('/sbtet/lib/getCourses').then(function(response) {
		$scope.data55 = response.data;
		if($scope.data55.successful) {
			
			$scope.branches=$scope.data55.responseObject;
		};
	});      */         
	
	
	
	
	$http.post('/ccic/stu/getYear').then(function(response) {
		$scope.data11 = response.data;
		if($scope.data11.successful) {
			/*$scope.aicterequiredone=$scope.data.responseObject;*/
			$scope.data={object:$scope.data11.responseObject};
		};   
		 
	}); 
	
	
	var role=Andromeda.getSessionValue('role');
	 var circularsArr = [];
		$scope.filePathsA
		rr = [];
		
		 
	    $scope.uploadFile = function(el1,param) 
		 {
			console.log(el1);
			console.log(param);
			var employeeId=Andromeda.getSessionValue("role");
			console.log(employeeId);
		   var fileName = el1.files[0].name;
		   var fileDetails=fileName.split(".");
		   fileName=employeeId+"_"+param+"."+fileDetails[1];
		   console.log(fileName);
				
		   //  fileName=param+"_"+employeeId+"."+fileDetails[1];
				  
		   // var fielName=fileDetails.join(".");
		   
		   Andromeda.setSessionValue("fileFormat",fileDetails[1]);
		  console.log(Andromeda.getSessionValue("fileFormat"));
			var fileReader;
	       fileReader = new FileReader();
	       fileReader.onload = function(e) {
	       	binaryString =  e.target.result;
	       	base64 = btoa(binaryString);
	       	var str = base64.toString();
	       	
	       	var fileModel = {
	       		fileName : fileName,
	       		base64String : str,
	       		name:fileName,
	       		role:Andromeda.getSessionValue('role')
	       	};
	       	//console.log("fileModel"+fileModel);
				$http.post('/ccic/stu//upload',fileModel).then(function(response) {    
					$scope.data1111 = response.data;
					if($scope.data1111.successful)
					{
						var name=$scope.data1111.responseObject.name;
						Andromeda.setSessionValue("filePath",name);
						
						
					}
					else {
						alert("File upload failed....please try again!!!!");
					}
				}, function(errResponse) {
					console.error('Error while fetching notes');
				});
	       };       
	       fileReader.readAsBinaryString( el1.files[0]);	
	    };
	    

                  
	  //Save excel data
	    $scope.save = function(excelData,yearobject)
	    {
	    	console.log(yearobject);
	    	
	    	if(yearobject == undefined)
			{
				swal("OOPS!","Fill all details","info");
			}
			else if(yearobject.year1 == null || yearobject.year1 == undefined || yearobject.year1 == "")
			{
				swal("Oops...","Select year","info");
			}
			else
				{
	    	
	    	/*console.log(excelData);*/
	        jQuery("#spinner1").show();
	        var student = [];
	        $scope.excelDetails = excelData.slice(1, excelData.length+1);
	        var excelLength =  $scope.excelDetails.length, keepOnGoing = true;
	            
	            for(var i = 0; i < $scope.excelDetails.length; i++)
	            {
	            	var studentsDetails = {};
	            		studentsDetails.name = $scope.excelDetails[i]['Name'];
	            		studentsDetails.fathername = $scope.excelDetails[i]['Father Name'];
	            		studentsDetails.email = $scope.excelDetails[i]['Email']; 
	            		studentsDetails.phoneno = $scope.excelDetails[i]['Phone Number']; 
	  
	                
	            	  
	            		 studentsDetails.year1 = yearobject.year1;
	 	                studentsDetails.institutioncode = Andromeda.getSessionValue("instituteid");
	 	                studentsDetails.courseid = Andromeda.getSessionValue("courseshortname");
	 	                studentsDetails.fee = Andromeda.getSessionValue("fee");
	 	            	studentsDetails.role = Andromeda.getSessionValue('role');
	 	                console.log(Andromeda.getSessionValue('filePath'));
	 	                studentsDetails.filePath = Andromeda.getSessionValue('filePath');
	 	                studentsDetails.fileExtension = Andromeda.getSessionValue('fileFormat');
	 	                //studentsDetails.fileFormat = Andromeda.getSessionValue('fileFormat');
	 	                student.push(studentsDetails);

	            }
	            
	            $("#spinner1").show();
	            console.log('StData:'+student);
	            
	            $http.post('/ccic/stu/saveDetails',student).then(function(response) {
	                $scope.data1 = response.data;
	                if($scope.data1.successful) {
	                	
	                	$("#spinner1").hide();
	                    alert("Data saved successfully");

	                }
						 
						 else {
	                    alert("Data not inserted");
	                }
	            }, function(errResponse) {
	                console.error('Error while fetching notes');
	            });
	            
	            
				}
	     
	           
	    };             
	
	
	
	
	
			      
				$scope.Student = function(userData) { 
					
					if(userData != undefined)  
					{
						if(userData.name == null || userData.name == undefined || userData.name == "")
						{
							swal("Oops","Please, Enter Name ","info");
						}  
						else if(userData.fathername == null || userData.fathername == undefined || userData.fathername == "")
						{
							swal("Oops","Please, Enter Father Name ","info");
						}  
						else if(userData.email == null || userData.email == undefined || userData.email == "")
						{
							swal("Oops","Please, Enter Email ","info");
						}       
						else if(userData.phoneno == null || userData.phoneno == undefined || userData.phoneno == "")
						{
							swal("Oops","Please, Enter Phone Number ","info");
						}       
						else 
						{
					
				    	 userData.institutioncode = Andromeda.getSessionValue("instituteid");
				    	 userData.courseid = Andromeda.getSessionValue("courseshortname");
				    	 userData.fee = Andromeda.getSessionValue("fee");
				    	 userData.exmcentercode = Andromeda.getSessionValue("exmcentercode");
				    	 console.log(userData.exmcentercode);
				    	  	 	$http.post('/ccic/stu/add', userData).then(   
									function(response) {    
										$scope.data3 = response.data;
										if ($scope.data3.successful) {  
											               
											swal("Success","Data Inserted Successfully","info");
											Andromeda.showStudentRegistration1();  
										} else {             
											swal("Failed","Data Not Inserted","info");   
										}
									}, function(errResponse) {
										console.error('Error while fetching notes');
									});
				      
						}
				    }
				};
				       			
			     
					// View Data from Database
				var a=[Andromeda.getSessionValue("instituteid"),  
					Andromeda.getSessionValue("courseshortname")];
				a[0]=Andromeda.getSessionValue("instituteid");
				a[1] = Andromeda.getSessionValue("courseshortname");         
					$http.post('/ccic/stu/getAll',a).then(function(response) {
						$scope.data1 = response.data;
						if ($scope.data1.successful) {
							$scope.regdetails = $scope.data1.responseObject;
						} else {
							alert("Can't view the Data");
						}   
					}, function(errResponse) {
						console.error('Error while viewing notes');
					});                
			  
			//Update User Details
			$scope.updateData = function(Data){
				//alert(Data.branch);
				Data.institutioncode = Andromeda.getSessionValue("instituteid");
				Data.courseid = Andromeda.getSessionValue("courseshortname");
				$http.post('/ccic/stu/updateData', Data).then(
						function(response) {
							$scope.data2 = response.data;
							if ($scope.data2.successful) {
							  alert("User Details Successfully updated");
							  Andromeda.showStudentRegistration1();
							} else {
							  alert("Data not updated");
							}
						}, function(errResponse) {
						console.error('Error while fetching notes');
						});
			};
                         
			
			//Get Data from Database based on Name
			$scope.getById = function(Data){
			Data.institutioncode = Andromeda.getSessionValue("instituteid");
			Data.courseid = Andromeda.getSessionValue("courseshortname");
			$http.post('/ccic/stu/getById',Data).then(function (response) {
			    $scope.data13 = response.data;
			    if ($scope.data13.successful) {
			        $scope.data = {object:$scope.data13.responseObject};
			    } else {
			    	//alert("Error while getting data");
			    	console.log("error")
			       
			    }
			}, function (errResponse) {
			   console.error('Error while fetching notes');    
			});   
			};       
			     
			
			
			
				/*$http.post('/sbtet/lib/getById', a).then(
						function(response) {
							$scope.data = response.data;
							if ($scope.data.successful) {
								$scope.branches={object:$scope.data.responseObject};
							} else {
								alert("Error while getting data");
							}
						}, function(errResponse) {
							console.error('Error while fetching notes');
						});*/
			/*};*/
			
			// Delete UserData based on Name
			/*$scope.removeData = function(branch) {
				$http.post('/sbtet/lib/removeData', branch).then(
						function(response) {
							$scope.data = response.data;
							if ($scope.data.successful) {
								location.reload();
								alert("User Data removed Successfully");
							} else {
						     	alert("Data not Deleted");
							}
						}, function(errResponse) {
							console.error('Error while fetching notes');     
						});
			};	*/
			     
		/*	$scope.save = function(){      
				var institutioncode = Andromeda.getSessionValue("instituteid");
				$http.post('/payment/payment/home', institutioncode).then(function(response) {
							$scope.data = response.data;
							if($scope.data.successful) {
								//alert("Check your mail!");
								jQuery("#mainDiv").html($scope.data.responseObject.responseObject);
							} else{    
								alert("Link expired!");
							}
				});    
			};*/

		
		} ]);
