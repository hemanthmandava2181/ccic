var StudentPay = angular.module('hallticket', []); 
StudentPay.controller('StudentPayController', ['$http','$scope', function($http, $scope) {
	       
	// View Data from Database
	   
	    
	
				//Get Data from Database based on Name
				$scope.getByApplicationId = function(applicationid){ 
					
					 
					Andromeda.setSessionValue("applicationid",applicationid);  

					
				$http.post('/ccic/StudentPay/getByApplicationId',applicationid).then(function (response) {
					 
				    $scope.data13 = response.data;            
				    if ($scope.data13.successful) {       
				        $scope.data = $scope.data13.responseObject;
				    } else {   
				    	//alert("Error while getting data");      
				    	console.log("error")
				       
				    }
				}, function (errResponse) {
				   console.error('Error while fetching notes');        
				}); 
				 
				$http.post('/ccic/StudentPay/getSubject',applicationid).then(function(response){
					$scope.data61 = response.data;          
					if($scope.data61.successful)       
					{             
						$scope.subjects = $scope.data61.responseObject;
					}   
					else                       
					{
						console.log("Client error while getting data");
					}                      
				},
				function(response)       
				{	
					console.log("Server error while getting data");    
				});
				             
     				};        
				  
				    
				$scope.save = function(){         
					var applicationid =Andromeda.getSessionValue('applicationid');
					console.log(applicationid);
					$http.post('/payment/payment/home',applicationid).then(function(response) {
						console.log(applicationid);
						console.log(response);
								$scope.data = response.data;        
								
								if($scope.data.successful) {
									//alert("Check your mail!");
					  				jQuery("#mainDiv").html($scope.data.responseObject.responseObject);
								} else{    
									alert("Link expired12345!");
								}        
								
					});              
		    		};     
		    		
		    		
		    		 $scope.generateHallTicket = function(applicationid)
		 			{   
		 				
		 				        	$http.post('/ccic/StudentPay/generateHallTicket', applicationid).then(function(response) {
		 				        		console.log(a);
		 										$scope.data2 = response.data;      
		 										if ($scope.data2.successful) {
		 										alert("User Hallticket Successfully Generated");   
		 			   							} else {
		 										  alert("User Hallticket Not Generated");       
		 										}
		 									}, function(errResponse) {
		 									console.error('Error while fetching notes');
		 									});
		 					  		}     
		 						               } ]);
