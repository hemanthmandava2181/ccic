var creationModule = angular.module('creationModule', []);
creationModule.controller('creationController',['$scope','$http',function($scope,$http)
{
	
	$http.get('/ccic/service/getDistricts').then(function(response){
		$scope.data61 = response.data;
		if($scope.data61.successful)
		{
			$scope.districts = $scope.data61.responseObject;
		}
		else
		{
			console.log("Client error while getting data");
		}
	},
	function(response)  
	{	
		console.log("Server error while getting data");
	});
	                                                  
	$scope.getColleges = function(districtid)
	{
		$http.post('/ccic/service/getColleges',districtid).then(function(response){
			$scope.data62 = response.data;
			if($scope.data62.successful)
			{
				$scope.colleges = $scope.data62.responseObject;
				/*$scope.data = {object : totalObj};*/
			}
			else
			{
				console.log("Client error while getting data");
			}
		},
		function(response)
		{
			console.log("Server error while getting data");
		});
		
		
		$http.post('/ccic/service/getExamCenters',districtid).then(function(response){
			$scope.data62 = response.data;
			if($scope.data62.successful)
			{   
				$scope.examcenters = $scope.data62.responseObject;
				/*$scope.data = {object : totalObj};*/
			}
			else
			{
				console.log("Client error while getting data");
			}
		},
		function(response)
		{
			console.log("Server error while getting data");
		});
		
	};
	$scope.getCourses = function(instituteid)
	{
	$http.post('/ccic/service/getCourses',instituteid).then(function(response){
		$scope.data61 = response.data;
		if($scope.data61.successful)
		{
			$scope.courses = $scope.data61.responseObject;
		}
		else               
		{
			console.log("Client error while getting data");
		}                      
	},
	function(response)  
	{	
		console.log("Server error while getting data");    
	});
	};
	$scope.getRoles = function()
	{
		$http.post('/ccic/service/getRoles').then(function(response){
			$scope.data62 = response.data;
			if($scope.data62.successful)
			{
				$scope.roles = $scope.data62.responseObject;
				/*$scope.data = {object : totalObj};*/
			}
			else
			{
				console.log("Client error while getting data");
			}
		},
		function(response)
		{
			console.log("Server error while getting data");
		});
	};   $scope.getData = function(institutioncode) {
			$http.post('/ccic/service/getData',institutioncode).then(function(response) {
				$scope.data60 = response.data;
				if($scope.data60.successful) {
					
					$scope.data1={object:$scope.data60.responseObject};
				};
			}); 				
		 };
	$scope.createLogin = function(totalObj,data1)
	{
		jQuery("#glyphiconid").show();
		if(totalObj == null || totalObj == undefined || totalObj == "")
		{
			alert("Fill all details!");
		}
		else if(totalObj.districtid == null || totalObj.districtid == undefined || totalObj.districtid == "")
		{
			alert("Select district");
		}
		else if(totalObj.instituteid == null || totalObj.instituteid == undefined || totalObj.instituteid == "")
		{
			alert("Select college");
		}
		/*else if(totalObj.email == null || totalObj.email == undefined || totalObj.email == "")
		{
			alert("Enter valid email id");
		}
		else if(totalObj.phone == null || totalObj.phone == undefined || totalObj.phone == "")
		{
			alert("Enter mobile number start with 9 or 8 or 7 and should be 10 digits");
		}*/
		else
		{
			$http.post('/ccic/service/createLogin', totalObj).then(function(response)
			{
				$scope.data = response.data;
				if($scope.data.successful)
				{    
					$scope.credentials = $scope.data.responseObject;
					if($scope.credentials.userStatus == null || $scope.credentials.userStatus == undefined
							|| $scope.credentials.userStatus == "")
					{
						$("#loginsDiv").show();
						alert("Login credentials created successfully!!!");
					}        
					else
					{
						alert($scope.credentials.userStatus);
						$("#msgDiv").show();
					}
					jQuery("#glyphiconid").hide();
					$scope.data = {object : totalObj};
				}
				else
				{
					console.log("Client error while getting data");
					jQuery("#glyphiconid").hide();
				}
			},
			function(response)
			{
				alert($scope.data.errorMessage);
				console.log("Server error while getting data");
				jQuery("#glyphiconid").hide();
			});
		}
	};
	
	$scope.getLogins = function(totalObj)
	{
		jQuery("#glyphiconid").show();
		if(totalObj == null || totalObj == undefined || totalObj == "")
		{
			alert("Fill all details!");
		}
		else if(totalObj.districtId == null || totalObj.districtId == undefined || totalObj.districtId == "")
		{
			alert("Select district");
		}
		else if(totalObj.instituteid == null || totalObj.instituteid == undefined || totalObj.instituteid == "")
		{
			alert("Select college");
		}
		$http.post('/ccic/service/getLogins', totalObj.instituteid).then(function(response)
		{
			$scope.data = response.data;
			if($scope.data.successful)
			{
				$scope.users = $scope.data.responseObject;
				$scope.data = {object : totalObj};
				if($scope.users == null || $scope.users == undefined || $scope.users == "")
					$("#msgDiv").show();
				else
					$("#msgDiv").hide();
				$("#loginsDiv").show();
				$("#errorDiv").hide();
				jQuery("#glyphiconid").hide();
			}
			else
			{
				console.log("Client error while getting data");
				jQuery("#glyphiconid").hide();
			}
		},
		function(response)
		{
			$("#loginsDiv").hide();
			$("#errorDiv").show();
			$("#errorDiv").html("<b>" + $scope.data.errorMessage + "</b>");
			console.log("Server error while getting data");
			jQuery("#glyphiconid").hide();
		});
	};
	     
/*	//Get link for selected program
	$scope.getLink = function(selection)
	{
		
		console.log(selection);
		
		$http.post('/admin/service/getLink', selection).then(function(response){
			$scope.data = response.data;
			if($scope.data.successful)
			{
				$scope.message = $scope.data.responseObject;
			}
			else
			{
				console.log("Client error while getting link");
			}
		},
		function(response)
		{
			console.log("Server error while getting link");
		});
	};
	
	//Get student details based on aadhaar
	$scope.getStudentDetails = function(aadhaar)
	{
		if(aadhaar == "" || aadhaar == undefined || aadhaar == "" || aadhaar == 123412341234 || aadhaar == 999999999999)
		{
			alert("Invalid aadhaar");
		}
		else
		{
			$http.post('/admin/service/checkAadhaar',aadhaar).then(function(response){
			  $scope.data  = response.data;
			  if($scope.data.successful)
			  {
				 Andromeda.setSessionValue("aadhaar", aadhaar);
				 $scope.student = $scope.data.responseObject;
				 Andromeda.setSessionValue("trainingBatchId",  $scope.student.trainingBatchId);
				 
				 $(".studentResultTableDiv").show();
				 
				$http.get('/admin/service/getCollegeDetails').then(function(response){
					$scope.data = response.data;
					if($scope.data.successful)
					{
						$scope.colleges = $scope.data.responseObject.colleges;
						$scope.trainingPrgms = $scope.data.responseObject.trainingPrgms;
						$scope.prgms = $scope.data.responseObject.prgms;
					}
					else
					{
						console.log("Client error while getting data");
					}
				},
				function(response)
				{
					console.log("Server error while getting data");
				});
			  }
			  else
			  {
				  alert("Invalid aadhaar");
			  }
		   },
		   function(errResponse){
			  console.log("Error checking aadhaar validity");
		   });
		}
	};
	
	//Change student course
	$scope.changeCourse = function(student)
	{
		console.log(student);
		
		if(confirm("Are you sure want to change course?"))
		{
			var student = 
			{
				collegeId : student.collegeId,
				trainingBatchId : Andromeda.getSessionValue("trainingBatchId"),
				trainingProgramId : student.trainingProgramId,
				programId : student.programId,
				aadhaar : Andromeda.getSessionValue("aadhaar")
			};
			
		   $http.post('/admin/service/changeStudentCourse', student).then(function(response){
				$scope.data = response.data;
				if($scope.data.successful)
				{
					alert("Course changed successfully");
				}
				else
				{
					console.log("Client error while changing course");
				}
			},
			function(response)
			{
				console.log("Server error while changing course");
			});
		}
	};*/
	
}]);