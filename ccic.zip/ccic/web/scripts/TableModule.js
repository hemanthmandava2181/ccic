var Student = angular.module('TableModule', []);
var documentsArr = [];

Student.filter('numberFormat', function () {
	return function(input) {   
	     input = input || 0;
	     var out = new Intl.NumberFormat('en-IN').format(parseInt(input));
	     return out;
	};
})  
                                
.filter('sumOfValue', function() {
    return function(data, key) {
      if (angular.isUndefined(data) || angular.isUndefined(key))
        return 0;
      var sum = 0;
      angular.forEach(data, function(v, k) {
        sum = sum + parseInt(v[key]);
      });    
      return sum;  
    };
 })

.controller('TableController', ['$http','$scope', function($http, $scope) {
				   			     
					// View Data from Database
				var a=[Andromeda.getSessionValue("instituteid"),  
					Andromeda.getSessionValue("courseshortname")];
				a[0]=Andromeda.getSessionValue("instituteid");
				a[1] = Andromeda.getSessionValue("courseshortname");         
					$http.post('/ccic/Table/getAll',a).then(function(response) {
						$scope.data1 = response.data;
						if ($scope.data1.successful) {
							$scope.regdetails = $scope.data1.responseObject;
						} else {
							alert("Can't view the Data");
						}
					}, function(errResponse) {
						console.error('Error while viewing notes');
					});
					
	$scope.name=null,$scope.filteredResult = null;
					    
					$scope.getNameWiseData = function(obj) {      
						$scope.getBranchWisePrograms = function(totalObj)
						{
							Andromeda.setSessionValue("studentBranchId", totalObj.name);
							
							$("#glyphiconid").show();        
							$scope.name = totalObj.name;
							$http.post('/ccic/Table/getBranchWisePrograms', totalObj.name).then(function(response)
							{
								$scope.data = response.data;
								if($scope.data.successful)
								{
									$scope.regdetails = $scope.data.responseObject;
									/*$("#div1").hide();
									$("#lb6b").show();
									$("#div4").hide();*/
									$("#glyphiconid").hide();
								}
								else
								{    
									console.log("Client error while getting data");
								}
							},
							function(response)
							{
								console.log("Server error while getting data");
							});
						}; 
					} 
					
			//Update User Details
			$scope.updateData = function(Data){
			
				if(Data != undefined)
				{
					if(Data.dno == null || Data.dno == undefined || Data.dno == "")
					{
						swal("Oops","Please, Enter Door No ","info");
					}  
					else if(Data.village == null || Data.village == undefined || Data.village == "")
					{
						swal("Oops","Please, Enter Village ","info");
					}  
					else if(Data.mandal == null || Data.mandal == undefined || Data.mandal == "")
					{
						swal("Oops","Please, Enter Mandal ","info");
					}       
					else if(Data.district == null || Data.district == undefined || Data.district == "")
					{
						swal("Oops","Please, Enter District ","info");
					}    
					else if(Data.pincode == null || Data.pincode == undefined || Data.pincode == "")
					{
						swal("Oops","Please, Enter Pincode ","info");
					}       
					else 
					{
				    
				Data.institutioncode = Andromeda.getSessionValue("instituteid");
				Data.courseid = Andromeda.getSessionValue("courseshortname");
				Data.base64String=documentsArr[0].base64String;
				Data.fileName=documentsArr[0].fileName;
				Data.name=documentsArr[0].name;
				console.log(Data);
				$http.post('/ccic/Table/updateData', Data).then(
						function(response) {
							$scope.data2 = response.data;     
							if ($scope.data2.successful) {
							  alert("User Details Successfully updated");
							  Andromeda.showStudentRegistration2();   
							} else {
							  alert("Data not updated");
							}
						}, function(errResponse) {
						console.error('Error while fetching notes');
						});
					}
				}
			};
                         
			 $scope.uploadFiles = function(e)
		     {
		         var k= 0;
		         for(var i =	0;	i < e.files.length; i++)
		         {
		             var singleFileInfo = e.files[i];
		             (function(singleFileInfo)
		             {
		                 var fileReader;
		                 fileReader = new FileReader();
		                 fileReader.onload = function(e)
		                 {
		                     var fileName1 = singleFileInfo.name;
		                     filesize =  singleFileInfo.size;
		                     var fileDetails=fileName1.split(".");
		                     var fileName = "ccic_" + (k+1)+"."+fileDetails[1];
		                     var binaryString =  e.target.result;
		                     var base64 = btoa(binaryString);                     
		                     var fileModel =
		                         {
		                             fileName		:	fileName,
		                             base64String	: base64.toString(),
		                             name			: fileName
		                         };
		                      documentsArr[k] = fileModel;
		                     k++;
		                 };
		                 fileReader.readAsBinaryString(e.files[i]);
		             })(singleFileInfo);
		         }
//		         console.log(documentsArr);
		     }
			//Get Data from Database based on Name    
			$scope.getById = function(Data){
			Data.institutioncode = Andromeda.getSessionValue("instituteid");
			Data.courseid = Andromeda.getSessionValue("courseshortname");
			$http.post('/ccic/Table/getById',Data).then(function (response) {
			    $scope.data13 = response.data;
			    if ($scope.data13.successful) {
			        $scope.data = {object:$scope.data13.responseObject};
			    } else {
			    	//alert("Error while getting data");
			    	console.log("error")
			       
			    }
			}, function (errResponse) {
			   console.error('Error while fetching notes');    
			});   
			};       
			     
			
						          
		/*	$scope.save = function(){ 
				var institutioncode = Andromeda.getSessionValue("institutioncode");
				$http.post('/payment/payment/home', institutioncode).then(function(response) {
							$scope.data = response.data;
							if($scope.data.successful) {    
								//alert("Check your mail!");
								jQuery("#mainDiv").html($scope.data.responseObject.responseObject);
							} else{    
								alert("Link expired!");
							}
				});               
			};
			  */
			$scope.toggle = function(id)
    		{
    			$("#" + id).toggle();
    		};

		
		} ]);
