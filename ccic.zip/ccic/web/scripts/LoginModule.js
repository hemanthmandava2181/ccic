var LoginModule = angular.module('LoginModule', [])
LoginModule.controller('LoginController', [ '$http', '$scope', function($http, $scope) {
		var self = this;
		$scope.login = function(user) {
		//	 $("#glyphiconid").show();     
			
	        $http.post('/ccic/login/login',user).then(function(response) {
				$scope.data = response.data;    
				if($scope.data.successful) {
					Andromeda.setSessionValue("username", $scope.data.responseObject.username.replace(/\s+/g, ''));
					Andromeda.setSessionValue("password", $scope.data.responseObject.password);
		  			Andromeda.setSessionValue("role", $scope.data.responseObject.role);
		  			Andromeda.setSessionValue("instituteid", $scope.data.responseObject.instituteid);  
					Andromeda.setSessionValue("courseid", $scope.data.responseObject.courseid);
					Andromeda.setSessionValue("courseshortname", $scope.data.responseObject.courseshortname);
					Andromeda.setSessionValue("districtid", $scope.data.responseObject.districtid);
					Andromeda.setSessionValue("fee", $scope.data.responseObject.fee);
					Andromeda.setSessionValue("exmcentercode", $scope.data.responseObject.exmcentercode);
					//console.log(Andromeda.getSessionValue("courseid"));   
					  		if ((Andromeda.getSessionValue("role") == "admin")) {
				    			Andromeda.showAdminHomePage();    
				    		}   
				    		else if ((Andromeda.getSessionValue("role") == "principal")) { 
				    			Andromeda.showLoginHomePage();
				    		}   
				    		else if ((Andromeda.getSessionValue("role") == "HOD")) {   
				    			Andromeda.showHodHomePage();
				    		}     
				    		else {    
				    			 Andromeda.showHomePage();       
				         		}      
				        	     			      
					
	    
				} else {
				//	$("#glyphiconid").hide();
					//alert($scope.data.errorMessage);
					Andromeda.showError($scope.data.errorMessage);    
					var message = "<div class=\"alert alert-danger\"><strong>Error: </strong>"+ $scope.data.errorMessage + "</div>";
				   jQuery("#errorDiv").html(message);
					$("#errorDiv").show();
					$("#errorDiv").html("<b style='margin-left: 28%;font-size: medium;color:blue'>Note:</b> Invalid login credentials");
				//	console.log('Error while validating user');
				} 
			},function(errResponse) {
				console.error('Error while fetching notes');
			});
	    };    
	   
	    $scope.forgotPassword = function(email)
		{
			if(email != null)   
			{
				jQuery("#spinner").addClass("glyphicon glyphicon-refresh glyphicon-refresh-animate");
			//	alert(email);
				$http.post('/ccic/user/forg', email).then(function(response) 
				{
					$scope.data = response.data;
					if($scope.data.successful) 
					{
						jQuery("#spinner").removeClass("glyphicon glyphicon-refresh glyphicon-refresh-animate");
				alert("Your password is sent to your mail so,please check your mail");
						Andromeda.showLoginPage();
					}
					else 
					{
						jQuery("#spinner").removeClass("glyphicon glyphicon-refresh glyphicon-refresh-animate");
					//	alert($scope.data.errorMessage);
					}
				},
				function(errResponse) 
				{
				//	console.error('Error while fetching notes');
				});
			}
			else
			{
				//alert("Please enter email-Id");
			}
	    };
} ]);