var dataModule = angular.module("bulkPayment", ['angularUtils.directives.dirPagination'])
.filter('numberFormat', function () {
	return function(input) {
	     input = input || 0;  
	     var out = new Intl.NumberFormat('en-IN').format(parseInt(input));
	     return out;
	};  
})
    
.filter('sumOfValue', function() {    
    return function(data, key) {
      if (angular.isUndefined(data) || angular.isUndefined(key))
        return 0;
      var sum = 0;
      angular.forEach(data, function(v, k) {  
        sum = sum + parseInt(v[key]);
      });      
      return sum;  
    }
 })    
.controller("FormController", ["$scope","$http", function($scope,$http)
	{
	    var studentID;  
	    $scope.coePaymentStudents = [];
	    $scope.studentFilteredResult = [];
		$scope.studentsPresentArr = [];
		var id= Andromeda.getSessionValue("centerId");  
		
	if(id <= 6){   
	      
		
	$http.get('/siemens/report/getCOEPaymentCourses').then(function(response)
			{
				$scope.data1 = response.data;
				if($scope.data1.successful)       
				{        
					$("#glyphiconid1").hide();       
					$("#glyphiconid2").hide();         
					
					$scope.coePaymentDomains = $scope.data1.responseObject.coePaymentDomains;
					
					if($scope.coePaymentDomains.length == 0)      
					{       
						      
						$("#errorDiv").show();
						$("#coursewiseDiv").hide();    
						$("#coePaymentCoursesDiv").hide();
						$("#registeredListDiv").hide(); 
						$("#Div3").hide();
						
						
					}  
				else{  
					$("#errorDiv").hide();
					$("#coursewiseDiv").show();
					$("#coePaymentCoursesDiv").hide();
					$("#registeredListDiv").hide(); 
					$("#Div3").hide();
					
				}  
					
				}      
				else    
				{
					$("#glyphiconid1").hide();
					$("#glyphiconid2").hide();
					console.log("Client error while getting data");
				}
			},
			function(response)
			{
				$("#glyphiconid1").hide();
				$("#glyphiconid2").hide();
				console.log("Server error while getting data");
			});
	
	}
	else{
		
		        
	}     
	  
	
	$scope.getPaymentStudents = function(data){
		
		var id= Andromeda.getSessionValue("centerId");  
		Andromeda.setSessionValue("coursecode",data.coursecode);
		Andromeda.setSessionValue("coursename",data.coursename);
		
		if(id<=6)
		{    
		   var obj = {  
				   
				   coursecode : data.coursecode,
				   id : id
				  
		    }  
		$http.post('/siemens/report/getCOEPaymentStudents',obj).then(function(response)
				{
					$scope.data1 = response.data;
					if($scope.data1.successful)               
					{            
						$("#glyphiconid1").hide();           
						$("#glyphiconid2").hide();             
						    
						$scope.coePaymentStudents = $scope.data1.responseObject.coePaymentStudents;
						
						if($scope.coePaymentStudents.length == 0)      
						{         
							       
							$("#errorDiv").show();
							$("#coursewiseDiv").hide(); 
							$("#coePaymentCoursesDiv").hide();  
							$("#registeredListDiv").hide(); 
							$("#Div3").hide();
							
							
						}    
					else{  
						$("#errorDiv").hide();
						$("#coursewiseDiv").hide();
						$("#coePaymentCoursesDiv").hide();  
						$("#registeredListDiv").show(); 
						$("#Div3").hide();
						
					}  
						
					}      
					else          
					{
						$("#glyphiconid1").hide();
						$("#glyphiconid2").hide();
						console.log("Client error while getting data");
					}
				},
				function(response)
				{
					$("#glyphiconid1").hide();
					$("#glyphiconid2").hide();
					console.log("Server error while getting data");
				});
		}
		
	}
	  
	$scope.getCourses = function(data){
		$scope.domain = data.domain;
		Andromeda.setSessionValue("coedomain",data.domain);
		var id= Andromeda.getSessionValue("centerId");  
		if(id<=6)
		{
		   var obj = {
				   
				   coedomain : data.domain,
				   id : id  
				
		    }    
		$http.post('/siemens/report/getCOEPayments',obj).then(function(response)
				{  
					$scope.data1 = response.data;
					if($scope.data1.successful)         
					{        
						$("#glyphiconid1").hide();           
						$("#glyphiconid2").hide();             
						  
						$scope.coePaymentCourses = $scope.data1.responseObject.coePaymentCourses;
						
						if($scope.coePaymentCourses.length == 0)      
						{       
							       
							$("#errorDiv").show();
							$("#coursewiseDiv").hide(); 
							$("#coePaymentCoursesDiv").hide();
							$("#registeredListDiv").hide(); 
							$("#Div3").hide();
							
						}  
					else{  
						$("#errorDiv").hide();
						$("#coursewiseDiv").hide();
						$("#coePaymentCoursesDiv").show();  
						$("#registeredListDiv").hide();
						$("#Div3").hide();
						
					}  
						
					}      
					else          
					{
						$("#glyphiconid1").hide();
						$("#glyphiconid2").hide();
						console.log("Client error while getting data");
					}
				},
				function(response)
				{
					$("#glyphiconid1").hide();
					$("#glyphiconid2").hide();
					console.log("Server error while getting data");
				});
		}
		
	};
	
	$scope.savePaymentDetails = function(studentsPresentArr)
	{
		console.log(studentsPresentArr);
		$scope.totalLength = 0;
		$scope.totalAmount = 0;
		$scope.arr = [];         
		$scope.studentList = {};
		
		var coursecode = Andromeda.getSessionValue("coursecode");
		var coedomain = Andromeda.getSessionValue("coedomain");
		var coursename = Andromeda.getSessionValue("coursename");
		
		//studentID = $scope.studentFilteredResult[0]['id'];
		 if(studentsPresentArr != null)
		 {

			 for(var i in studentsPresentArr)
			 {
				 if(studentsPresentArr[i]== true)
				   {
					   
			$scope.student = {};    
						
			for(var j = 0; j < $scope.coePaymentStudents.length; j++)
			{
				var temp = $scope.coePaymentStudents[j];  
				
				
				if((studentsPresentArr[i] == true) && (i == temp['id']))
				{  
					$scope.student.aadhaar = temp['aadhaar'];
					$scope.student.id = temp['id'];  
					$scope.student.name = temp['name'];    
					$scope.student.email = temp['email'];    
					$scope.student.phone = temp['phone'];
					$scope.student.highestqualification = temp['highestqualification'];
					$scope.coursecode = coursecode;
					$scope.coedomain = coedomain; 
					$scope.coursename = coursename;
					$scope.student.fee = temp['fee'];   
					$scope.totalLength = $scope.totalLength + 1;  
					$scope.totalAmount = $scope.totalAmount + parseInt(temp['fee']);    
					$scope.arr.push($scope.student);  
				}  
				console.log($scope.student);  
				console.log($scope.totalAmount);
			}
			$scope.arr.push($scope.student);
		}
		  
		 }  
		 }
		$scope.studentList.studentList = $scope.arr;  
		
		console.log($scope.arr);    
		
		Andromeda.setSessionValue("studentList", btoa(JSON.stringify($scope.studentList)));
		      
		var object =  
		{
			students: $scope.totalLength,
			amount: $scope.totalAmount,
			studentList: btoa(JSON.stringify($scope.studentList)),
			coursecode: $scope.coursecode
		};    
		  
		Andromeda.setSessionValue("Base64String", btoa(JSON.stringify($scope.studentList)));
		
		$scope.payment = {object: object};
		$("#errorDiv").hide();		
		$("#coursewiseDiv").hide();
		$("#coePaymentCoursesDiv").hide();   
		$("#registeredListDiv").hide(); 
		$("#Div3").show(); 
		$("#spinner").hide();

		var data =  
			{
				inchargeEmail : Andromeda.getSessionValue("userName")
			};
		$scope.data = {object : data};    
	};
	    
	$scope.pay = function(allDetails, paymentCountDetails)
	{
		if(allDetails == null || allDetails == undefined || allDetails == "")
		{
			alert("Fill all details");
		}
		else if(allDetails.aadhaar == null || allDetails.aadhaar == undefined || allDetails.aadhaar == "" ||
				allDetails.aadhaar == "123412341234" || allDetails.aadhaar == "999999999999")
		{
			alert("Enter adhaar number");
		}
		else if(allDetails.spocName == null || allDetails.spocName == undefined || allDetails.spocName == "")
		{
			alert("Enter name");
		}    
		
		else if(allDetails.spocEmail == null || allDetails.spocEmail == undefined || allDetails.spocEmail == "")
		{
			alert("Enter valid mail id");
		}  
		else if(allDetails.phone == null || allDetails.phone == undefined || allDetails.phone == "")
		{
			alert("Mobile number starts with 9 or 8 or 7 or 6 and should be 10 digits");
		}
		else     
		{      
			var status = confirm("A confirmation mail will be sent to \nEmail: " + allDetails['spocEmail'] + " \nAre you sure want to proceed?");
			if(status)  
			{            
						allDetails['centerId'] = Andromeda.getSessionValue("centerId");      

						paymentCountDetails.aadhaar = allDetails['aadhaar'];
						paymentCountDetails.email = allDetails['spocEmail'];
						paymentCountDetails.name = allDetails['spocName'];
						paymentCountDetails.phone = allDetails['phone'];  
						paymentCountDetails.centerId = Andromeda.getSessionValue("centerId");
						paymentCountDetails.course = Andromeda.getSessionValue("coursename");
						paymentCountDetails.logUser = Andromeda.getSessionValue("userName");
						
						$scope.data = {object : paymentCountDetails};     
						console.log($scope.data);
						  
						jQuery("#spinner").show();		  		  	  
						  
						$http.post('/siemens/payment/paymentOption', paymentCountDetails).then(function(response) {
							$scope.data = response.data;
							if($scope.data.successful) {
								
								paymentCountDetails.bulkPaymentKey = $scope.data.responseObject;
								console.log(paymentCountDetails);
								$http.post('/siemenspayment/payment/bulkPayment', paymentCountDetails).then(function(response)
								{
									$scope.data = response.data;  
									if($scope.data.successful)    
									{
										$scope.paymentResponse = $scope.data.responseObject.responseObject;
										console.log("Response:"+$scope.paymentResponse);
										jQuery("#paymentDiv").html($scope.paymentResponse);
									}     
									else        
									{
										console.log("Client error while getting college data");
									}
								},
								function(response)
								{
									console.log("Server error while getting college data");
								});
								     
							}
						});
							
		    
						
						
			}
		}
	};
	$scope.exportDistrictWiseDatatoExcel = function()  
	{  
		var blob = new Blob([document.getElementById('districtWiseReportDiv').innerHTML], { 
	        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8" 
	    }); 
	    var fileName = "DistrictWiseReport.xls";   
	    saveAs(blob, fileName); 
	};        
	
	$scope.toggleRegisteredStudents = function()
	{
		$("#registeredStudentsSearchRow").toggle();
	};
	
	$scope.setAllRegIds = function(allStudents)
	{
		if(allStudents == true)
		{
			for(var i = 0; i < $scope.studentFilteredResult.length; i++)
			{
				var id = $scope.studentFilteredResult[i]['id'];
				$scope.studentsPresentArr[id] = true;  
			}
		}   
		else if(allStudents == false)       
		{
			$scope.studentsPresentArr = [];
		}
	};
	
	$scope.exportRegisteredStudentsDatatoExcel = function()  
	{    
		var blob = new Blob([document.getElementById('registeredListDiv').innerHTML], { 
	        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8" 
	    }); 
	    var fileName = "PaymentPendingReport.xls";   
	    saveAs(blob, fileName); 
	}; 
	$scope.exportCenterWiseDatatoExcel = function()  
	{  
		var blob = new Blob([document.getElementById('coetsdiWiseReportDiv').innerHTML], { 
	        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8" 
	    }); 
	    var fileName = "CenterTypeWiseReport.xls";   
	    saveAs(blob, fileName); 
	};  
	  
	
	$scope.exportclusterWiseDatatoExcel = function()  
	{  
		var blob = new Blob([document.getElementById('coeclusterWiseReportDiv').innerHTML], { 
	        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8" 
	    }); 
	    var fileName = "ClusterWiseReport.xls";   
	    saveAs(blob, fileName);    
	};
	  
	
	
	$scope.exportQualificationWiseDatatoExcel = function()  
	{  
		var blob = new Blob([document.getElementById('qualificationWiseReportDiv').innerHTML], { 
	        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8" 
	    }); 
	    var fileName = "QualificationWiseReport.xls";   
	    saveAs(blob, fileName);      
	};
	
	
	}]);