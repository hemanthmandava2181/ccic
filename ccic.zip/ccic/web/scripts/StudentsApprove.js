var creationModule = angular.module('StudentsApprove', []);
creationModule.filter('numberFormat', function () {
	return function(input) {   
	     input = input || 0;
	     var out = new Intl.NumberFormat('en-IN').format(parseInt(input));
	     return out;
	};
})  

.filter('sumOfValue', function() {
    return function(data, key) {
      if (angular.isUndefined(data) || angular.isUndefined(key))
        return 0;
      var sum = 0;
      angular.forEach(data, function(v, k) {
        sum = sum + parseInt(v[key]);
      });
      return sum;
    };           
 })    
creationModule.controller('StudentsApproveController',['$scope','$http',function($scope,$http)
{
	$scope.filteredResult = [], $scope.studentFilteredResult = [], $scope.studentsPaymentArr = [],
	$scope.totalLength = 0, $scope.totalAmount = 0, $scope.paidDetails = [];
		      
	
		      
	$http.get('/ccic/StudentsApprove/getDistricts').then(function(response){
		$scope.data61 = response.data;
		if($scope.data61.successful)
		{
			$scope.districts = $scope.data61.responseObject;
		}
		else
		{
			console.log("Client error while getting data");
		}
	},
	function(response)  
	{	
		console.log("Server error while getting data");
	});
	                                                  
	$scope.getColleges = function(districtid)
	{
		
		
		$http.post('/ccic/StudentsApprove/getColleges',districtid).then(function(response){
			$scope.data62 = response.data;
			if($scope.data62.successful)
			{
				
				$scope.colleges = $scope.data62.responseObject;
				/*$scope.data = {object : totalObj};*/
			}
			else
			{
				console.log("Client error while getting data");
			}
		},
		function(response)
		{
			console.log("Server error while getting data");
		});
	};
	
	$scope.getCourses = function(instituteid)
	{
		Andromeda.setSessionValue("instituteid",instituteid);
	   $http.post('/ccic/StudentsApprove/getCourses',instituteid).then(function(response){
		
		$scope.data61 = response.data;
		//console.log(response)
		if($scope.data61.successful)  
		{  
			$scope.courses = $scope.data61.responseObject;
			//console.log('dadvSDdgas'+response.data.responseObject['0'].courseshortname);  
			Andromeda.setSessionValue("courseshortname", response.data.responseObject['0'].courseshortname);
			
			
			
		}   
		else                  
		{    
			console.log("Client error while getting data");
		}                      
	},
	function(response)  
	{	
		console.log("Server error while getting data");    
	});
	};
	$scope.getAll = function(courseid)
	{
		var a = [Andromeda.getSessionValue("instituteid"),Andromeda.getSessionValue("courseshortname")];
		 a[0] = Andromeda.getSessionValue("instituteid");  
		 a[1] = Andromeda.getSessionValue("courseshortname");
	$http.post('/ccic/StudentsApprove/getAll',a).then(function(response){
		$scope.data61 = response.data;   
		if($scope.data61.successful)   
		{
			$scope.regdetails = $scope.data61.responseObject;
		}
		else               
		{
			console.log("Client error while getting data");
		}                      
	},
	function(response)  
	{	
		console.log("Server error while getting data");    
	});
	};   
	
	
	$scope.setAllRegIds = function(allStudents)
	{
		if(allStudents == true)
		{
			for(var i = 0; i < $scope.studentFilteredResult.length; i++)
			{
				var applicationid = $scope.studentFilteredResult[i]['applicationid'];
				console.log(applicationid);
				$scope.studentsPaymentArr[applicationid] = true;
			}
		}
		else if(allStudents == false)
		{
			$scope.studentsPaymentArr = [];
		}
		            			
	};         
	
	
	   
	$scope.savePaymentDetails = function(studentsPaymentArr)
	{
			
		$scope.totalLength = 0;
		$scope.totalAmount = 0;
		$scope.arr = [];                       
		$scope.studentList = {};
		 if(studentsPaymentArr != null)
		 {      
		for(var i in studentsPaymentArr)      
		{
			if(studentsPaymentArr[i]== true)
			   {          
  			$scope.student = {};    
			
			for(var j = 0; j < $scope.studentFilteredResult.length; j++)
			{
				var temp = $scope.studentFilteredResult[j];
				                            
				if((studentsPaymentArr[i] == true) && (i == temp['applicationid']))
				{
					$scope.student.name = temp['name'];
					$scope.student.email = temp['email'];
					$scope.student.applicationid = temp['applicationid'];   
					$scope.totalLength = $scope.totalLength + 1;
					$scope.totalAmount = $scope.totalAmount + parseInt(temp['fee']);
					$scope.arr.push($scope.student);
		        	var a=$scope.student.applicationid;
		        	
		        	var a=[$scope.student.applicationid,  
		        		$scope.student.name];
					a[0]=$scope.student.applicationid;
					a[1] = $scope.student.name;       
		       
		        	$http.post('/ccic/StudentsApprove/updateData', a[0]).then(function(response) {
								$scope.data2 = response.data;      
								if ($scope.data2.successful) {
								
			   					  
								} else {
								  alert("Data not updated");       
								}
							}, function(errResponse) {
							console.error('Error while fetching notes');
							});
			  		}   
				                    
			}   
			
			$scope.arr.push($scope.student);
		}  
			  
		 }
		alert("User Details Successfully updated");
		 }
		 };   
	
	
	
}]);