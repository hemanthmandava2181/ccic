package com.spring.Model;

import com.andromeda.commons.model.BaseModel;

public class HodCreation extends BaseModel
{
	private Integer courseid;
	private Integer userid;
	private String hodname;
	private String institutename;
	private String districtname;
	private Integer instituteid;
    private String hodmobileno;
	private String hodemail;     
	private String courseshortname;     
	private String password;
	private String enyptPassword;
	private String ipAddress;        
	private Integer id;
	private String pwd;
	private String userStatus;
	private String role;
	public Integer status;
	public Integer districtid;
    public String username; 
    public float fee;
    
    
	public float getFee() {
		return fee;
	}
	public void setFee(float fee) {
		this.fee = fee;
	}
	public String getCourseshortname() {
		return courseshortname;
	}
	public void setCourseshortname(String courseshortname) {
		this.courseshortname = courseshortname;
	}
	public Integer getDistrictid() {
		return districtid;
	}
	public void setDistrictid(Integer districtid) {
		this.districtid = districtid;
	}
	public String getDistrictname() {
		return districtname;
	}
	public void setDistrictname(String districtname) {
		this.districtname = districtname;
	}
	public Integer getCourseid() {
		return courseid;
	}
	public void setCourseid(Integer courseid) {
		this.courseid = courseid;
	}
	
	public Integer getUserid() {
		return userid;
	}
	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	public String getHodname() {
		return hodname;
	}
	public void setHodname(String hodname) {
		this.hodname = hodname;
	}
	public String getInstitutename() {
		return institutename;
	}
	public void setInstitutename(String institutename) {
		this.institutename = institutename;
	}
	public Integer getInstituteid() {
		return instituteid;
	}
	public void setInstituteid(Integer instituteid) {
		this.instituteid = instituteid;
	}
	public String getHodmobileno() {
		return hodmobileno;
	}
	public void setHodmobileno(String hodmobileno) {
		this.hodmobileno = hodmobileno;
	}
	public String getHodemail() {
		return hodemail;
	}
	public void setHodemail(String hodemail) {
		this.hodemail = hodemail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEnyptPassword() {
		return enyptPassword;
	}
	public void setEnyptPassword(String enyptPassword) {
		this.enyptPassword = enyptPassword;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getUserStatus() {
		return userStatus;
	}
	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}     

  

}