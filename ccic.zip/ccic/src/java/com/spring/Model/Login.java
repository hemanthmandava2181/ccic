package com.spring.Model; 

import com.andromeda.commons.model.BaseModel;

public class Login extends BaseModel
{
	
	private static final long serialVersionUID = 1L;
	private String username;
	private String password;
	private String ipaddress;    
	private String logtime;        
	private String role;
	public Integer instituteid;
	public Integer courseid;
	public Integer districtid;
	private String courseshortname;
	public float fee;
	public Integer exmcentercode;
	public String centername;
	
	
	
	public Integer getExmcentercode() {
		return exmcentercode;
	}

	public void setExmcentercode(Integer exmcentercode) {
		this.exmcentercode = exmcentercode;
	}

	public String getCentername() {
		return centername;
	}

	public void setCentername(String centername) {
		this.centername = centername;
	}

	
	
	  
    
	public float getFee() {
		return fee;
	}

	public void setFee(float fee) {
		this.fee = fee;
	}

	public String getCourseshortname() {
		return courseshortname;
	}

	public void setCourseshortname(String courseshortname) {
		this.courseshortname = courseshortname;
	}

	public Integer getDistrictid() {
		return districtid;
	}

	public void setDistrictid(Integer districtid) {
		this.districtid = districtid;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}  

	public Integer getCourseid() {
		return courseid;
	}

	public void setCourseid(Integer courseid) {
		this.courseid = courseid;
	}

	public String getLogtime() {
		return logtime;
	}

	public void setLogtime(String logtime) {
		this.logtime = logtime;
	}

		public String getIpaddress() {
		return ipaddress;
	}

	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}

		public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword()
	{
		return password;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}   

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Integer getInstituteid() {
		return instituteid;
	}

	public void setInstituteid(Integer instituteid) {
		this.instituteid = instituteid;
	}
	
}