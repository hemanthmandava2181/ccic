package com.spring.Controller;
import java.io.File;
import java.io.FileOutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.andromeda.commons.model.Response;
import com.andromeda.commons.util.HttpUtils;

import com.spring.Model.Table;
import com.spring.Service.TableService;
import com.spring.Model.FileModel;
import commons.util.Base64;

@RestController
@RequestMapping("/Table")
public class TableController {
    String file = null;           
    Response response = new Response();
	@Autowired     
	private TableService tableService;
	
	@ResponseBody              
	@RequestMapping(value = "getNameWiseData", method = { RequestMethod.POST, RequestMethod.GET })
	public Response getNameWiseData(@RequestBody Table table)
	{
			return tableService.getNameWiseData(table);
	}
	
	
	@ResponseBody   
	@RequestMapping(value = "getAll", method = { RequestMethod.POST, RequestMethod.GET })
	public Response getAll(@RequestBody String[] stu)
	{
		String institutioncode = stu[0];
		String courseid = stu[1];
		return tableService.getAll(institutioncode,courseid);
	}
	
	@ResponseBody
	@RequestMapping(value = "getById", method = { RequestMethod.POST })
	public Response getById(@RequestBody Table table)
	{
		
		return tableService.getById(table);
	}
	

	
	@ResponseBody
	@RequestMapping(value = "updateData", method = { RequestMethod.POST })
	public Response updateData(@RequestBody Table table)
	{
		handleFileUpload(table);
		table.setImage_path(file);
		return tableService.updateData(table);
	}
	
	
	public String handleFileUpload(Table table)
	{
		FileOutputStream fos = null;

		try
		{
			String folderName = "ccic";
			String imageValue = table.getBase64String();
			byte[] imageByteArray = decodeImage(imageValue);

			String baseDir = System.getProperty("catalina.base") + "/webapps/uploads/" + "ccic" + "/"
					+ folderName;
			File dir = new File(baseDir);
			if (!Files.isDirectory(Paths.get(baseDir)))
			{
				dir.mkdirs();
			}
			
			String ccicFileName = UUID.randomUUID().toString();
			
			fos = new FileOutputStream(baseDir + "/" + ccicFileName+".png");
			file = "/uploads/" + "ccic" + "/" + folderName + "/" + ccicFileName+".png";
			fos.write(imageByteArray);
			fos.close();

			System.out.println("---Path--> " + file);
		}
		catch (Exception e)
		{
			System.out.println("Exception: " + e.getMessage());
		} 
		return file.trim();
	}
	public static byte[] decodeImage(String imageValue)
	{
		return Base64.decode(imageValue);
	}
}
/*@ResponseBody 
@RequestMapping(value = "add", method = { RequestMethod.POST })
public Response add(@RequestBody Table table, HttpServletRequest httpServletRequest)
		throws UnsupportedEncodingException, NoSuchAlgorithmException
{
	//String clientProxyIp = HttpUtils.getClientProxyAddress(httpServletRequest);
	String clientIp = HttpUtils.getClientAddress(httpServletRequest);
	String ipaddress = "CLIENT:" + clientIp;// + ", CLIENT_PROXY:" + clientProxyIp;
	table.setIpaddress(ipaddress);

	return tableService.add(table);
}*/

/*@ResponseBody
@RequestMapping(value = "removeData", method = { RequestMethod.POST })
public Response remove(@RequestBody String name)
{
	return libService.remove(name);
}

*/