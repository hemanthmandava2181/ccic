package com.spring.Controller;



import java.util.jar.JarException;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.andromeda.commons.model.Response;
import com.andromeda.commons.util.HttpUtils;
import com.spring.Model.PayStudent;
import com.spring.Service.PayStudentService;

@RestController
@RequestMapping("/PayStudent")
public class PayStudentController {
    
	
	@Autowired     
	private PayStudentService payStudentService;
	
	@ResponseBody
	@RequestMapping(value = "getNameWiseData", method = { RequestMethod.POST, RequestMethod.GET })
	public Response getNameWiseData(@RequestBody PayStudent payStudent)
	{
			return payStudentService.getNameWiseData(payStudent);
	}
	
	@ResponseBody   
	@RequestMapping(value = "getAll", method = { RequestMethod.POST, RequestMethod.GET })
	public Response getAll(@RequestBody String[] stu)
	{
		String institutioncode = stu[0];
		String courseid = stu[1];
		return payStudentService.getAll(institutioncode,courseid);
	}
	
	@ResponseBody   
	@RequestMapping(value = "getBacklogAll", method = { RequestMethod.POST, RequestMethod.GET })
	public Response getBacklogAll(@RequestBody String[] stu)
	{
		String institutioncode = stu[0];
		String courseid = stu[1];
		return payStudentService.getBacklogAll(institutioncode,courseid);
	}
	
	@ResponseBody     
	@RequestMapping(value = "getSubjects", method = { RequestMethod.POST, RequestMethod.GET })
	private Response getSubjects(@RequestBody String courseid)
	{
		System.out.println(courseid);
		/*System.out.println(stu[0]);
		System.out.println(stu[1]);*/
		return payStudentService.getSubjects(courseid);
	}
	
	             
	@ResponseBody    
	@RequestMapping(value = { "paymentOption" }, method = { RequestMethod.POST })
	public Response paymentOption(@RequestBody PayStudent paystudent, HttpServletRequest httpServletRequest) throws JSONException, JarException
	{
		String clientProxyIp = HttpUtils.getClientProxyAddress(httpServletRequest);
		String clientIp = HttpUtils.getClientAddress(httpServletRequest);
		String ipAddress = "CLIENT:" + clientIp + ", CLIENT_PROXY:" + clientProxyIp;
		paystudent.setIpaddress(ipAddress);
		/*System.out.println("-----Payment");     
		System.out.println(payment);*/     
		return payStudentService.paymentOption(paystudent);                 
	}   
	      
}
