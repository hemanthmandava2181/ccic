package com.spring.Controller;

import com.spring.Model.Student;
import com.spring.Model.StudentsApprove;
import com.spring.Model.Table;
import com.spring.Service.StudentsApproveService;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.andromeda.commons.model.Response;
import com.andromeda.commons.util.HttpUtils;

@RestController
@RequestMapping("/StudentsApprove")
public class StudentsApproveController
{
	@Autowired
	StudentsApproveService studentsApproveService;

    @ResponseBody
	@RequestMapping(value = "/getDistricts", method = { RequestMethod.POST, RequestMethod.GET })
	private Response getDistricts()
	{
		return studentsApproveService.getDistricts();
	}

	@ResponseBody
	@RequestMapping(value = "/getColleges", method = { RequestMethod.POST })
	private Response getColleges(@RequestBody Integer districtid)    
	{
		System.out.println(districtid);
		return studentsApproveService.getColleges(districtid);
	}
	@ResponseBody
	@RequestMapping(value = "/getCourses", method = { RequestMethod.POST })
	private Response getCourses(@RequestBody String instituteid) 
	{
		return studentsApproveService.getCourses(instituteid);
	}
	
	@ResponseBody
	@RequestMapping(value = "/getAll", method = { RequestMethod.POST })
	private Response getAll(@RequestBody String[] studentsApprove)
	{    
		String instituteid = studentsApprove[0];
		String courseid = studentsApprove[1];
		System.out.println("instituteid" + instituteid + "courseid" + courseid);
		return studentsApproveService.getAll(instituteid,courseid);
	}

	@ResponseBody
	@RequestMapping(value = "updateData", method = { RequestMethod.POST })
	public Response updateData(@RequestBody String applicationid)
	{
		return studentsApproveService.updateData(applicationid);
	}
	   
	@ResponseBody
	@RequestMapping(value = "generateHallTicket", method = { RequestMethod.POST })
	public Response generateHallTicket(@RequestBody String[] studentsApprove)
	{
		String applicationid = studentsApprove[0];
		String name = studentsApprove[1];
		System.out.println("instituteid" + applicationid + "courseid" + name);
		return studentsApproveService.generateHallTicket(applicationid,name);
	}
	
	
}