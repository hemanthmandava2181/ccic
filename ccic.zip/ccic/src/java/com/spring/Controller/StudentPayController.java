package com.spring.Controller;

                                 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.andromeda.commons.model.Response;

import com.spring.Model.StudentPay;

import com.spring.Service.StudentPayService;

@RestController                    
@RequestMapping("/StudentPay")
public class StudentPayController {
                
	
	@Autowired     
	private StudentPayService studentPayService;
	                                               
	@ResponseBody  
	@RequestMapping(value = "getByApplicationId", method = { RequestMethod.POST })
	public Response getById(@RequestBody String applicationid)
	{
		
		return studentPayService.getByApplicationId(applicationid);           
	}
	
	@ResponseBody       
	@RequestMapping(value = "getSubject", method = { RequestMethod.POST, RequestMethod.GET })
	private Response getSubjects(@RequestBody String applicationid)
	{
		return studentPayService.getSubjects(applicationid);
	}
	@ResponseBody
	@RequestMapping(value = "generateHallTicket", method = { RequestMethod.POST })
	public Response generateHallTicket(@RequestBody String applicationid)
	{
	
		return studentPayService.generateHallTicket(applicationid);
	}
	
}
