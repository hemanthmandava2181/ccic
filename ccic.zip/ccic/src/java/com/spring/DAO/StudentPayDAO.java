package com.spring.DAO;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Iterator;



import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.jfree.ui.Align;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.spring.Model.StudentPay;



@Repository
public class StudentPayDAO extends BaseDAO {    
@Autowired    
private SqlSessionFactory sqlSessionFactory;
	
public StudentPay getByApplicationId(String applicationid)
	{ 
		SqlSession sqlSession = sqlSessionFactory.openSession();
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("applicationid", applicationid);
		StudentPay userDetails = sqlSessionTemplate.selectOne("StudentPay.getByApplicationId",params);
		sqlSession.close();   
		return userDetails;               
	}                                       
	
	public List<Map<String, Object>> getSubjects(String applicationid)   
	{
		SqlSession sqlSession = sqlSessionFactory.openSession();
		Map<String, Object> params = new HashMap<String, Object>();   
		params.put("applicationid",applicationid);     
		List<Map<String, Object>> userdetails = sqlSessionTemplate.selectList("StudentPay.getSubjects",params);
		sqlSession.close();
		return userdetails;
	}     
	
	public String generateHallTicket(String applicationid)     
	{  
		Document document1 = new Document();       
		 Rectangle rect= new Rectangle(577,825,15,15);   
		 
		File z=new File(System.getProperty("catalina.base")+"/webapps/uploads/ccic/pdf/"+"Hallticket_"+applicationid+".pdf");
		Font bfBold12 = new Font(FontFamily.TIMES_ROMAN, 13, Font.BOLD, new BaseColor(0, 0, 0)); 
		Font bfBold6 = new Font(FontFamily.TIMES_ROMAN, 12, Font.BOLD, new BaseColor(0, 0, 0));
		//Font bfBold1 = new Font(FontFamily.TIMES_ROMAN, 12);
		Font bf12 = new Font(FontFamily.TIMES_ROMAN, 12);   
        
	       
		String pdfFilename =
				System.getProperty("catalina.base") + "/webapps/uploads/ccic/pdf/"+"Hallticket_"+applicationid+".pdf";  
	    try {
	    	
	    	SqlSession sqlSession = sqlSessionFactory.openSession();   
			
	    	StudentPay studentpay= sqlSession.selectOne("StudentPay.getapplname",applicationid);
	    	StudentPay studentpay1= sqlSession.selectOne("StudentPay.getInstCode",applicationid);
	    	int exmcentercode =studentpay.getExmcentercode();
	    	String courseid = studentpay.getCourseid();
	    	StudentPay studentpay3= sqlSession.selectOne("StudentPay.getExamCenter",exmcentercode);
	    	StudentPay studentpay4= sqlSession.selectOne("StudentPay.getInstName",courseid);
		   
		    PdfWriter writer = PdfWriter.getInstance(document1, new FileOutputStream(pdfFilename));  
			document1.open();      
		     rect.enableBorderSide(1);             
		     rect.enableBorderSide(2);              
		     rect.enableBorderSide(4);
		     rect.enableBorderSide(8);
		     rect.setBorderColor(BaseColor.BLACK);   
		     rect.setBorderWidth(2);
		     document1.add(rect);
			   
		     String a = "STATE BOARD OF TECHNICAL EDUCATION AND TRAINING.";	    
		  	 Chunk chunk1 = new Chunk(a);      
			 chunk1.setFont(new Font(FontFamily.TIMES_ROMAN,18,Font.BOLD));          
			 Paragraph para2 = new Paragraph(chunk1.toString());
			 para2.setFont(new Font(FontFamily.TIMES_ROMAN,18,Font.BOLD));
			 para2.setAlignment(Paragraph.ALIGN_CENTER);      
			// para2.setSpacingAfter(30);      
			 document1.add(para2);
			    
			 String b = "A.P. CRAFT AND COMPUTER CERTIFICATE COURSES  EXAMINATIONS";	
		  	 Chunk chunk12 = new Chunk(b);      
		  	chunk12.setFont(new Font(FontFamily.TIMES_ROMAN,18,Font.BOLD));          
			 Paragraph para3 = new Paragraph(chunk12.toString());
			 para3.setFont(new Font(FontFamily.TIMES_ROMAN,16,Font.BOLD));
			 para3.setAlignment(Paragraph.ALIGN_CENTER);
			 para3.setSpacingAfter(10);      
			 document1.add(para3);   
			 
			     
			 String c = "ORIGINAL HALL TICKET";	
		  	 Chunk chunk3 = new Chunk(c);      
			 chunk3.setFont(new Font(FontFamily.TIMES_ROMAN,16,Font.BOLD));          
			 Paragraph para4 = new Paragraph(chunk3.toString());
			 para4.setFont(new Font(FontFamily.TIMES_ROMAN,16,Font.BOLD));
			 para4.setAlignment(Paragraph.ALIGN_CENTER);
			 para4.setSpacingAfter(10);                           
			 document1.add(para4);
			    
			         
			  PdfPTable table101 = new PdfPTable(2);
				 table101.setWidthPercentage(90);         
				 PdfPCell cellOne101 = new PdfPCell(new Phrase("Dist. Name:",bfBold6));
				 PdfPCell cellTwo101 = new PdfPCell(new Phrase(" Institution Name: ",bfBold6));
				// PdfPCell cellThree101 = new PdfPCell(new Phrase(" Course Name : ",bf12));
				// PdfPCell cellFour101 = new PdfPCell(new Phrase(" Photo : ",bf12));
				 cellOne101.setBorder(Rectangle.NO_BORDER);
				 cellTwo101.setBorder(Rectangle.NO_BORDER);
				// cellThree101.setBorder(Rectangle.NO_BORDER);
			//	 cellFour101.setBorder(Rectangle.NO_BORDER); 
				 table101.addCell(cellOne101);     
				 table101.addCell(cellTwo101);   
				 //table101.addCell(cellThree101);      
			//	 table101.addCell(cellFour101);   
			     document1.add(table101);              
				     
				   PdfPTable table103 = new PdfPTable(3);     
					 table103.setWidthPercentage(90);            
					 PdfPCell cellOne103 = new PdfPCell(new Phrase(studentpay.getDistrictname(),bf12));
					 PdfPCell cellTwo103 = new PdfPCell(new Phrase(studentpay1.getInstitutename(),bf12));
					// PdfPCell cellThree103 = new PdfPCell(new Phrase(studentpay.getCourseid(),bf12));
					 PdfPCell cell3= new PdfPCell();          
						
					  String img4 = System.getProperty("catalina.base")+"/webapps"+studentpay.getImage_path();
					  Image image5 = Image.getInstance(img4);  
					  image5.setAlignment(Element.ALIGN_RIGHT);   
					  image5.scaleAbsolute(80,80);   
					  cell3.addElement(image5);                    
					  cell3.setBorder(Rectangle.NO_BORDER);      
					             
					 cellOne103.setBorder(Rectangle.NO_BORDER);
					 cellTwo103.setBorder(Rectangle.NO_BORDER);          
					// cellThree103.setBorder(Rectangle.NO_BORDER);    
					 table103.addCell(cellOne103);     
					 table103.addCell(cellTwo103);    
				//	 table103.addCell(cellThree103);   
					 table103.addCell(cell3);
					 table103.setSpacingAfter(-50);
					 document1.add(table103);  
					        
					 
					 
				  PdfPTable table2 = new PdfPTable(1);
				  table2.setWidthPercentage(90);  
				  PdfPCell cellOne = new PdfPCell(new Phrase("1.MONTH & YEAR OF EXAM : "+" March,2020",bf12));
				 
				  cellOne.setBorder(Rectangle.NO_BORDER);  
				         
				  table2.addCell(cellOne);  
				     
				  document1.add(table2); 
				          
				    
				  PdfPTable table21 = new PdfPTable(1);      
				  table21.setWidthPercentage(90);  
				  PdfPCell cellOne2 = new PdfPCell(new Phrase("2.HALLTICKET NO : "+ applicationid,bf12));
				 
				  cellOne2.setBorder(Rectangle.NO_BORDER);  
				         
				  table21.addCell(cellOne2);  
				      
				  document1.add(table21); 
				  
				  PdfPTable table22 = new PdfPTable(1);      
				  table22.setWidthPercentage(90);  
				  PdfPCell cellOne1 = new PdfPCell(new Phrase("3. Course Name : "+ studentpay4.getCoursename(),bf12));
				 
				  cellOne1.setBorder(Rectangle.NO_BORDER);  
				         
				  table22.addCell(cellOne1);     
				     
				  document1.add(table22);         
				     
				      
				             
			
						 PdfPTable table104 = new PdfPTable(1);      
						  table104.setWidthPercentage(90);  
						  PdfPCell cellOne104 = new PdfPCell(new Phrase("4.Examination Centre : "+studentpay3.getCentername(),bf12));
					       cellOne104.setBorder(Rectangle.NO_BORDER);     
						  table104.addCell(cellOne104);     
						  document1.add(table104);   
				      
					 
						  PdfPTable table105 = new PdfPTable(1);      
						  table105.setWidthPercentage(90);  
						  PdfPCell cellOne105 = new PdfPCell(new Phrase("5.Certified that Sri/Kum/Smt/  "+studentpay.getName()+" S/o D/o Sri  " +studentpay.getFathername()+ " is a candidate for the under mentioned examination. ",bfBold6));
						
						  cellOne105.setBorder(Rectangle.NO_BORDER);     
						       
						  cellOne105.setHorizontalAlignment(90);       
						  table105.addCell(cellOne105);    
						  document1.add(table105);   
  
						  PdfPTable table106 = new PdfPTable(1);      
						  table106.setWidthPercentage(90);  
						  PdfPCell cellOne106 = new PdfPCell(new Phrase("6.WHOLE/PART Examination  : "+ " PART EXAMINATION. ",bf12));
						 
						  cellOne106.setBorder(Rectangle.NO_BORDER);     
						    
						  table106.addCell(cellOne106);  
						      
						  document1.add(table106); 
						  
						  PdfPTable table107 = new PdfPTable(1);      
						  table107.setWidthPercentage(90);  
						  PdfPCell cellOne107 = new PdfPCell(new Phrase("7. PG SEQ NUMBER  : " + applicationid,bf12));
						 
						  cellOne107.setBorder(Rectangle.NO_BORDER);     
						        
						  table107.addCell(cellOne107);  
						   
						  table107.setSpacingAfter(10);
						  document1.add(table107);      
						             
						  Paragraph d5 = new Paragraph();          
				            d5.setFont(bf12); 
				            d5.setAlignment(Paragraph.ALIGN_RIGHT);    
				            d5.setIndentationRight(30);       
				            d5.add("For Secretary, S.B.T.E.T.");
				            d5.setSpacingAfter(10);
							document1.add(d5);
							
						  
							 /**************************Library Details**********************/	
							    

							 float[] columnWidths4 = {1f,1f,1f,1f};            
								// create PDF table with the given widths    
								PdfPTable libtable = new PdfPTable(columnWidths4);
								// set table width a percentage of the page width            
								libtable.setWidthPercentage(90f);          
								// insert column headings 
							 
							    insertCell(libtable, "Subject Code", Element.ALIGN_CENTER, 4, bfBold6);
								insertCell(libtable, " Name of the Subject", Element.ALIGN_CENTER, 4, bfBold6);
								insertCell(libtable, "Date & Time of Examination", Element.ALIGN_CENTER, 4, bfBold6);
								insertCell(libtable, "Signature of the Invigilator", Element.ALIGN_CENTER, 4, bfBold6);
								/*insertCell(libtable, "Journals", Element.ALIGN_CENTER, 4, bfBold6);*/
								List<StudentPay> studentpay2 = sqlSession.selectList("StudentPay.getSubjects",applicationid);  
							    	
								System.out.println("Library  Details Length : "+studentpay2.size());            
								   
								Iterator<StudentPay> it4 = studentpay2.iterator();
								while(it4.hasNext()) {
									StudentPay student = (StudentPay) it4.next(); 
									
									//System.out.println("Branch Name:"+student.getSubjects());    
									
									insertCell(libtable,student.getSubjectid().toString(), Element.ALIGN_CENTER, 4, bf12);
					 				insertCell(libtable,student.getSubjectname().toString(), Element.ALIGN_CENTER, 4, bf12);
									insertCell(libtable,(student.getDate().toString()+""
											+ "                                    "+student.getTime().toString()), Element.ALIGN_CENTER, 4, bf12);
									insertCell(libtable,"                         ", Element.ALIGN_CENTER, 4, bf12);
									/*	insertCell(libtable,student.getSubscribed_journals ().toString(), Element.ALIGN_CENTER, 4, bf12);*/
								}   
								libtable.setSpacingAfter(10);	          
							    document1.add(libtable);
							
								    
							/***************************************************************************/	

	         
							
							 Paragraph d3 = new Paragraph();          
					            d3.setFont(bfBold6); 
					            d3.setAlignment(Paragraph.ALIGN_LEFT);   
					            d3.setIndentationRight(30);       
					            d3.add("Signature Of the Candidate");    
					            d3.setSpacingAfter(20);
								document1.add(d3);
								
								 Paragraph d6 = new Paragraph();      
						            d6.setFont(bfBold6); 
						            d6.setAlignment(Paragraph.ALIGN_LEFT);   
						            d6.setIndentationRight(30);       
						            d6.add("INSTRUCTIONS TO CANDIDATES : ");    
						            d6.setSpacingAfter(20);
									document1.add(d6);  
									 Paragraph d7 = new Paragraph();      
									 d7.setFont(bf12);    
									 d7.setAlignment(Paragraph.ALIGN_LEFT);   
									 d7.setIndentationRight(30);       
									 d7.add("1. Hall-ticket issued to you is an important document preserve carefully.");    
									// d7.setSpacingAfter(30);
										document1.add(d7);	   
									
										Paragraph d8 = new Paragraph();      
										 d8.setFont(bf12);    
										 d8.setAlignment(Paragraph.ALIGN_LEFT);   
										 d8.setIndentationRight(30);       
										 d8.add("2. No candidate will be allowed to enter the examination hall without proper hall-ticket. ");    
										// d7.setSpacingAfter(30);
											document1.add(d8);	
											
											Paragraph d9 = new Paragraph();      
											 d9.setFont(bf12);       
											 d9.setAlignment(Paragraph.ALIGN_LEFT);   
											 d9.setIndentationRight(30);       
											 d9.add("3. Candidate shall arrive at the examination center at least 30 minutes before the commencement of the examination. While entering the examination hall every student shall deposit all books, personal belongings etc at counter provided. ");    
											// d7.setSpacingAfter(30);
												document1.add(d9);	
										
												Paragraph d10 = new Paragraph();      
												 d10.setFont(bf12);    
												 d10.setAlignment(Paragraph.ALIGN_LEFT);   
												 d10.setIndentationRight(30);       
	  											 d10.add("4. No printed / written material, in any form, shall be taken inside the exam hall, other than hall ticket. ");    
										     		// d7.setSpacingAfter(30);
													document1.add(d10);
													
													Paragraph d11 = new Paragraph();      
													 d11.setFont(bf12);    
													 d11.setAlignment(Paragraph.ALIGN_LEFT);   
													 d11.setIndentationRight(30);       
													 d11.add("5. Every student shall cooperate while pockets are being checked or frisked.");    
													// d7.setSpacingAfter(30);
														document1.add(d11);	
										 
														Paragraph d12 = new Paragraph();      
														 d12.setFont(bf12);    
														 d12.setAlignment(Paragraph.ALIGN_LEFT);   
														 d12.setIndentationRight(30);       
														 d12.add("6. Candidates will not be allowed to enter the examination hall, after half-an-hour of the commencement of examination. ");    
														// d7.setSpacingAfter(30);
														document1.add(d12);	
														
						Paragraph d13 = new Paragraph();    
						d13.setFont(bf12);    
						d13.setAlignment(Paragraph.ALIGN_LEFT);   
						d13.setIndentationRight(30);       
						d13.add("7.  Candidates will not be allowed to leave the examination hall before one hour from the commencement of examination. After one hour, ifany candidate wishes to leave or wants to attend any emergency needs, the candidate must return his/her answer script along with question paper to the Invigilator.");    
							// d7.setSpacingAfter(30);
             			document1.add(d13);	
             			Paragraph d14 = new Paragraph();    
						d14.setFont(bf12);    
						d14.setAlignment(Paragraph.ALIGN_LEFT);   
						d14.setIndentationRight(30);       
						d14.add("8.  Candidates are advised to go through the instructions given on Answer Booklet or OMR Bar Code Sheet before starting answering. ");    
							// d7.setSpacingAfter(30);
             			document1.add(d14);	
             			Paragraph d15 = new Paragraph();    
						d15.setFont(bf12);    
						d15.setAlignment(Paragraph.ALIGN_LEFT);   
						d15.setIndentationRight(30);       
						d15.add("9.  Candidates should not write any matter inside the Answer Booklet which may lead to the identification of the Candidate or institution. If he/she do so, he/she will be bokked under malpractice. No color sketch pens are to be used unless specified question");    
							// d7.setSpacingAfter(30);
             			document1.add(d15);	 
             			Paragraph d16 = new Paragraph();    
						d16.setFont(bf12);    
						d16.setAlignment(Paragraph.ALIGN_LEFT);   
						d16.setIndentationRight(30);       
						d16.add("10. Candidates should carry their own Scientific Calculators, Pens, Pencils and required drawing instruments.");    
							// d7.setSpacingAfter(30);
             			document1.add(d16);	 
             			Paragraph d17 = new Paragraph();    
						d17.setFont(bf12);    
						d17.setAlignment(Paragraph.ALIGN_LEFT);   
						d17.setIndentationRight(30);       
						d17.add("11. Candidateswill not be allowed with Cell Phones(CDMA & GSM),Pagers,Organizers,PDA's andpalmtops or any other Electronic Gadgets, etc.");    
							// d7.setSpacingAfter(30);
             			document1.add(d17);	 
             			Paragraph d18 = new Paragraph();    
						d18.setFont(bf12);    
						d18.setAlignment(Paragraph.ALIGN_LEFT);   
						d18.setIndentationRight(30);       
						d18.add("12. Every student shall follow the regulations during examinations, failing which he/she will be booked under malpractice case.");    
							// d7.setSpacingAfter(30);
             			document1.add(d18);	 
             			Paragraph d19 = new Paragraph();    
						d19.setFont(bf12);    
						d19.setAlignment(Paragraph.ALIGN_LEFT);   
						d19.setIndentationRight(30);       
						d19.add("13. Candidates are advised to check all the pages in the '32-page Answer Booklet' supplied to him/her. All answers are to be written within the given booklet only.");    
							// d7.setSpacingAfter(30);
             			document1.add(d19);	 
             			Paragraph d20 = new Paragraph();    
						d20.setFont(bf12);    
						d20.setAlignment(Paragraph.ALIGN_LEFT);   
						d20.setIndentationRight(30);       
						d20.add("14. No additional sheet/s will be supplied under any circumstances.");    
							// d7.setSpacingAfter(30);
             			document1.add(d20);	 
															  
								    
             			 document1.add(rect);			    
				document1.close();                 
				writer.close();  
				
				//if((("catalina.base") + "/webapps/uploads/sbtet/pdf/"+"Reports_"+studentsapprove.getApplicationid()+".pdf").equals(1)) {
		        	
		        	/* Email email = new Email();
		     	    
		     	    email.setFrom("SBTET<noreply4@apssdc.in>");
		     	  //  email.setTo(users.getEmail());          
		     	    email.setTo("narepalempadhu@gmail.com");
		     	    email.setSubject("SBTET pre-inspection - Process Success.");
		     	    String msg = "Dear Principal Sir,,<br><br>Thank you for Submitting Data to <b>SBTET </b>.<br><br>"
		     	    +"Your data was submitted successfully"+"<br><br>"+
		     	    "Application URL : "+System.getProperty("catalina.base") + "/webapps/uploads/sbtet/pdf/"+"Reports_"+studentsapprove.getApplicationid()+".pdf";;
		     	    email.setText(msg);  
					emailservice.sendHtmlMsg(email); */  
	        	
				sqlSession.close();  
				
	    }
	    catch(Exception b)      
		{
			System.out.print("Exception is:"+b);    
			document1.close(); 
			z.delete();
			//System.out.print(studentsapprove);
		}  
	    
	   
	   
		return pdfFilename;   
		//return  data;     
	}
	   

	
	private void insertCell(PdfPTable table, String text, int align, int colspan, Font font) {

		// create a new cell with the specified Text and Font
		PdfPCell cell = new PdfPCell(new Phrase(text.trim(), font));         
		// set the cell alignment    
		cell.setHorizontalAlignment(align);
		// set the cell column span in case you want to merge two or more cells

		// in case there is no text and you wan to create an empty row
		if (text.trim().equalsIgnoreCase("")) {
		cell.setMinimumHeight(10f);       
		} 
		// add the cell to the table  
		table.addCell(cell);           

		} 
	
	
	
	
	
	
	
	
	
	
	
}
