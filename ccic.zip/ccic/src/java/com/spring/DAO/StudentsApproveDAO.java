  package com.spring.DAO;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.andromeda.commons.dao.BaseDAO;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;   
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.spring.Model.StudentsApprove;

   
@Repository    
public class StudentsApproveDAO extends BaseDAO
{
	
	
	public List<Map<String, Object>> getDistricts()
	{
		return sqlSessionTemplate.selectList("StudentsApprove.getDistricts");
	}
     
	
	public List<Map<String, Object>> getColleges(Integer districtid)
	{
		System.out.println(districtid);
		return sqlSessionTemplate.selectList("StudentsApprove.getColleges",districtid);
	}
	
	
	public List<Map<String, Object>> getCourses(String instituteid)
	{
		return sqlSessionTemplate.selectList("StudentsApprove.getCourses",instituteid);
	}  
	    
	public List<Map<String, Object>> getAll(String instituteid,String courseid)
	{
		Map<String, Object> params = new HashMap<String, Object>(); 
		params.put("instituteid",instituteid);
		params.put("courseid",courseid);
		return sqlSessionTemplate.selectList("StudentsApprove.getAll",params);
	}  
	public void updateData(String applicationid)
	{
      System.out.println(applicationid);     
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("p", applicationid);
		SqlSession sqlSession = sqlSessionFactory.openSession();
		sqlSession.update("StudentsApprove.updateData",applicationid);
		sqlSession.close();
	}  
	   
	public String generateHallTicket(String applicationid,String name)   
	{  
		Document document1 = new Document();       
		 Rectangle rect= new Rectangle(577,825,15,15);   
		 
		File z=new File(System.getProperty("catalina.base")+"/webapps/uploads/sbtet/pdf/"+"Hallticket of"+applicationid+".pdf");
		Font bfBold12 = new Font(FontFamily.TIMES_ROMAN, 16, Font.BOLD, new BaseColor(0, 0, 0)); 
		Font bfBold6 = new Font(FontFamily.TIMES_ROMAN, 12, Font.BOLD, new BaseColor(0, 0, 0));
		//Font bfBold1 = new Font(FontFamily.TIMES_ROMAN, 12);
		Font bf12 = new Font(FontFamily.TIMES_ROMAN, 12); 
	
		String pdfFilename =
				System.getProperty("catalina.base") + "/webapps/uploads/ccic/pdf/"+"Hallticket of"+applicationid+".pdf";  
	    try {
	    	
	    	SqlSession sqlSession = sqlSessionFactory.openSession();   
			
		    StudentsApprove studentsapprove= sqlSession.selectOne("StudentsApprove.getapplname",applicationid);
		    PdfWriter writer = PdfWriter.getInstance(document1, new FileOutputStream(pdfFilename));  
			document1.open();      
			    
			 rect.enableBorderSide(1);   
		     rect.enableBorderSide(2);              
		     rect.enableBorderSide(4);
		     rect.enableBorderSide(8);
		     rect.setBorderColor(BaseColor.BLACK);   
		     rect.setBorderWidth(2);
		     document1.add(rect);
			   
		     String a = "STATE BOARD OF TECHNICAL EDUCATION AND TRAINING.";	    
		  	 Chunk chunk1 = new Chunk(a);      
			 chunk1.setFont(new Font(FontFamily.TIMES_ROMAN,18,Font.BOLD));          
			 Paragraph para2 = new Paragraph(chunk1.toString());
			 para2.setFont(new Font(FontFamily.TIMES_ROMAN,18,Font.BOLD));
			 para2.setAlignment(Paragraph.ALIGN_CENTER);      
			// para2.setSpacingAfter(30);      
			 document1.add(para2);
			 
			 String b = "A.P. CRAFT AND COMPUTER CERTIFICATE COURSES  EXAMINATIONS";	
		  	 Chunk chunk12 = new Chunk(b);      
		  	chunk12.setFont(new Font(FontFamily.TIMES_ROMAN,18,Font.BOLD));          
			 Paragraph para3 = new Paragraph(chunk12.toString());
			 para3.setFont(new Font(FontFamily.TIMES_ROMAN,16,Font.BOLD));
			 para3.setAlignment(Paragraph.ALIGN_CENTER);
			 para3.setSpacingAfter(20);      
			 document1.add(para3);   
			 
			     
			 String c = "ORIGINAL HALL TICKET";	
		  	 Chunk chunk3 = new Chunk(c);      
			 chunk3.setFont(new Font(FontFamily.TIMES_ROMAN,16,Font.BOLD));          
			 Paragraph para4 = new Paragraph(chunk3.toString());
			 para4.setFont(new Font(FontFamily.TIMES_ROMAN,16,Font.BOLD));
			 para4.setAlignment(Paragraph.ALIGN_CENTER);
			 para4.setSpacingAfter(20);      
			 document1.add(para4);
			    
			         
				    
				  PdfPTable table2 = new PdfPTable(2);
				  table2.setWidthPercentage(90);  
				  PdfPCell cellOne = new PdfPCell(new Phrase("1.MONTH & YEAR OF EXAM :",bf12));
				  PdfPCell cellTwo2 = new PdfPCell(new Phrase("March,2020",bf12));
				  cellOne.setBorder(Rectangle.NO_BORDER);  
				  cellTwo2.setBorder(Rectangle.NO_BORDER);
				  cellTwo2.setHorizontalAlignment(80);       
				  table2.addCell(cellOne);  
				  table2.addCell(cellTwo2);    
				  document1.add(table2); 
				  
				
				  PdfPTable table21 = new PdfPTable(2);      
				  table21.setWidthPercentage(90);  
				  PdfPCell cellOne2 = new PdfPCell(new Phrase("2.HALLTICKET NO :",bf12));
				  PdfPCell cellTwo3 = new PdfPCell(new Phrase(applicationid));
				  cellOne2.setBorder(Rectangle.NO_BORDER);  
				  cellTwo3.setBorder(Rectangle.NO_BORDER);
				  cellTwo3.setHorizontalAlignment(90);         
				  table21.addCell(cellOne2);  
				  table21.addCell(cellTwo3);    
				  document1.add(table21);        
				     
				  /*PdfPTable table11= new PdfPTable(1);
					 PdfPCell cell2 = new PdfPCell();
					 PdfPCell cell3= new PdfPCell();
					 cell3.addElement(table11);
					  String img4 = System.getProperty("catalina.base") + "/webapps/sbtet/images/PLogo.jfif";
					  Image image5 = Image.getInstance(img4);  
					  image5.setAlignment(Element.ALIGN_RIGHT);
					  image5.scaleAbsolute(70,80);
					  cell2.addElement(image5);              
					  cell2.setBorder(Rectangle.NO_BORDER);       
					  table11.addCell(cell2);            
					  document1.add(table11);    */
				     
				  
				  PdfPTable table101 = new PdfPTable(4);
					 table101.setWidthPercentage(90);         
					 PdfPCell cellOne101 = new PdfPCell(new Phrase("Dist. Name: ",bf12));
					 PdfPCell cellTwo101 = new PdfPCell(new Phrase(" Inst. Name: ",bf12));
					 PdfPCell cellThree101 = new PdfPCell(new Phrase(" Course Name : ",bf12));
					 PdfPCell cellFour101 = new PdfPCell(new Phrase(" Photo : ",bf12));
					 cellOne101.setBorder(Rectangle.NO_BORDER);
					 cellTwo101.setBorder(Rectangle.NO_BORDER);
					 cellThree101.setBorder(Rectangle.NO_BORDER);
					 cellFour101.setBorder(Rectangle.NO_BORDER);
					 table101.addCell(cellOne101);     
					 table101.addCell(cellTwo101);   
					 table101.addCell(cellThree101);
					 table101.addCell(cellFour101);   
				     document1.add(table101);            
					     
					   PdfPTable table103 = new PdfPTable(4);
						 table103.setWidthPercentage(90);            
						 PdfPCell cellOne103 = new PdfPCell(new Phrase(studentsapprove.getDistrictname(),bf12));
						 PdfPCell cellTwo103 = new PdfPCell(new Phrase(" AANM & VVRSR POLY",bf12));
						 PdfPCell cellThree103 = new PdfPCell(new Phrase(studentsapprove.getCourseid(),bf12));
						 PdfPCell cell3= new PdfPCell();
							
						  String img4 = System.getProperty("catalina.base") + "\\webapps\\uploads\\ccic\\ccic\\plogo.png";
						  Image image5 = Image.getInstance(img4);  
						  image5.setAlignment(Element.ALIGN_RIGHT);
						  image5.scaleAbsolute(50,20); 
						  cell3.addElement(image5);                  
						  cell3.setBorder(Rectangle.NO_BORDER);   
						             
						 cellOne103.setBorder(Rectangle.NO_BORDER);
						 cellTwo103.setBorder(Rectangle.NO_BORDER);          
						 cellThree103.setBorder(Rectangle.NO_BORDER);    
						 table103.addCell(cellOne103);     
						 table103.addCell(cellTwo103);    
						 table103.addCell(cellThree103);
						 table103.addCell(cell3);
						 document1.add(table103);  
						 
						 PdfPTable table104 = new PdfPTable(2);      
						  table104.setWidthPercentage(90);  
						  PdfPCell cellOne104 = new PdfPCell(new Phrase("3.Examination Centre :",bf12));
						  PdfPCell cellTwo104 = new PdfPCell(new Phrase("MBTS POLYTECHNIC GUNTUR. "));
						  cellOne104.setBorder(Rectangle.NO_BORDER);     
						  cellTwo104.setBorder(Rectangle.NO_BORDER);
						  cellTwo104.setHorizontalAlignment(90);       
						  table104.addCell(cellOne104);  
						  table104.addCell(cellTwo104);    
						  document1.add(table104);   
				      
					 
						  PdfPTable table105 = new PdfPTable(2);      
						  table105.setWidthPercentage(90);  
						  PdfPCell cellOne105 = new PdfPCell(new Phrase("4.Certified that Sri/Kum/Smt"+name,bf12));
						  PdfPCell cellTwo105 = new PdfPCell(new Phrase("S/o D/o Sri P NARASAIAH is a candidate for the under mentioned examination. "));
						  cellOne105.setBorder(Rectangle.NO_BORDER);     
						  cellTwo105.setBorder(Rectangle.NO_BORDER);  
						  cellTwo105.setHorizontalAlignment(90);       
						  table105.addCell(cellOne105);  
						  table105.addCell(cellTwo105);    
						  document1.add(table105);   
  
						  PdfPTable table106 = new PdfPTable(2);      
						  table106.setWidthPercentage(90);  
						  PdfPCell cellOne106 = new PdfPCell(new Phrase("5.WHOLE/PART Examination  :",bf12));
						  PdfPCell cellTwo106 = new PdfPCell(new Phrase(" PART EXAMINATION. "));
						  cellOne106.setBorder(Rectangle.NO_BORDER);     
						  cellTwo106.setBorder(Rectangle.NO_BORDER);
						  cellTwo106.setHorizontalAlignment(90);       
						  table106.addCell(cellOne106);  
						  table106.addCell(cellTwo106);    
						  document1.add(table106); 
						  
						  PdfPTable table107 = new PdfPTable(2);      
						  table107.setWidthPercentage(90);  
						  PdfPCell cellOne107 = new PdfPCell(new Phrase("6. PG SEQ NUMBER  :",bf12));
						  PdfPCell cellTwo107 = new PdfPCell(new Phrase(" PCCC8677442D9E9. "));
						  cellOne107.setBorder(Rectangle.NO_BORDER);     
						  cellTwo107.setBorder(Rectangle.NO_BORDER);
						  cellTwo107.setHorizontalAlignment(90);       
						  table107.addCell(cellOne107);  
						  table107.addCell(cellTwo107); 
						  table107.setSpacingAfter(30);
						  document1.add(table107);      
						             
						  Paragraph d5 = new Paragraph();          
				            d5.setFont(bf12); 
				            d5.setAlignment(Paragraph.ALIGN_RIGHT); 
				            d5.setIndentationRight(30);       
				            d5.add("For Secretary, S.B.T.E.T.");
				            d5.setSpacingAfter(40);
							document1.add(d5);
							
						  
			
	          
		   /*        
			 float[] columnWidths = {1f,1f,1f};      
				// create PDF table with the given widths  
				PdfPTable table = new PdfPTable(columnWidths);
				// set table width a percentage of the page width        
				table.setWidthPercentage(80f);             
				// insert column headings     
	    
				insertCell(table, "Institution Code", Element.ALIGN_CENTER, 4, bfBold6 );
				insertCell(table, studentsapprove.getApplicationid(), Element.ALIGN_CENTER, 4, bf12);
				
				insertCell(table, "Staff Required", Element.ALIGN_CENTER, 4, bfBold6 );
				insertCell(table, studentsapprove.getStaffReq(), Element.ALIGN_CENTER, 4, bf12);
				insertCell(table, "Staff Available", Element.ALIGN_CENTER, 4, bfBold6 );
				insertCell(table, studentsapprove.getStaffAvail(), Element.ALIGN_CENTER, 4, bf12);
				insertCell(table, "Staff Deficiency", Element.ALIGN_CENTER, 4, bfBold6 );
				insertCell(table, studentsapprove.getStaffdeff(), Element.ALIGN_CENTER, 4, bf12);
				insertCell(table, "Staff Remarks", Element.ALIGN_CENTER, 4, bfBold6 );
				insertCell(table, studentsapprove.getStaffremarks(), Element.ALIGN_CENTER, 4, bf12);
				        
				table.setSpacingAfter(30);    
				document1.add(table);*/
				
				
					/*String d2 ="Rooms Information:";
					Chunk chunk3 = new Chunk(d2); 
					chunk3.setFont(new Font(FontFamily.TIMES_ROMAN, 14,Font.BOLD));
		            Paragraph para12 = new Paragraph(chunk3);
		            para12.setAlignment(Paragraph.ALIGN_LEFT);
		            para12.setAlignment(Element.ALIGN_JUSTIFIED);
		            para12.setSpacingAfter(15);
		            document1.add(para12);   */
				                
				
				 float[] columnWidths2 = {1f,1f,1f,1f,1f};  
					// create PDF table with the given widths  
					PdfPTable table10= new PdfPTable(columnWidths2);
					// set table width a percentage of the page width     
					table10.setWidthPercentage(90f);             
					// insert column headings     
					
					insertCell(table10, "SNO", Element.ALIGN_CENTER, 4, bfBold6 );
					insertCell(table10, "Subject Code", Element.ALIGN_CENTER, 4, bfBold6 );
					insertCell(table10, " Name of the Subject", Element.ALIGN_CENTER, 4, bfBold6 );
					insertCell(table10, " Date & Time of Examination", Element.ALIGN_CENTER, 4, bfBold6 );
					insertCell(table10, " Signature of the Invigilator", Element.ALIGN_CENTER, 4, bfBold6 );
					
					
					insertCell(table10, "1", Element.ALIGN_CENTER, 4, bf12);
					insertCell(table10, "101", Element.ALIGN_CENTER, 4, bf12);
		 			insertCell(table10, "Program in C", Element.ALIGN_CENTER, 4, bf12);
					insertCell(table10, "13-09-2019(2.00pmTo05.00pm)", Element.ALIGN_CENTER, 4, bf12);
					insertCell(table10,"", Element.ALIGN_CENTER, 4, bf12);
					
					insertCell(table10, "2", Element.ALIGN_CENTER, 4, bf12);
					insertCell(table10, "102", Element.ALIGN_CENTER, 4, bf12);
		 			insertCell(table10, "JAVA", Element.ALIGN_CENTER, 4, bf12);
					insertCell(table10, "13-09-2019(2.00pmTo05.00pm)", Element.ALIGN_CENTER, 4, bf12);  
					insertCell(table10,"", Element.ALIGN_CENTER, 4, bf12);
					     
						      
					/*insertCell(table10, "Auditoriums", Element.ALIGN_CENTER, 4, bfBold6);
					insertCell(table10, studentsapprove.getAudiReq(), Element.ALIGN_CENTER, 4, bf12);
					insertCell(table10, studentsapprove.getAudiAvail(), Element.ALIGN_CENTER, 4, bf12);
					insertCell(table10, studentsapprove.getAudideff(), Element.ALIGN_CENTER, 4, bf12);
					insertCell(table10, studentsapprove.getAudiremarks(), Element.ALIGN_CENTER, 4, bf12);
					
					insertCell(table10, "WorkShops", Element.ALIGN_CENTER, 4, bfBold6);
					insertCell(table10, studentsapprove.getWorkReq(), Element.ALIGN_CENTER, 4, bf12);
					insertCell(table10, studentsapprove.getWorkAvail(), Element.ALIGN_CENTER, 4, bf12);
					insertCell(table10, studentsapprove.getWorkdeff(), Element.ALIGN_CENTER, 4, bf12);
					insertCell(table10, studentsapprove.getWorkremarks(), Element.ALIGN_CENTER, 4, bf12);
					  
					        
		
				
					        insertCell(table10, "Laboratories", Element.ALIGN_CENTER, 4, bfBold6);
							insertCell(table10, studentsapprove.getLabReq(), Element.ALIGN_CENTER, 4, bf12);  
							insertCell(table10, studentsapprove.getLabAvail(), Element.ALIGN_CENTER, 4, bf12);
							insertCell(table10, studentsapprove.getLabdeff(), Element.ALIGN_CENTER, 4, bf12);
							insertCell(table10, studentsapprove.getLabremarks(), Element.ALIGN_CENTER, 4, bf12);
							
								             */
							table10.setSpacingAfter(45);       
							document1.add(table10);     
							
							 Paragraph d3 = new Paragraph();      
					            d3.setFont(bfBold6); 
					            d3.setAlignment(Paragraph.ALIGN_LEFT);   
					            d3.setIndentationRight(30);       
					            d3.add("Signature Of the Candidate");    
					            d3.setSpacingAfter(30);
								document1.add(d3);
								
								 Paragraph d6 = new Paragraph();      
						            d6.setFont(bfBold6); 
						            d6.setAlignment(Paragraph.ALIGN_LEFT);   
						            d6.setIndentationRight(30);       
						            d6.add("INSTRUCTIONS TO CANDIDATES : ");    
						            d6.setSpacingAfter(30);
									document1.add(d6);
									 Paragraph d7 = new Paragraph();      
									 d7.setFont(bf12);    
									 d7.setAlignment(Paragraph.ALIGN_LEFT);   
									 d7.setIndentationRight(30);       
									 d7.add("1. Hall-ticket issued to you is an important document preserve carefully.");    
									// d7.setSpacingAfter(30);
										document1.add(d7);	   
									
										Paragraph d8 = new Paragraph();      
										 d8.setFont(bf12);    
										 d8.setAlignment(Paragraph.ALIGN_LEFT);   
										 d8.setIndentationRight(30);       
										 d8.add("2. No candidate will be allowed to enter the examination hall without proper hall-ticket. ");    
										// d7.setSpacingAfter(30);
											document1.add(d8);	
											
											Paragraph d9 = new Paragraph();      
											 d9.setFont(bf12);    
											 d9.setAlignment(Paragraph.ALIGN_LEFT);   
											 d9.setIndentationRight(30);       
											 d9.add("3. Candidate shall arrive at the examination center at least 30 minutes before the commencement of the examination. While entering the examination hall every student shall deposit all books, personal belongings etc at counter provided. ");    
											// d7.setSpacingAfter(30);
												document1.add(d9);	
										
												Paragraph d10 = new Paragraph();      
												 d10.setFont(bf12);    
												 d10.setAlignment(Paragraph.ALIGN_LEFT);   
												 d10.setIndentationRight(30);       
												 d10.add("4. No printed / written material, in any form, shall be taken inside the exam hall, other than hall ticket. ");    
												// d7.setSpacingAfter(30);
													document1.add(d10);
													
													Paragraph d11 = new Paragraph();      
													 d11.setFont(bf12);    
													 d11.setAlignment(Paragraph.ALIGN_LEFT);   
													 d11.setIndentationRight(30);       
													 d11.add("5. Every student shall cooperate while pockets are being checked or frisked.");    
													// d7.setSpacingAfter(30);
														document1.add(d11);	
										 
														/*Paragraph d12 = new Paragraph();      
														 d12.setFont(bf12);    
														 d12.setAlignment(Paragraph.ALIGN_LEFT);   
														 d12.setIndentationRight(30);       
														 d12.add("6. Candidates will not be allowed to enter the examination hall, after half-an-hour of the commencement of examination. ");    
														// d7.setSpacingAfter(30);
															document1.add(d12);	
															*/   
								    
								
				document1.close();                 
				writer.close();  
				
				//if((("catalina.base") + "/webapps/uploads/sbtet/pdf/"+"Reports_"+studentsapprove.getApplicationid()+".pdf").equals(1)) {
		        	
		        	/* Email email = new Email();
		     	    
		     	    email.setFrom("SBTET<noreply4@apssdc.in>");
		     	  //  email.setTo(users.getEmail());          
		     	    email.setTo("narepalempadhu@gmail.com");
		     	    email.setSubject("SBTET pre-inspection - Process Success.");
		     	    String msg = "Dear Principal Sir,,<br><br>Thank you for Submitting Data to <b>SBTET </b>.<br><br>"
		     	    +"Your data was submitted successfully"+"<br><br>"+
		     	    "Application URL : "+System.getProperty("catalina.base") + "/webapps/uploads/sbtet/pdf/"+"Reports_"+studentsapprove.getApplicationid()+".pdf";;
		     	    email.setText(msg);  
					emailservice.sendHtmlMsg(email); */  
	        	
				sqlSession.close();  
				
	    }
	    catch(Exception b)      
		{
			System.out.print("Exception is:"+b);    
			document1.close(); 
			z.delete();
			//System.out.print(studentsapprove);
		}  
	    
	   
	   
		return pdfFilename;   
		//return  data;     
	}
	   

	
	private void insertCell(PdfPTable table, String text, int align, int colspan, Font font) {

		// create a new cell with the specified Text and Font
		PdfPCell cell = new PdfPCell(new Phrase(text.trim(), font));         
		// set the cell alignment    
		cell.setHorizontalAlignment(align);
		// set the cell column span in case you want to merge two or more cells

		// in case there is no text and you wan to create an empty row
		if (text.trim().equalsIgnoreCase("")) {
		cell.setMinimumHeight(10f);       
		} 
		// add the cell to the table  
		table.addCell(cell);           

		} 
	
	
		
	
}  
	