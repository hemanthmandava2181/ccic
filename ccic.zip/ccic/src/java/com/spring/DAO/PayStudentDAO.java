package com.spring.DAO;

import java.util.ArrayList;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.jar.JarException;
import org.apache.commons.codec.binary.Base64;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.andromeda.commons.util.CryptoUtils;
import com.spring.Model.PayStudent;
import com.spring.Model.Student;


@Repository
public class PayStudentDAO extends BaseDAO {    
	@Autowired    
	private SqlSessionFactory sqlSessionFactory;
	
	public List<PayStudent> getNameWiseData(PayStudent payStudent) {   
		SqlSession sqlSession = sqlSessionFactory.openSession();
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("institutioncode", payStudent.getInstitutioncode());	
		params.put("courseid",payStudent.getCourseid()); 
		params.put("name",payStudent.getName());    
		List<PayStudent> nameWiseData=sqlSession.selectList("PayStudent.getNameWiseData",params);
		sqlSession.close();
		return nameWiseData;   
	}
   
	public List<PayStudent> getAll(String institutioncode,String courseid) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("institutioncode", institutioncode);	
		params.put("courseid",courseid); 
		List<PayStudent> userdetails=sqlSession.selectList("PayStudent.getAll",params);
		sqlSession.close();
		return userdetails;  
			
	}
	
	public List<PayStudent> getBacklogAll(String institutioncode,String courseid) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("institutioncode", institutioncode);	
		params.put("courseid",courseid); 
		List<PayStudent> userdetails=sqlSession.selectList("PayStudent.getBacklogAll",params);
		sqlSession.close();
		return userdetails;  
			
	}
	
	public List<Map<String, Object>> getSubjects(String  courseid)   
	{
		SqlSession sqlSession = sqlSessionFactory.openSession();
		Map<String, Object> params = new HashMap<String, Object>();   
		//String courseid = courseid;    
		//String instituteid = stu[1];
		//params.put("instituteid", instituteid);	
		params.put("courseid",courseid);                 
		List<Map<String, Object>> userdetails = sqlSessionTemplate.selectList("PayStudent.getSubjects",params);
		sqlSession.close();
		return userdetails;
	}  
	
	
	
		public String generateString()
		{
			char[] chars = "abcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*".toCharArray();
			StringBuffer sb = new StringBuffer();
			Random random = new Random();
			for (int i = 0; i < 15; i++)
			{
				char c = chars[random.nextInt(chars.length)];
				sb.append(c);
			}
			String output = CryptoUtils.getMD5Hash(sb.toString());  
			return output;
		}
		
		
		public void paymentOption(PayStudent paystudent) throws JarException, JSONException
		{  		      
			byte[] byteArr = Base64.decodeBase64(paystudent.getStudentList());   
			String s = new String(byteArr);
			JSONObject jsonObject = new JSONObject(s);
			List<JSONObject> list = new ArrayList<JSONObject>();
			JSONArray array = new JSONArray(jsonObject.get("studentList").toString());
			for (int i = 0; i < array.length(); i++)
			{
				list.add(array.getJSONObject(i));  
			}   

			/*Iterator<JSONObject> i = list.iterator();

			while (i.hasNext())
			{	  
				JSONObject jsonObj = i.next();    
				Student studentDetails = new Student();   
				studentDetails.setCenterId(paystudent.getCenterId());
				studentDetails.setLogUser(paystudent.getLogUser());     
				studentDetails.setAadhaar(jsonObj.getString("aadhaar"));
				studentDetails.setEmail(jsonObj.getString("email"));
				studentDetails.setPhone(jsonObj.getString("phone"));
				studentDetails.setName(jsonObj.getString("name"));      
				studentDetails.setFee(jsonObj.get("fee").toString());  
				studentDetails.setNetAmount(payment.getAmount());
				studentDetails.setTotalStudents(Integer.parseInt(paystudent.getStudents()));
				
			}        */        

			Map<String, Object> map1 = new HashMap<String, Object>();
			map1.put("p", paystudent);
			
			sqlSessionTemplate.insert("PayStudent.saveBulkPaymentDetails", map1);

			
		}

	
}
