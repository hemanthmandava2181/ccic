package com.spring.DAO;

import java.util.HashMap;


import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.spring.Model.Table;

@Repository
public class TableDAO extends BaseDAO {    
	@Autowired    
	private SqlSessionFactory sqlSessionFactory;
    
	/*public void add(Table table) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("p", table);   
		SqlSession sqlSession = sqlSessionFactory.openSession();
		params.put("applicationid",table.getApplicationid());
        params.put("address",table.getAddress());
	   	sqlSession.update("Table.UpdateAddress", params);
		sqlSession.close();      
	}*/
	           
	public List<Table> getNameWiseData(Table table) {   
		SqlSession sqlSession = sqlSessionFactory.openSession();
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("institutioncode", table.getInstitutioncode());	
		params.put("courseid",table.getCourseid()); 
		params.put("name",table.getName());    
		List<Table> nameWiseData=sqlSession.selectList("Table.getNameWiseData",params);
		sqlSession.close();
		return nameWiseData;     
	}   
	
	public List<Table> getAll(String institutioncode,String courseid) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("institutioncode", institutioncode);	
		params.put("courseid",courseid);
		List<Table> librarydetails=sqlSession.selectList("Table.getAll",params);
		sqlSession.close();
		return librarydetails;
		  	
	}

/*	public void remove(String lib)
	{
		SqlSession sqlSession = sqlSessionFactory.openSession();
		sqlSession.delete("Library.deleteData",lib);
		sqlSession.close();
	}
*/
	public Table getById(Table table)
	{ 
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("institutioncode",table.getInstitutioncode());	
		params.put("applicationid",table.getApplicationid());	
		table = sqlSessionTemplate.selectOne("Table.getById",params);
		return table;             
		        
	}
	
	   

	public void updateData(Table table)   
	{
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("p", table);   
		SqlSession sqlSession = sqlSessionFactory.openSession();
		sqlSession.update("Table.updateData",params);
		sqlSession.close();
	}
      
}
