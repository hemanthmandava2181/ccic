package com.spring.DAO;

import java.util.HashMap;

import javax.persistence.PersistenceException;

import java.util.List;
import java.util.Map;

import java.util.Iterator;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.Model.Student;
                                
@Repository
public class StudentDAO extends BaseDAO {    
	@Autowired    
	private SqlSessionFactory sqlSessionFactory;
    
	
	public Student getYear()
	{
		SqlSession sqlSession = sqlSessionFactory.openSession();
		Student year=sqlSession.selectOne("Student.getYear1");
		sqlSession.close();
		return year;
		
	}
	
	public Map<String, Object> saveDetails(List<Student> student, String ipAddress)
	{
		Map<String, Object> maps = new HashMap<String, Object>();

		Student student1 = new Student();
		student1
				.setRole(((Student) student.get(0)).getRole());
		student1
				.setFilePath(((Student) student.get(0)).getFilePath());
		student1
				.setFileExtension(((Student) student.get(0)).getFileExtension());
		Map<String, Object> map1 = new HashMap<String, Object>();
		map1.put("p1", student1);
	
		sqlSessionTemplate.insert("Student.saveFileUploadDetails", map1);
		try
		{	
			if (student.size() > 0)
			{  
				Iterator<Student> i = student.iterator();
				while (i.hasNext())
				{
					Student stud =
							(Student) i.next();
					stud.setIpAddress(ipAddress);
					maps.put("p", stud);
					                                
					SqlSession sqlSession = sqlSessionFactory.openSession();
				     Integer currentYear  =sqlSession.selectOne("Student.getYear");
				     Integer currentMonth =sqlSession.selectOne("Student.getMonth");
			        System.out.println("Current Month: " + currentMonth);
			        System.out.println("Current Year: " + currentYear);
			        if (currentMonth > 8 || currentMonth <= 2 )  
			        {
			           maps.put("month",2);
			           maps.put("year",currentYear+1);
			        }
			        else
			        {
			           maps.put("month",8);
			           maps.put("year",currentYear);
			        }
			     
				Student countdetails=sqlSession.selectOne("Student.count", maps);
				stud.count = countdetails.count;
					
					
						System.out.println("==============================>"+maps);
							this.sqlSessionTemplate.insert("Student.saveDetails", maps);
						this.sqlSessionTemplate.update("Student.updateDetails", maps);				
				}
			}                          
		} 
		catch (Throwable t)            
		{
			System.out.println("Excepction occured during updateBatch: " + t);

			throw new PersistenceException(t);
		}
		return map1;
		}
		
	
	
	
	public void add(Student stu) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("p", stu);
		 /* Calendar localCalendar = Calendar.getInstance(TimeZone.getDefault());*/
		  SqlSession sqlSession = sqlSessionFactory.openSession();
		     Integer currentYear  =sqlSession.selectOne("Student.getYear");
		     Integer currentMonth =sqlSession.selectOne("Student.getMonth");
	       /* Date currentTime = localCalendar.getTime();
	        int currentDay = localCalendar.get(Calendar.DATE);*/
//		    int currentMonth = localCalendar.get(Calendar.MONTH) + 1;
//	        int currentYear = localCalendar.get(Calendar.YEAR);   
	        System.out.println("Current Month: " + currentMonth);
	        System.out.println("Current Year: " + currentYear);
	        System.out.println("uyoghruekh: " + stu.getExmcentercode());
	        if (currentMonth > 8 || currentMonth <= 2 )  
	        {
	           //int month = 2;    
	          // int year = currentYear +1;
	           //System.out.println("month = " + month +" year = "+ year);
	           params.put("month",2);
	           params.put("year",currentYear+1);
	        }
	        else/* if (currentMonth < 8 && currentMonth > 2 )*/
	        {
	           //int month = 8;
	           //int year = currentYear;
	          // System.out.println("month = " + month +" year = "+ year);
	           params.put("month",8);
	           params.put("year",currentYear);
	        }
	      /*  else { 
	            System.out.println("you are not allowed for registration");
	        }
*/	        // Calendar gmtCalendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
	       
		//SqlSession sqlSession = sqlSessionFactory.openSession();
		/*System.out.print("fmjvghnn" + params);*/
		Student countdetails=sqlSession.selectOne("Student.count", params);
		stu.count = countdetails.count;
		sqlSession.insert("Student.Insert", params);
		sqlSession.update("Student.updateDetails", params);
		sqlSession.close(); 
	}
	         
	public List<Student> getAll(String institutioncode,String courseid) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("institutioncode", institutioncode);	
		params.put("courseid",courseid);
		List<Student> librarydetails=sqlSession.selectList("Student.getAll",params);
		sqlSession.close();
		return librarydetails;
			
	}

/*	public void remove(String lib)
	{
		SqlSession sqlSession = sqlSessionFactory.openSession();
		sqlSession.delete("Library.deleteData",lib);
		sqlSession.close();
	}
*/
	public Student getById(Student student)
	{ 
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("institutioncode",student.getInstitutioncode());	
		params.put("email",student.getEmail());	
		student = sqlSessionTemplate.selectOne("Student.getById",params);
		return student;             
		
	}
	
	   

	public void updateData(Student stu)
	{
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("p", stu);
		SqlSession sqlSession = sqlSessionFactory.openSession();
		sqlSession.update("Student.updateData",params);
		sqlSession.close();
	}

}
