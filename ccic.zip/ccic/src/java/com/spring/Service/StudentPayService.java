package com.spring.Service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.andromeda.commons.model.Response;
import com.spring.DAO.StudentPayDAO;
import com.spring.Model.StudentPay;
import com.spring.Model.Table;

@Service
public class StudentPayService {

	Response response = new Response();

	@Autowired       
	private StudentPayDAO  studentPayDAO;
	
	public Response getByApplicationId(String applicationid)
	{
		response.setSuccessful(false);
		StudentPay singleuserdetails = studentPayDAO.getByApplicationId(applicationid);
		response.setSuccessful(true);  
		response.setResponseObject(singleuserdetails);
		return response;
	}    
	
	public Response getSubjects(String applicationid)
	{
		response.setSuccessful(false);
		List<Map<String, Object>> subjects = studentPayDAO.getSubjects(applicationid);
		response.setSuccessful(true);
		response.setResponseObject(subjects);
		return response;
	}
	public Response generateHallTicket(String applicationid)
	{
		response.setSuccessful(false);
		studentPayDAO.generateHallTicket(applicationid);
		response.setSuccessful(true);
		response.setResponseObject(applicationid);      
		return response;
	}
}
