package com.spring.Service;

import java.util.List;
import java.util.Map;     
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.andromeda.commons.model.Response;
import com.spring.DAO.StudentsApproveDAO;
import com.spring.Model.StudentsApprove;
import com.spring.Model.Table;
import com.spring.Model.Email;
import com.spring.Model.Student;
/*import com.spring.Model.Enroll;*/
import com.spring.Service.EmailService;
import com.spring.Service.StudentsApproveService;
@Service
public class StudentsApproveService
{
	@Autowired
	StudentsApproveDAO studentsApproveDAO;

	@Autowired
	EmailService emailService;
	StudentsApproveService studentsApproveService;
	Response response = new Response();

	

	public Response getDistricts()
	{
		response.setSuccessful(false);
		List<Map<String, Object>> districts = studentsApproveDAO.getDistricts();
		response.setSuccessful(true);
		response.setResponseObject(districts);
		return response;    
	}
	
	public Response getColleges(Integer districtid)
	{
		response.setSuccessful(false);
		System.out.println(districtid);
		List<Map<String, Object>> colleges = studentsApproveDAO.getColleges(districtid);
		response.setSuccessful(true);
		response.setResponseObject(colleges);
		return response;
	}
	
	
	public Response getCourses(String instituteid)
	{
		response.setSuccessful(false);
		List<Map<String, Object>> districts = studentsApproveDAO.getCourses(instituteid);
		response.setSuccessful(true);
		response.setResponseObject(districts);
		return response;
	}
	
	public Response getAll(String instituteid,String courseid)
	{
		response.setSuccessful(false);
		List<Map<String, Object>> districts = studentsApproveDAO.getAll(instituteid,courseid);
		response.setSuccessful(true);
		response.setResponseObject(districts);
		return response;   
	}
	public Response updateData(String applicationid)
	{
		response.setSuccessful(false);
		studentsApproveDAO.updateData(applicationid);
		response.setSuccessful(true);      
		response.setResponseObject(applicationid);   
		return response;
	}
	public Response generateHallTicket(String applicationid,String name)
	{
		response.setSuccessful(false);
		studentsApproveDAO.generateHallTicket(applicationid,name);
		response.setSuccessful(true);
		response.setResponseObject(applicationid);      
		return response;
	}
}