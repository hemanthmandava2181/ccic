package com.spring.Service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.andromeda.commons.model.Response;
import com.spring.DAO.StudentDAO;
import com.spring.Model.Student;

@Service
public class StudentService {

	Response response = new Response();

	@Autowired       
	private StudentDAO  stuDAO;
	
	
	public Response getYear()
	{
		response.setSuccessful(false);
		Student data = stuDAO.getYear();
		response.setResponseObject(data);
		response.setSuccessful(true);
		return response;
	}
	
	
	 public Response saveDetails(List<Student> student, String ipAddress, List<String> pathsList)
	  {
	    this.response.setSuccessful(false);
	    Map<String, Object> list=this.stuDAO.saveDetails(student, ipAddress);
	    
	    Student filePathsMail = new Student();
	    
	    filePathsMail.setPaths(pathsList);
	    
	   // mailSend(filePathsMail);
	    
	    this.response.setSuccessful(true);
	    response.setResponseObject(list);       
	    
	    return this.response;
	  }
	
	
     
	public Response add(Student stu) {
		response.setSuccessful(false);
		stuDAO.add(stu);
		response.setSuccessful(true);
		response.setResponseObject(stu);
		return response;
	}                                                   
	
	public Response getAll(String institutioncode,String courseid) {
		response.setSuccessful(false);
		List<Student> userdetails = stuDAO.getAll(institutioncode,courseid);
		response.setSuccessful(true);
		response.setResponseObject(userdetails);
		return response;
	}

	/*public Response remove(String branch)
	{
		response.setSuccessful(false);
		libDAO.remove(branch);
		response.setSuccessful(true);
		response.setResponseObject(branch);
		return response;
	}
*/
	public Response getById(Student student)
	{
		response.setSuccessful(false);
		Student singleuserdetails = stuDAO.getById(student);
		response.setSuccessful(true);  
		response.setResponseObject(singleuserdetails);
		return response;
	}    

	
	public Response updateData(Student email)
	{
		response.setSuccessful(false);
		stuDAO.updateData(email);
		response.setSuccessful(true);
		response.setResponseObject(email);
		return response;
	}
	

}
