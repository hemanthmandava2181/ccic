package com.spring.Service;

import java.util.List;
import java.util.Map;
import java.util.jar.JarException;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.andromeda.commons.model.Response;
import com.spring.DAO.PayStudentDAO;
import com.spring.Model.PayStudent;

import commons.util.IDGenerator;

@Service
public class PayStudentService {

	Response response = new Response();

	@Autowired       
	private PayStudentDAO  payStudentDAO;
     
	public Response getNameWiseData(PayStudent payStudent) {
		response.setSuccessful(false);
		List<PayStudent> nameWiseData = payStudentDAO.getNameWiseData(payStudent);
		response.setSuccessful(true);
		response.setResponseObject(nameWiseData);
		return response;
	}                                              
	
	public Response getAll(String institutioncode,String courseid) {
		response.setSuccessful(false);
		List<PayStudent> userdetails = payStudentDAO.getAll(institutioncode,courseid);
		response.setSuccessful(true);
		response.setResponseObject(userdetails);
		return response;
	}
	
	public Response getBacklogAll(String institutioncode,String courseid) {
		response.setSuccessful(false);
		List<PayStudent> userdetails = payStudentDAO.getBacklogAll(institutioncode,courseid);
		response.setSuccessful(true);
		response.setResponseObject(userdetails);
		return response;
	}
	
	public Response getSubjects(String courseid)
	{
		response.setSuccessful(false);
		List<Map<String, Object>> subjects = payStudentDAO.getSubjects(courseid);
		response.setSuccessful(true);
		response.setResponseObject(subjects);
		return response;
	}
	
	 
	public Response paymentOption(PayStudent paystudent) throws JSONException, JarException  
	{  
		paystudent.setGuid(IDGenerator.getUniqueID() + payStudentDAO.generateString());
		Response response1 = new Response();  
		response1.setSuccessful(false);      
		payStudentDAO.paymentOption(paystudent);     
		response1.setSuccessful(true);        
		response1.setResponseObject(paystudent.getGuid());  
		return response1;
	}
}
