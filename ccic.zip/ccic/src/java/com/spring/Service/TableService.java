package com.spring.Service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.andromeda.commons.model.Response;
import com.spring.DAO.TableDAO;

import com.spring.Model.Table;

@Service
public class TableService {

	Response response = new Response();

	@Autowired       
	private TableDAO  tableDAO;
     
	public Response getNameWiseData(Table table) {
		response.setSuccessful(false);
		List<Table> nameWiseData = tableDAO.getNameWiseData(table);
		response.setSuccessful(true);
		response.setResponseObject(nameWiseData);
		return response;
	}           
	
	/*public Response add(Table table) {
		response.setSuccessful(false);
		tableDAO.add(table);
		response.setSuccessful(true);
		response.setResponseObject(table);
		return response;
	}         */                                          
	
	public Response getAll(String institutioncode,String courseid) {
		response.setSuccessful(false);
		List<Table> userdetails = tableDAO.getAll(institutioncode,courseid);
		response.setSuccessful(true);
		response.setResponseObject(userdetails);
		return response;
	}

	/*public Response remove(String branch)
	{
		response.setSuccessful(false);
		libDAO.remove(branch);
		response.setSuccessful(true);
		response.setResponseObject(branch);
		return response;
	}
*/
	public Response getById(Table table)
	{
		response.setSuccessful(false);
		Table singleuserdetails = tableDAO.getById(table);
		response.setSuccessful(true);  
		response.setResponseObject(singleuserdetails);
		return response;
	}    

	     
	public Response updateData(Table table)
	{
		tableDAO.updateData(table);
		response.setSuccessful(true);
		response.setResponseObject(table);
		return response;
	}
	

}
