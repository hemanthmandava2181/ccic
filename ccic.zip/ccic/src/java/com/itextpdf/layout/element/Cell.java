package com.itextpdf.layout.element;

public class Cell {

	public static final int ALIGN_LEFT = 0;

}
