import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DownloadServlet extends HttpServlet
{

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{

		JavaIntegrationKit integrationKit = new JavaIntegrationKit();
		Map<String, String> values = integrationKit.hashCalMethod(request, response);
		System.out.println("===============>"+values);
		PrintWriter writer = response.getWriter();
		// build HTML code
		String htmlResponse =
				"<html> <body> \n" + "      \n" + "  \n" + "  <h1>PayUForm </h1>\n" + "  \n"
						+ "<div>" + "        <form id=\"payuform\" action=\""
						+ values.get("action")
						+ "\"  name=\"payuform\" method=POST >\n"
						+ "      <input type=\"hidden\" name=\"key\" value="
						+ values.get("key").trim()
						+ ">"
						+ "      <input type=\"hidden\" name=\"hash\" value="
						+ values.get("hash").trim()
						+ ">"
						+ "      <input type=\"hidden\" name=\"txnid\" value="
						+ values.get("txnid").trim()
						+ ">"
						+ "      <table>\n"
						+ "        <tr>\n"
						+ "          <td><b>Mandatory Parameters</b></td>\n"
						+ "        </tr>\n"
						+ "        <tr>\n"
						+ "         <td>Amount: </td>\n"
						+ "          <td><input name=\"amount\" value="
						+ values.get("amount").trim()
						+ " /></td>\n"
						+ "          <td>First Name: </td>\n"
						+ "          <td><input name=\"firstname\" id=\"firstname\" value="
						+ values.get("firstname").trim()
						+ " /></td>\n"
						+ "        <tr>\n"
						+ "          <td>Email: </td>\n"
						+ "          <td><input name=\"email\" id=\"email\" value="
						+ values.get("email").trim()
						+ " /></td>\n"
						+ "          <td>Phone: </td>\n"
						+ "          <td><input name=\"phone\" value="
						+ values.get("phone")
						+ " ></td>\n"
						+ "        </tr>\n"
						+ "        <tr>\n"
						+ "          <td>Product Info: </td>\n"
						+ "<td><input name=\"productinfo\" value="
						+ values.get("productinfo").trim()
						+ " ></td>\n"
						+ "        </tr>\n"
						+ "        <tr>\n"
						+ "          <td>Success URI: </td>\n"
						+ "          <td colspan=\"3\"><input name=\"surl\"  size=\"64\" value="
						+ values.get("surl")
						+ "></td>\n"
						+ "        </tr>\n"
						+ "        <tr>\n"
						+ "          <td>Failure URI: </td>\n"
						+ "          <td colspan=\"3\"><input name=\"furl\" value="
						+ values.get("furl")
						+ " size=\"64\" ></td>\n"
						+ "        </tr>\n"
						+ "\n"
						
						+ "       <tr> <td colspan=\"4\"><input type=\"submit\" value=\"Submit\"  /></td></tr>\n"
						+ "      \n"
						+ "    \n"
						+ "      </table>\n"
						+ "    </form>\n"
						+ " <script> "
						+ " document.getElementById(\"payuform\").submit(); "
						+ " </script> " + "       </div>   " + "  \n" + "  </body>\n" + "</html>";
		// return response
		writer.println(htmlResponse);
		
	}

}
