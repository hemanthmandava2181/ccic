package in.apssdc.paymentgateway.dao;

import in.apssdc.paymentgateway.model.Echallan;
import in.apssdc.paymentgateway.model.Payment;

import java.util.HashMap;
import java.util.Map;

import com.andromeda.commons.dao.BaseDAO;

public class PaymentDAO extends BaseDAO   
{

	public Echallan getMailIdByCode(Payment payment)
	{
		Echallan data = null;
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p", payment);
		//Map<String, Object> params = new HashMap<String, Object>();
		return data = (Echallan) sqlSessionTemplate.selectList("Payment.getMailId", map);   
	}   

	public String getTxnId()
	{
		String txnId = sqlSessionTemplate.selectOne("Payment.getTxnId");
		System.out.println(txnId);
		return txnId;
	}
}