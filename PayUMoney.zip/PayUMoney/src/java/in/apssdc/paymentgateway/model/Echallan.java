package in.apssdc.paymentgateway.model;

import com.andromeda.commons.model.BaseModel;

public class Echallan extends BaseModel
{  
	private String email;
	private Integer jobid;
	private String aadhaar;
	private String guid;
	private String apssdcNumber;
	private String challanPath;
	private String ipAddress;        
	private String phone;   
	private String name;  
	private String program;
	private String uniqueKey;
	private String registrationid;  
	private Integer trainingbatchid;
	private Integer batchprogramid;
	private Integer programid;
	private Integer collegecourseid;
	private String course;
	private String centerId;
	private String username;
	private String fee;
	private String feeInWords;
	private Integer trainingBatchId;
	private String studentList;
	private String key;
	private String hash;
	private String txnId;
	private String amount;
	//private String name;
	private String productInfo;
	private String surl;
	private String furl;  
	private String actionUrl;
	private String batchId;
	private String bulkPaymentKey;
	private String applicationId;
	

	private String transactionid;
	private String instituteid;
	private String courseid;
	
	
	

	
	public String getInstituteid() {
		return instituteid;
	}

	public void setInstituteid(String instituteid) {
		this.instituteid = instituteid;
	}

	public String getCourseid() {
		return courseid;
	}

	public void setCourseid(String courseid) {
		this.courseid = courseid;
	}
	public String getTransactionid() {
		return transactionid;
	}

	public void setTransactionid(String transactionid) {
		this.transactionid = transactionid;
	}

	public String getBulkPaymentKey()
	{
		return bulkPaymentKey;
	}

	public void setBulkPaymentKey(String bulkPaymentKey)
	{
		this.bulkPaymentKey = bulkPaymentKey;
	}

	public String getBatchId()
	{
		return batchId;
	}

	public void setBatchId(String batchId)
	{
		this.batchId = batchId;
	}

	public String getActionUrl()
	{
		return actionUrl;
	}

	public void setActionUrl(String actionUrl)
	{
		this.actionUrl = actionUrl;
	}

	public String getKey()
	{
		return key;
	}

	public void setKey(String key)
	{
		this.key = key;
	}

	public String getHash()
	{
		return hash;
	}

	public void setHash(String hash)
	{
		this.hash = hash;
	}

	public String getTxnId()
	{
		return txnId;
	}

	public void setTxnId(String txnId)
	{
		this.txnId = txnId;
	}

	public String getAmount()
	{
		return amount;
	}

	public void setAmount(String amount)
	{
		this.amount = amount;
	}

	/*public String getFirstName()
	{
		return firstName;
	}

	public void setFirstName(String firstName)
	{  
		this.firstName = firstName;
	}*/

	public String getProductInfo()
	{
		return productInfo;
	}

	public void setProductInfo(String productInfo)
	{
		this.productInfo = productInfo;
	}

	public String getSurl()
	{
		return surl;
	}

	public void setSurl(String surl)
	{
		this.surl = surl;
	}

	public String getFurl()
	{
		return furl;
	}

	public void setFurl(String furl)
	{
		this.furl = furl;
	}

	public String getStudentList()
	{
		return studentList;
	}

	public void setStudentList(String studentList)
	{
		this.studentList = studentList;
	}

	public Integer getTrainingBatchId()
	{
		return trainingBatchId;
	}

	public void setTrainingBatchId(Integer trainingBatchId)
	{
		this.trainingBatchId = trainingBatchId;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public Integer getJobid()
	{
		return jobid;
	}

	public void setJobid(Integer jobid)
	{
		this.jobid = jobid;
	}

	public String getAadhaar()
	{
		return aadhaar;
	}

	public void setAadhaar(String aadhaar)
	{
		this.aadhaar = aadhaar;
	}

	public String getGuid()
	{
		return guid;
	}

	public void setGuid(String guid)
	{
		this.guid = guid;
	}

	public String getApssdcNumber()
	{
		return apssdcNumber;
	}

	public void setApssdcNumber(String apssdcNumber)
	{
		this.apssdcNumber = apssdcNumber;
	}

	public String getChallanPath()
	{
		return challanPath;
	}

	public void setChallanPath(String challanPath)
	{
		this.challanPath = challanPath;
	}

	public String getIpAddress()
	{
		return ipAddress;
	}

	public void setIpAddress(String ipAddress)
	{
		this.ipAddress = ipAddress;
	}

	public String getPhone()
	{
		return phone;
	}

	public void setPhone(String phone)
	{
		this.phone = phone;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getProgram()
	{
		return program;
	}

	public void setProgram(String program)
	{
		this.program = program;
	}

	public String getUniqueKey()
	{
		return uniqueKey;
	}

	public void setUniqueKey(String uniqueKey)
	{
		this.uniqueKey = uniqueKey;
	}

	public String getRegistrationid()
	{
		return registrationid;
	}

	public void setRegistrationid(String registrationid)
	{
		this.registrationid = registrationid;
	}

	public Integer getTrainingbatchid()
	{
		return trainingbatchid;
	}

	public void setTrainingbatchid(Integer trainingbatchid)
	{
		this.trainingbatchid = trainingbatchid;
	}

	public Integer getBatchprogramid()
	{
		return batchprogramid;
	}

	public void setBatchprogramid(Integer batchprogramid)
	{
		this.batchprogramid = batchprogramid;
	}

	public Integer getProgramid()
	{
		return programid;
	}

	public void setProgramid(Integer programid)
	{
		this.programid = programid;
	}

	public Integer getCollegecourseid()
	{
		return collegecourseid;
	}

	public void setCollegecourseid(Integer collegecourseid)
	{
		this.collegecourseid = collegecourseid;
	}

	public String getCourse()
	{
		return course;
	}

	public void setCourse(String course)
	{
		this.course = course;
	}

	public String getFee()
	{
		return fee;
	}

	public void setFee(String fee)
	{
		this.fee = fee;
	}

	public String getFeeInWords()
	{
		return feeInWords;
	}

	public void setFeeInWords(String feeInWords)
	{
		this.feeInWords = feeInWords;
	}

	public String getCenterId() {
		return centerId;
	}

	public void setCenterId(String centerId) {
		this.centerId = centerId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}


	

}
