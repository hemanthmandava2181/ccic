package in.apssdc.paymentgateway.model;

import com.andromeda.commons.model.BaseModel;

public class Payment extends BaseModel
{
	private String paymentOption;
	private String aadhaar;
	private String uniqueKey;
	private boolean paymentStatus;
	private Integer trainingBatchId;
	private String fee;
	private Integer collegeId;
	private String userName;  
	private String students;
	private String amount;   
	private String studentList; 
	private String course;
	private String bulkPaymentKey;
	private String centerId;
	private String coursecode;
	private String logUser;  
	private String phone;
	private String name;
	private String email;
	private String applicationId;
	private String instituteid;
	private String courseid;
	
	
	

	
	public String getInstituteid() {
		return instituteid;
	}

	public void setInstituteid(String instituteid) {
		this.instituteid = instituteid;
	}

	public String getCourseid() {
		return courseid;
	}

	public void setCourseid(String courseid) {
		this.courseid = courseid;
	}
	
	
	public String getCenterId() {
		return centerId;
	}

	public void setCenterId(String centerId) {
		this.centerId = centerId;
	}

	public String getCoursecode() {
		return coursecode;
	}

	public void setCoursecode(String coursecode) {
		this.coursecode = coursecode;
	}

	public String getLogUser() {
		return logUser;
	}

	public void setLogUser(String logUser) {
		this.logUser = logUser;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}


	
  
	public String getBulkPaymentKey()  
	{
		return bulkPaymentKey;
	}

	public void setBulkPaymentKey(String bulkPaymentKey)
	{
		this.bulkPaymentKey = bulkPaymentKey;
	}

	public String getCourse()
	{
		return course;
	}

	public void setCourse(String course)
	{
		this.course = course;
	}

	public String getStudentList()
	{
		return studentList;
	}

	public void setStudentList(String studentList)
	{
		this.studentList = studentList;
	}

	public Integer getCollegeId()
	{
		return collegeId;
	}

	public void setCollegeId(Integer collegeId)
	{
		this.collegeId = collegeId;
	}

	public String getUserName()
	{
		return userName;
	}

	public void setUserName(String userName)
	{
		this.userName = userName;
	}

	public String getStudents()
	{
		return students;
	}

	public void setStudents(String students)
	{
		this.students = students;
	}

	public String getAmount()
	{
		return amount;
	}

	public void setAmount(String amount)
	{
		this.amount = amount;
	}

	public String getFee()
	{
		return fee;
	}

	public void setFee(String fee)
	{
		this.fee = fee;
	}

	public Integer getTrainingBatchId()
	{
		return trainingBatchId;
	}

	public void setTrainingBatchId(Integer trainingBatchId)
	{
		this.trainingBatchId = trainingBatchId;
	}

	public boolean isPaymentStatus()
	{
		return paymentStatus;
	}

	public void setPaymentStatus(boolean paymentStatus)
	{
		this.paymentStatus = paymentStatus;
	}

	public String getUniqueKey()
	{
		return uniqueKey;
	}

	public void setUniqueKey(String uniqueKey)
	{
		this.uniqueKey = uniqueKey;
	}

	public String getPaymentOption()
	{
		return paymentOption;
	}

	public void setPaymentOption(String paymentOption)
	{
		this.paymentOption = paymentOption;
	}

	public String getAadhaar()
	{
		return aadhaar;
	}

	public void setAadhaar(String aadhaar)
	{
		this.aadhaar = aadhaar;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	

}
