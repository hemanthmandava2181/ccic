package in.apssdc.paymentgateway.service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.andromeda.commons.model.Response;

import in.apssdc.paymentgateway.dao.PaymentDAO;
import in.apssdc.paymentgateway.model.Echallan;

@Service
public class PayUService
{  
	Response response = new Response();

	@Autowired  
	private PaymentDAO paymentDAO;

	public Response getPayUPage(Echallan echallan)
	{             
		   
		  
		String actionUrl = "https://secure.payu.in/_payment";  
		String key = "Ibyh6q";  
		String salt = "Mh8kjduV";  
		  
		Float amount = Float.parseFloat(echallan.getFee().toString());  
		// Float amount = 2.00f;     
		     
		String txnId = paymentDAO.getTxnId();        
		String courseid = echallan.getCourseid();
		String instituteid = echallan.getInstituteid();
		
		
		String productInfo = "CCIC-Certificate-Fee";       
		
		String surl = "http://localhost:8080/siemensPaymentStatus/status";
		String furl = "http://localhost:8080/siemensPaymentStatus/status";         
        
		String[] name = echallan.getName().split(" ");    
		     
		                          
		                     
		/**************************************************************************/
		
				
		String hashPrepare = key +"|" + txnId + "|" + amount + "|" + productInfo + "|" + name[0] + "|" +
				echallan.getEmail().trim() + "|" + courseid + "|" + instituteid + "|" + "123" +"|"+echallan.getBulkPaymentKey()+ "|||||||" + salt;

				     
				         
				String hash = hashCal("SHA-512", hashPrepare.trim());              
				           
				// build HTML code              
				          
				   
				String htmlResponse = "<html> <body> \n" + "      \n" + "  \n" + "<div>"
				+ "        <form id=\"payuform\" action=\"" + actionUrl + "\"  name=\"payuform\" method=\"POST\" >\n"
				+ "      <input type=\"hidden\" name=\"key\" value=" + key + ">"
		   		+ "      <input type=\"hidden\" name=\"hash\" value=" + hash + ">"
				+ "      <input type=\"hidden\" name=\"txnid\" value=" + txnId + ">" + "      <table>\n"    
				+ "        <tr>\n" + "          <td><input type=\"hidden\" name=\"amount\" value="
				+amount + " /></td>\n"
				+ "          <td><input type=\"hidden\" name=\"firstname\" id=\"firstname\" value=" + name[0]
				+ " /></td>\n" + "        <tr>\n"
				+ "          <td><input type=\"hidden\" name=\"email\" id=\"email\" value=" + echallan.getEmail().trim()
				+ " /></td>\n" + "          <td><input type=\"hidden\" name=\"phone\" value="
				+ echallan.getPhone()+ " ></td>\n" + "        </tr>\n" + "        <tr>\n"
				+ "<td><input type=\"hidden\" name=\"productinfo\" value=" + productInfo.trim() + " ></td>\n"      
				+ "        </tr>\n" + "        <tr>\n"
				+ "          <td colspan=\"3\"><input type=\"hidden\" name=\"surl\"  size=\"64\" value=" + surl
				+ "></td>\n" + "        </tr>\n" + "        <tr>\n"
				+ "          <td colspan=\"3\"><input type=\"hidden\" name=\"furl\" value=" + furl
				+ " size=\"64\" ></td>\n" + "        </tr>\n"
				      
				     
				 + "        <tr>\n" +
				 "          <td colspan=\"3\"><input type=\"hidden\" name=\"udf1\" value=" +
				 courseid + " size=\"64\" ></td>\n" + "        </tr>\n" +
				 "        <tr>\n"
				     

				+ "          <td colspan=\"3\"><input type=\"hidden\" name=\"udf2\" value=" + instituteid
				+ " size=\"64\" ></td>\n" + "        </tr>\n" + "        <tr>\n"
				 
				+ "          <td colspan=\"3\"><input type=\"hidden\" name=\"udf3\" value="   
				+ "123" + " size=\"64\" ></td>\n" + "        </tr>\n"+ "<tr>\n"        

				+ "          <td colspan=\"3\"><input type=\"hidden\" name=\"udf4\" value="
				+ echallan.getBulkPaymentKey() + " size=\"64\" ></td>\n" + "        </tr>\n"
				+ "\n" + "      \n" + "    \n" + "      </table>\n" + "    </form>\n" + " <script> "
				+ " document.getElementById(\"payuform\").submit(); " + " </script> " + "       </div>   " + "  \n"
				+ "  </body>\n" + "</html>";  
				// return response    
				response.setResponseObject(htmlResponse);      
				       
				   

				response.setSuccessful(true);  
				return response;    
		
		
		
	}
    
	public String hashCal(String type, String str) {
		byte[] hashseq = str.getBytes();
		StringBuffer hexString = new StringBuffer();
		try {  
			MessageDigest algorithm = MessageDigest.getInstance(type);
			algorithm.reset();
			algorithm.update(hashseq);
			byte messageDigest[] = algorithm.digest();
			for (int i = 0; i < messageDigest.length; i++) {
				String hex = Integer.toHexString(0xFF & messageDigest[i]);
				if (hex.length() == 1) {
					hexString.append("0");  
				}  
				hexString.append(hex);       
			}
  
		} catch (NoSuchAlgorithmException nsae) {
		}
		return hexString.toString();
	}

}