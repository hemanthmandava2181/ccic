package in.apssdc.paymentgateway.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.andromeda.commons.model.Response;

import in.apssdc.paymentgateway.dao.PaymentDAO;
import in.apssdc.paymentgateway.model.Echallan;
import in.apssdc.paymentgateway.model.Payment;

@Service
public class PaymentService
{
	Response response = new Response();

	@Autowired
	private PaymentDAO paymentDAO;  

	@Autowired
	private PayUService payUService;
  
	public Response getMailIdByCode(Payment payment)
	{
		response.setSuccessful(false);
		Echallan bi = paymentDAO.getMailIdByCode(payment);
		if (bi.getEmail() != null)  
		{
			bi.setStudentList("NA");      
			bi.setBulkPaymentKey("NA");
			Response rs = payUService.getPayUPage(bi);      
			System.out.println("Response:"+rs);
			response.setSuccessful(rs.isSuccessful());
			//System.out.println("===========>" + rs);  
			response.setResponseObject(rs);  
			//System.out.println("===========>" + response);
		}
		else
		{
			response.setSuccessful(false);
			response.setErrorMessage("Link expired!");
			response.setResponseObject(null);
		}
		return response;
	}

	public Response bulkPayment(Payment payment)
	{  
		response.setSuccessful(false);   
		Echallan echallan = new Echallan();    
		echallan.setFee(payment.getAmount()); 
		//echallan.setCenterId(payment.getCenterId());
		echallan.setUsername(payment.getLogUser());		   
		echallan.setEmail(payment.getEmail());       
	//	echallan.setAadhaar(payment.getAadhaar());  
		echallan.setName(payment.getName());
		echallan.setStudentList(payment.getStudentList());
		echallan.setBulkPaymentKey(payment.getBulkPaymentKey());
	//    echallan.setCourse(payment.getCoursecode());	    
		echallan.setPhone(payment.getPhone());
		echallan.setInstituteid(payment.getInstituteid());
		echallan.setCourseid(payment.getCourseid());      
		Response rs = payUService.getPayUPage(echallan);
		response.setSuccessful(rs.isSuccessful());       
		response.setResponseObject(rs);
		
		return response;
	}
}