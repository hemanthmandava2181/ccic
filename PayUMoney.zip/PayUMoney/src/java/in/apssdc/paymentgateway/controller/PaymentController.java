package in.apssdc.paymentgateway.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.andromeda.commons.model.Response;

import in.apssdc.paymentgateway.model.Payment;
import in.apssdc.paymentgateway.service.PaymentService;

@RestController
@RequestMapping("/payment")
public class PaymentController
{
	Response response = new Response();

	@Autowired
	private PaymentService paymentService;

	@ResponseBody  
	@RequestMapping(value = "home", method = { RequestMethod.GET, RequestMethod.POST })
	public Response getMailIdByCode(@RequestBody Payment payment)
	{
		
		response = paymentService.getMailIdByCode(payment);
		return response;
	}
  
	@ResponseBody
	@RequestMapping(value = "bulkPayment", method = { RequestMethod.GET, RequestMethod.POST })
	public Response bulkPayment(@RequestBody Payment payment)
	{
		     
		Response response = paymentService.bulkPayment(payment);
		   
		return response;  
	}
}   