 var emailgenerator = angular.module('emailgenerator', [])
.controller('FormController', [ '$http', '$scope', function($http, $scope) {
$scope.get=function(sendEmail){
	    	$http.post('/fileupload/studentRegistration/sendEmail',sendEmail).then(function(response){
	    		$scope.data = response.data;
				if($scope.data.successful){
						alert("inserted successfully");
				} else {
					showError($scope.data.errorMessage);
					var message = "<div class=\"alert alert-danger\"><strong>Error: </strong>"+ $scope.data.errorMessage + "</div>";
					jQuery("#errorDiv").html(message);
				}
			}, function(errResponse) {
				console.error('Error while fetching notes');
			});
			} 
	    
} ]);