var loading = angular.module('loading', [])
.controller('FormController', [ '$http', '$scope', function($http, $scope)
{
	var param = Andromeda.getSessionValue("param");
	$http.post('payment/home', param).then(function(response)
	{
		$scope.data = response.data;
		if($scope.data.successful)
		{
			alert($scope.data.successful);
			jQuery("#containerDiv").html($scope.data.responseObject.responseObject);
		}
		else
		{
			alert("Link expired!");
		}
	});
}]);