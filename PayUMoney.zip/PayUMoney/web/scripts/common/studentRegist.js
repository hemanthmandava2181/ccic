var studentReg = angular.module('studentRegist', [])
.controller('FormController', [ '$http', '$scope', function($http, $scope) {
	
	
	var self = this;
	$scope.banks = [];
	$http.post('/fileupload/studentRegistration/getBanks').then(function(response) {
			$scope.data = response.data;
			if($scope.data.successful) {
				$scope.banks = $scope.data.responseObject.banks;
			} else {
				showError($scope.data.errorMessage);
				var message = "<div class=\"alert alert-danger\"><strong>Error: </strong>"+ $scope.data.errorMessage + "</div>";
				jQuery("#errorDiv").html(message);
			}
		}, function(errResponse) {
			console.error('Error ...');
		});
	
	
	    
	$scope.get=function(){
    	$http.post('/fileupload/studentRegistration/sendEmail').then(function(response){
    		$scope.data = response.data;
			if($scope.data.successful){
					alert("send mails");
			} else {
				showError($scope.data.errorMessage);
				var message = "<div class=\"alert alert-danger\"><strong>Error: </strong>"+ $scope.data.errorMessage + "</div>";
				jQuery("#errorDiv").html(message);
			}
		}, function(errResponse) {
			console.error('Error while fetching notes');
		});
		};
	
	
	$scope.save = function(studentReg) {
			if(studentReg!=null){
			if(studentReg.name!=null  && studentReg.securityCode!=null && studentReg.bankName!=null && studentReg.accNo!=null && studentReg.ifsc!=null ){      
	        $http.post('/fileupload/studentRegistration/add',studentReg).then(function(response) {
				$scope.data = response.data;
				if($scope.data.successful){
						alert("Your details have been saved!");
				} else {
					alert($scope.data.errorMessage);
					showError($scope.data.errorMessage);
					var message = "<div class=\"alert alert-danger\"><strong>Error: </strong>"+ $scope.data.errorMessage + "</div>";
					jQuery("#errorDiv").html(message);
				}
			}, function(errResponse) {
				console.error('Error while fetching notes');
			});
			} else {
				alert("Required Fields are mandatory!!!");
			}
			}else{
				alert("Please enter details!!!");
			}
	    };
	   
} ]);




